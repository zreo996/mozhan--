# /检查 命令使用文档

## 功能
对指定章节执行完整质量检查,输出P0/P1/P2问题清单和修改建议。

## 触发格式

```
/检查 第X章
/检查 第33章
/检查 第15-20章   # 批量检查
```

## 检查内容

### 五重P0自检(零LLM成本)
- 时间线单调性
- 角色位置一致性
- 修为/能力不倒退
- 伏笔回收(超3章未推进→FATAL)
- 物品流转闭环
- 角色幽灵检测

### P1审计(1次API)
- 视角混乱
- 节奏崩塌
- 战力崩坏
- 设定冲突
- 伏笔断裂
- 逻辑跳跃

### P2优化(可选)
- 句式单一
- 情感过载
- 描写冗余
- 对话空洞
- 伏笔过密
- 重复描写

## 输出格式

```json
{
  "chapter": 33,
  "passed": false,
  "summary": {
    "p0_count": 1,
    "p1_count": 2,
    "p2_count": 3
  },
  "issues": [
    {"level": "P0", "type": "伏笔丢失", "message": "..."}
  ],
  "recommendations": ["..."]
}
```

## 调用底层脚本

```bash
python core/scripts/continuity_enforcer.py ./data {章节号} --text {章节文件}
python core/scripts/self_check.py {章节号}
python core/scripts/quality_score.py {章节号} --text {章节文件} --data-dir ./data
```
