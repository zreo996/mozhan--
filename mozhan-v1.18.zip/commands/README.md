# Commands 目录

本目录包含 mozhan Skill 支持的所有触发命令文档。

## 命令列表

| 命令 | 文档 | 功能 |
|:---|:---|:---|
| `/写小说` | [write_novel.md](write_novel.md) | 启动新小说项目 |
| `/续写` | [continue_writing.md](continue_writing.md) | 续写指定章节 |
| `/检查` | [check_chapter.md](check_chapter.md) | 章节质量检查 |
| `/大纲` | [outline.md](outline.md) | 大纲管理 |
| `/状态` | [status.md](status.md) | 项目状态查看 |
| `/成本` | [cost_report.md](cost_report.md) | 成本统计 |
| `/评分` | [score.md](score.md) | 章节评分 |

## 工作流

```
/写小说              ← 项目启动
   ↓
/大纲                ← 规划全书
   ↓
/续写 第1章          ← 开始写作
   ↓
/检查 第1章          ← 质量检查
   ↓
/评分 第1章          ← 最终评分
   ↓
/状态                ← 进度回顾
   ↓
(重复续写流程)
   ↓
/成本                ← 阶段成本审视
```

## 命令实现说明

本Skill的命令为**触发词约定**,实际由Claude识别用户意图后调用对应的Python脚本。
不需要在 .claude/commands/ 中创建对应文件 — Skill框架会自动识别。

如需将这些命令注册为 Claude Code 的全局slash command,
可以软链接或复制到 `~/.claude/commands/` 目录,并修改文件名为可执行格式。
