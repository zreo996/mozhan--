# /状态 命令使用文档

## 功能
查看四表当前状态、项目进度、伏笔健康度、爽点密度等指标。

## 触发格式

```
/状态              # 综合状态
/状态 四表          # 仅四表摘要
/状态 伏笔          # 伏笔健康度
/状态 进度          # 写作进度
```

## 输出内容

### 综合状态

```
项目: 沧海剑歌
题材: 武侠
当前章节: 33/100 (33%)
当前阶段: 第一幕末 (出江湖)

== 四表健康度 ==
✓ timeline.json     第3天·黄昏,无矛盾
✓ characters         15位活跃,无瞬移
⚠ hooks.json        active:5, dormant:3, 1个接近超期(玉佩4章未推进)
✓ inventory.json    23件物品,流转闭环

== 节奏指标 ==
打脸密度: 8/33章 (基准 6-8) ✓
钩子覆盖: 33/33章 (100%) ✓
情感波动: 平均 3.2 点/章 ✓

== 成本统计 ==
累计tokens: 2.3M
平均成本: 70K/章
省成本率: 62% (相比基线)
```

### 伏笔详情

```
ACTIVE伏笔(5):
  ★ 神秘玉佩 [P1] 第1章引入,第29章最近提及(4章未推进,⚠接近超期)
  ★ 黑衣首领身份 [P0] 第1章引入,第30章最近提及
  ...

DORMANT伏笔(3):
  ☆ 师门旧址 [长线] 暂停推进
  ...

RECOVERED伏笔(7):
  ✓ 第一仇人下落 第15章回收
  ...
```

## 调用底层脚本

```bash
python core/scripts/one_click_writer.py report
```

读取:
- `data/timeline.json`
- `data/characters_snapshot.json`
- `data/hooks.json`
- `data/inventory.json`
- `data/cost_log.json`
