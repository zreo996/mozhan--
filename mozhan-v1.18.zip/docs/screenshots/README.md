# Screenshots

界面截图存这里。文件命名建议:

- `home.png`           首页 Hero
- `conceive-step1.png` 选题材
- `conceive-step3.png` 构思结果卡片
- `studio.png`         写作台
- `settings.png`       设置页
- `logo.svg`           LOGO
