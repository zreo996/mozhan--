# Demo: 武侠 · 沧海剑歌

本目录是 `mozhan` Skill 的最小可运行示例:三章武侠开篇,四表已就绪。

## 目录结构

```
demo_wuxia/
├── README.md
├── data/
│   ├── timeline.json
│   ├── characters_snapshot.json
│   ├── hooks.json
│   ├── inventory.json
│   └── style_fingerprint.json   # 文风印记(~500 token,自动从 masterpiece 抽取)
└── chapters/
    └── chapter_001.txt
```

## 跑通自检流程

```bash
cd E:/迭代SKILL/mozhan

# 1. 连续性强制 (P0/P1 检查)
python core/scripts/continuity_enforcer.py examples/demo_wuxia/data 1 --text examples/demo_wuxia/chapters/chapter_001.txt

# 2. 五重自检 (含 LINT)
python core/scripts/self_check.py 1 --data-dir examples/demo_wuxia/data --text examples/demo_wuxia/chapters/chapter_001.txt --verbose

# 3. 章节质量评分
python core/scripts/quality_score.py 1 --text examples/demo_wuxia/chapters/chapter_001.txt --data-dir examples/demo_wuxia/data

# 4. 题材兼容性
python core/scripts/genre_validator.py wuxia examples/demo_wuxia/chapters/chapter_001.txt --skill-dir .

# 5. 爽点密度
python core/scripts/climax_tracker.py --chapters examples/demo_wuxia/chapters --data-dir examples/demo_wuxia/data

# 6. 写后处理 (回填四表)
python core/scripts/post_process.py examples/demo_wuxia/chapters/chapter_001.txt 1 --data-dir examples/demo_wuxia/data
```

## 与 LLMClient 配合 (需 ANTHROPIC_API_KEY)

```python
from core.scripts.llm_client import LLMClient, load_frozen_from_data
from core.scripts.multi_agent import MultiAgentOrchestrator

client = LLMClient(
    cost_log_path="examples/demo_wuxia/data/cost_log.json",
)
# 自动从 examples/demo_wuxia/data/style_fingerprint.json 读取文风印记
frozen = load_frozen_from_data(
    "examples/demo_wuxia/data",
    worldview_text="武侠世界,门派林立,内力为本。",
)
print("文风印记长度:", len(frozen.style_fingerprint), "字符")

orchestrator = MultiAgentOrchestrator(chapter_level="L2")
orchestrator.register_llm_client(client, frozen=frozen)
results = orchestrator.consult("战斗", {
    "genre": "武侠",
    "period": "黎明",
    "location": "青松剑派",
    "mood": "悲壮",
    "scene_requirements": "师门血洗,主角觉醒逃亡",
    # ...其余 context 字段
})
print(orchestrator.summary())
```

## 文风印记自动注入机制

`data/style_fingerprint.json` 是在 `one_click_writer.py init` 时自动生成的,内容是从 `genres/wuxia/masterpiece_analysis.md` 抽取的:

- 4 本精品流派定位 (《雪中悍刀行》《最强boss系统》《死人经》《催妆》)
- 12 条关键写作技巧 (来自各书"独特手法/关键技巧"小节)
- 主角差异化人设 (诗意型/游戏化型/复仇型/甜宠型)
- 节奏/爽点模板

每次 LLM 调用时,这 ~500 token 与世界观、extra 一起组成冻结前缀,自动走 Prompt Caching(命中率 95%+),无需重复计费。
