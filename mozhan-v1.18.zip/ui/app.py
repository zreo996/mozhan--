"""
ui/app.py — 墨栈 (MoZhan) 的 Web UI

启动:
    python -m ui                       # 默认 http://127.0.0.1:8765
    python -m ui --port 9000           # 自定义端口
    python -m ui --host 0.0.0.0        # 公开访问
    python -m ui --projects-root DIR   # 自定义项目根

支持:
    - Anthropic / OpenAI 兼容 API
    - 12 题材 L1-L4 章节写作
    - 四表查看与编辑
    - 连续性自检 / 质量评分 / 爽点密度
    - 文风印记 (genre_style) 自动加载
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

# 把 core/scripts 加入路径,使 UI 能调用同一仓库的脚本
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "core" / "scripts"))

try:
    from flask import Flask, jsonify, request, send_from_directory, render_template
except ImportError:
    print("缺少 Flask,请运行: pip install flask")
    sys.exit(1)


# ── 数据层 ──────────────────────────────────────────────
def projects_root() -> Path:
    return Path(os.environ.get("MOZHAN_PROJECTS_ROOT",
                                str(ROOT / "projects"))).resolve()


def project_dir(name: str) -> Path:
    p = projects_root() / name
    p.mkdir(parents=True, exist_ok=True)
    (p / "data").mkdir(exist_ok=True)
    (p / "chapters").mkdir(exist_ok=True)
    return p


def skill_dir() -> Path:
    return ROOT


# ── LLM 调用层(Anthropic + OpenAI 兼容) ──────────────
@dataclass
class ChatMessage:
    role: str
    content: str


class LLMBackend:
    """轻量 LLM 客户端 — 支持 Anthropic 与 OpenAI 兼容 API"""

    def __init__(self, config: dict):
        self.provider = config.get("provider", "anthropic").lower()
        self.api_key = config.get("api_key", "")
        self.base_url = config.get("base_url", "").rstrip("/")
        self.model = config.get("model", "claude-sonnet-4-6")
        self.temperature = float(config.get("temperature", 0.7))
        self.max_tokens = int(config.get("max_tokens", 4000))

    def chat(self, system: str, user: str,
             max_tokens: int | None = None) -> dict:
        if not self.api_key:
            return {"ok": False, "error": "未配置 API key"}
        max_tokens = max_tokens or self.max_tokens
        try:
            if self.provider == "anthropic":
                return self._chat_anthropic(system, user, max_tokens)
            else:
                return self._chat_openai(system, user, max_tokens)
        except Exception as e:
            return {"ok": False, "error": f"{type(e).__name__}: {e}"}

    def _chat_anthropic(self, system: str, user: str, max_tokens: int) -> dict:
        import urllib.request
        url = f"{self.base_url or 'https://api.anthropic.com'}/v1/messages"
        headers = {
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        }
        body = {
            "model": self.model,
            "max_tokens": max_tokens,
            "system": system,
            "messages": [{"role": "user", "content": user}],
            "temperature": self.temperature,
        }
        req = urllib.request.Request(url, data=json.dumps(body).encode("utf-8"),
                                     headers=headers, method="POST")
        with urllib.request.urlopen(req, timeout=120) as r:
            data = json.loads(r.read().decode("utf-8"))
        text = ""
        for blk in data.get("content", []):
            if blk.get("type") == "text":
                text += blk.get("text", "")
        return {
            "ok": True,
            "text": text,
            "model": data.get("model", self.model),
            "usage": data.get("usage", {}),
        }

    def _chat_openai(self, system: str, user: str, max_tokens: int) -> dict:
        import urllib.request
        url = f"{self.base_url or 'https://api.openai.com'}/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        body = {
            "model": self.model,
            "max_tokens": max_tokens,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "temperature": self.temperature,
        }
        req = urllib.request.Request(url, data=json.dumps(body).encode("utf-8"),
                                     headers=headers, method="POST")
        with urllib.request.urlopen(req, timeout=120) as r:
            data = json.loads(r.read().decode("utf-8"))
        text = data["choices"][0]["message"]["content"]
        return {
            "ok": True,
            "text": text,
            "model": data.get("model", self.model),
            "usage": data.get("usage", {}),
        }


# ── Prompt 构造 ──────────────────────────────────────────
def build_frozen_system(project: Path, worldview: str = "", platform: str = "") -> str:
    """构造系统提示 — 含世界观 + 文风印记 + 平台规则 + 当前四表摘要"""
    data_dir = project / "data"

    sys.path.insert(0, str(ROOT / "core" / "scripts"))
    try:
        from genre_style import render_style_fingerprint
    except ImportError:
        render_style_fingerprint = None
    try:
        from platform_profiles import render_platform_rules, platform_chapter_word
    except ImportError:
        render_platform_rules = None
        platform_chapter_word = lambda *_: 3000

    parts: list[str] = []
    cfg_path = project / "config.json"
    genre = "wuxia"
    if cfg_path.exists():
        try:
            cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
            genre = cfg.get("genre", genre)
            if not platform:
                platform = cfg.get("platform", "")
        except Exception:
            pass

    if worldview:
        parts.append(f"## 世界观\n{worldview}")

    # 【核心】读 conceived.json — 主角/简介/主题 必须作为锚点注入,否则模型会按模板写
    try:
        cv = json.loads((project / "conceived.json").read_text(encoding="utf-8"))
    except Exception:
        cv = {}
    if cv:
        p = cv.get("protagonist") or {}
        anchors = []
        if p.get("name"):
            anchors.append(f"- 主角名:**{p['name']}**(必须严格使用,不得改名/同音替换)")
        if p.get("identity"):
            anchors.append(f"- 主角身份:{p['identity']}")
        if p.get("motivation"):
            anchors.append(f"- 主角核心动机:{p['motivation']}")
        if p.get("trait"):
            anchors.append(f"- 主角人设标签:{p['trait']}")
        if cv.get("synopsis"):
            anchors.append(f"\n## 全书简介(每章都必须围绕此简介展开,不得偏离)\n{cv['synopsis']}")
        if cv.get("themes"):
            anchors.append(f"\n## 核心主题:{'、'.join(cv['themes'])}")
        if cv.get("title"):
            anchors.append(f"\n## 书名:{cv['title']}")
        if anchors:
            parts.append("## 核心设定(强约束,不得擅自修改)\n" + "\n".join(anchors))

    if render_style_fingerprint:
        try:
            parts.append(render_style_fingerprint(genre, skill_dir()))
        except Exception:
            pass
    if platform and render_platform_rules:
        try:
            parts.append(render_platform_rules(platform))
        except Exception:
            pass

    parts.append("\n## 当前四表快照")
    for name in ("timeline.json", "characters_snapshot.json",
                 "hooks.json", "inventory.json"):
        p = data_dir / name
        if p.exists():
            try:
                obj = json.loads(p.read_text(encoding="utf-8"))
                parts.append(f"### {name}\n{json.dumps(obj, ensure_ascii=False, indent=2)[:3000]}")
            except Exception:
                pass

    # 字数随平台浮动,默认综合 3000
    if platform:
        base = platform_chapter_word(platform)
        word_ranges = f"L1 {int(base*0.7)}-{base} 字, L2 {base}-{int(base*1.3)} 字, L3 {int(base*1.3)}-{int(base*1.7)} 字, L4 {int(base*1.7)} 字以上"
    else:
        word_ranges = "L1 1500-2500 字, L2 2500-3500 字, L3 3500-5000 字, L4 5000 字以上"
    parts.append(f"\n## 写作守则\n- 严格遵守题材红线\n- 保持四表连续性\n- 风格向文风印记看齐\n- 章节字数:{word_ranges}")
    return "\n\n".join(parts)


# ── Flask 应用 ──────────────────────────────────────────
def create_app() -> Flask:
    app = Flask(__name__,
                template_folder=str(Path(__file__).parent / "templates"),
                static_folder=str(Path(__file__).parent / "static"))
    app.config["JSON_AS_ASCII"] = False

    @app.route("/")
    def index():
        return render_template("index.html")

    @app.route("/api/projects", methods=["GET", "POST"])
    def api_projects():
        if request.method == "POST":
            body = request.get_json(force=True, silent=True) or {}
            name = (body.get("name") or "").strip()
            genre = (body.get("genre") or "wuxia").strip()
            platform = (body.get("platform") or "").strip()
            if not name:
                return jsonify({"ok": False, "error": "name 必填"}), 400
            safe = re.sub(r"[\\/:*?\"<>|]", "_", name)
            p = project_dir(safe)
            (p / "config.json").write_text(
                json.dumps({
                    "name": name, "genre": genre, "platform": platform,
                    "created_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
                    "status": "planning",
                }, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            # 复制四表模板
            import shutil
            for tpl in (ROOT / "core" / "templates").glob("*.json"):
                shutil.copy(tpl, p / "data" / tpl.name)
            # 写入文风印记
            try:
                from genre_style import render_style_fingerprint
                fp_text = render_style_fingerprint(genre, skill_dir())
                (p / "data" / "style_fingerprint.json").write_text(
                    json.dumps({
                        "genre": genre, "text": fp_text,
                        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
                    }, ensure_ascii=False, indent=2),
                    encoding="utf-8",
                )
            except Exception as e:
                app.logger.warning(f"style fingerprint 写入失败: {e}")
            return jsonify({"ok": True, "name": safe, "genre": genre})
        # GET 列表
        items = []
        for p in sorted(projects_root().iterdir()):
            if not p.is_dir():
                continue
            cfg = p / "config.json"
            meta = {}
            if cfg.exists():
                try:
                    meta = json.loads(cfg.read_text(encoding="utf-8"))
                except Exception:
                    pass
            items.append({
                "name": p.name,
                "genre": meta.get("genre", "?"),
                "title": meta.get("title") or meta.get("name", p.name),
                "status": meta.get("status", "?"),
            })
        return jsonify({"ok": True, "projects": items, "root": str(projects_root())})

    @app.route("/api/projects/<name>", methods=["GET", "DELETE"])
    def api_project(name):
        p = projects_root() / name
        if not p.exists():
            return jsonify({"ok": False, "error": "项目不存在"}), 404
        if request.method == "DELETE":
            import shutil
            shutil.rmtree(p)
            return jsonify({"ok": True})
        # GET: 返回项目配置 + 四表
        cfg = {}
        if (p / "config.json").exists():
            cfg = json.loads((p / "config.json").read_text(encoding="utf-8"))
        tables = {}
        for tname in ("timeline.json", "characters_snapshot.json",
                      "hooks.json", "inventory.json", "style_fingerprint.json"):
            tp = p / "data" / tname
            if tp.exists():
                try:
                    tables[tname] = json.loads(tp.read_text(encoding="utf-8"))
                except Exception:
                    tables[tname] = None
        chapters = sorted((p / "chapters").glob("*.txt"))
        return jsonify({
            "ok": True,
            "config": cfg,
            "tables": tables,
            "chapters": [c.name for c in chapters],
        })

    @app.route("/api/projects/<name>/table/<table>", methods=["GET", "PUT"])
    def api_table(name, table):
        p = projects_root() / name / "data" / table
        if request.method == "PUT":
            body = request.get_json(force=True, silent=True) or {}
            p.write_text(json.dumps(body, ensure_ascii=False, indent=2),
                         encoding="utf-8")
            return jsonify({"ok": True})
        if not p.exists():
            return jsonify({"ok": False, "error": "表不存在"}), 404
        return jsonify({"ok": True, "data": json.loads(p.read_text(encoding="utf-8"))})

    @app.route("/api/projects/<name>/chapter/<int:num>", methods=["GET", "PUT", "DELETE"])
    def api_chapter(name, num):
        p = projects_root() / name / "chapters" / f"chapter_{num:03d}.txt"
        if request.method == "DELETE":
            if p.exists():
                p.unlink()
            return jsonify({"ok": True})
        if request.method == "PUT":
            body = request.get_json(force=True, silent=True) or {}
            content = body.get("content", "")
            p.write_text(content, encoding="utf-8")
            # 触发后处理
            try:
                from post_process import PostProcessor
                PostProcessor(str(projects_root() / name / "data"), num).process(str(p))
            except Exception as e:
                app.logger.warning(f"post_process 失败: {e}")
            return jsonify({"ok": True})
        if not p.exists():
            return jsonify({"ok": False, "error": "章节不存在"}), 404
        return jsonify({"ok": True, "content": p.read_text(encoding="utf-8")})

    @app.route("/api/projects/<name>/write", methods=["POST"])
    def api_write(name):
        body = request.get_json(force=True, silent=True) or {}
        llm_cfg = body.get("llm") or {}
        chapter_num = int(body.get("chapter", 1))
        level = body.get("level", "L2")
        outline = body.get("outline", "")
        worldview = body.get("worldview", "")
        platform = body.get("platform", "")
        p = projects_root() / name
        if not p.exists():
            return jsonify({"ok": False, "error": "项目不存在"}), 404

        # 读 config 中的 platform
        if not platform and (p / "config.json").exists():
            try:
                cfg = json.loads((p / "config.json").read_text(encoding="utf-8"))
                platform = cfg.get("platform", "")
            except Exception:
                pass

        backend = LLMBackend(llm_cfg)
        system = build_frozen_system(p, worldview, platform)
        # 字数: 平台基准 × 等级系数
        if platform:
            try:
                from platform_profiles import platform_chapter_word
                base = platform_chapter_word(platform)
            except Exception:
                base = 3000
        else:
            base = 3000
        scale = {"L1": 0.7, "L2": 1.0, "L3": 1.3, "L4": 1.7}.get(level, 1.0)
        word_target = int(base * scale)

        # 若 outline 为空,自动从 outline_full.json 拉该章的钩子
        if not outline:
            op = p / "data" / "outline_full.json"
            if op.exists():
                try:
                    full = json.loads(op.read_text(encoding="utf-8"))
                    for ch in (full.get("outline") or []):
                        if int(ch.get("num", -1)) == chapter_num:
                            outline = f"【章名】{ch.get('title','')}\n【本章核心钩子】{ch.get('hook','')}"
                            break
                except Exception:
                    pass

        user = f"""# 任务
请写第 {chapter_num} 章,等级 {level},目标字数 {word_target}。

# 【保真硬约束 — 最高优先级】
1. 主角名、人名、地名、组织名、物品名**严格沿用项目设定**(`conceived.json` 与 `outline_full.json` 内的命名),不得替换为常见的网文套名(如"李轩/林北/楚风"等)。
2. 章节内容必须紧扣简介的设定与主题,不得出现与简介矛盾的人物、动机、背景。
3. 若项目无具体人名,方可按题材自由命名。

# 本章大纲
{outline or '(未提供大纲,请基于四表与文风自行展开)'}

# 输出要求
- 严格遵守文风印记的语言特征与流派
- 不出现 P0 红线(时间倒序/位置漂移/修为倒退/伏笔丢失/物品消失)
- 章末留钩子(悬念/反转/共鸣)
- 直接输出章节正文,不要任何 meta 说明"""
        result = backend.chat(system, user, max_tokens=word_target * 3 + 500)
        if not result["ok"]:
            return jsonify(result), 500
        text = result["text"]
        # 写文件
        chapter_path = p / "chapters" / f"chapter_{chapter_num:03d}.txt"
        chapter_path.write_text(text, encoding="utf-8")
        # 后处理
        try:
            from post_process import PostProcessor
            PostProcessor(str(p / "data"), chapter_num).process(str(chapter_path))
        except Exception as e:
            app.logger.warning(f"post_process 失败: {e}")
        return jsonify({
            "ok": True,
            "text": text,
            "model": result.get("model"),
            "usage": result.get("usage", {}),
        })

    @app.route("/api/projects/<name>/check", methods=["POST"])
    def api_check(name):
        body = request.get_json(force=True, silent=True) or {}
        chapter_num = int(body.get("chapter", 1))
        p = projects_root() / name
        ch_path = p / "chapters" / f"chapter_{chapter_num:03d}.txt"
        chapter_text = ch_path.read_text(encoding="utf-8") if ch_path.exists() else ""
        try:
            from self_check import SelfChecker
            checker = SelfChecker(str(p / "data"), chapter_num)
            report = checker.run(chapter_text, verbose=False, silent=True)
            return jsonify({"ok": True, "report": report})
        except Exception as e:
            return jsonify({"ok": False, "error": f"自检失败: {e}"}), 500

    @app.route("/api/projects/<name>/score", methods=["POST"])
    def api_score(name):
        body = request.get_json(force=True, silent=True) or {}
        chapter_num = int(body.get("chapter", 1))
        p = projects_root() / name
        ch_path = p / "chapters" / f"chapter_{chapter_num:03d}.txt"
        if not ch_path.exists():
            return jsonify({"ok": False, "error": "章节不存在"}), 404
        try:
            from quality_score import QualityScorer
            scorer = QualityScorer(chapter_num)
            result = scorer.assess(ch_path.read_text(encoding="utf-8"),
                                   data_dir=str(p / "data"))
            return jsonify({"ok": True, "result": result})
        except Exception as e:
            return jsonify({"ok": False, "error": f"评分失败: {e}"}), 500

    @app.route("/api/projects/<name>/climax", methods=["GET"])
    def api_climax(name):
        p = projects_root() / name
        chap_dir = p / "chapters"
        try:
            from climax_tracker import ClimaxTracker
            tracker = ClimaxTracker(chap_dir)
            report = tracker.report()
            return jsonify({"ok": True, "report": report.to_dict()})
        except Exception as e:
            return jsonify({"ok": False, "error": f"爽点分析失败: {e}"}), 500

    @app.route("/api/genre/<genre>/style", methods=["GET"])
    def api_genre_style(genre):
        try:
            from genre_style import render_style_fingerprint
            text = render_style_fingerprint(genre, skill_dir())
            return jsonify({"ok": True, "text": text})
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 500

    @app.route("/api/genre/<genre>/seeds", methods=["GET"])
    def api_genre_seeds(genre):
        """返回该题材的种子点子(用于第 2 步 chip 快速填充)"""
        try:
            from genre_style import get_genre_seeds
            seeds = get_genre_seeds(genre)
            return jsonify({"ok": True, "genre": genre, "seeds": seeds})
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 500

    @app.route("/api/platforms", methods=["GET"])
    def api_platforms():
        """返回 9 大平台档案,供 UI 第 1 步选择使用"""
        try:
            from platform_profiles import list_platforms
            return jsonify({"ok": True, "platforms": list_platforms()})
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 500

    @app.route("/api/genres", methods=["GET"])
    def api_genres():
        try:
            from genre_style import list_supported_genres
            gs = list_supported_genres(skill_dir())
            return jsonify({"ok": True, "genres": gs})
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 500

    @app.route("/api/conceive", methods=["POST"])
    def api_conceive():
        """四步向导第三/四步:由 idea + genre + platform + total 范围生成 全书构想。"""
        body = request.get_json(force=True, silent=True) or {}
        llm_cfg = body.get("llm") or {}
        genre = (body.get("genre") or "wuxia").strip()
        platform = (body.get("platform") or "").strip()
        idea = (body.get("idea") or "").strip()
        total_words = int(body.get("total_words") or 0)
        total_chapters = int(body.get("total_chapters") or 0)
        if not idea:
            return jsonify({"ok": False, "error": "请先写下你的想法"}), 400
        if not total_chapters:
            return jsonify({"ok": False, "error": "请填写全本章节数"}), 400
        if not total_words:
            return jsonify({"ok": False, "error": "请填写全本总字数"}), 400

        # 1. 文风印记
        try:
            from genre_style import render_style_fingerprint
            fp = render_style_fingerprint(genre, skill_dir())
        except Exception:
            fp = ""

        # 2. 题材世界观(摘 worldbuilding.md 的前 2000 字)
        world_summary = ""
        try:
            wb_path = skill_dir() / "genres" / genre / "worldbuilding.md"
            if wb_path.exists():
                world_summary = wb_path.read_text(encoding="utf-8")[:2000]
        except Exception:
            pass

        # 3. 题材红线
        red_summary = ""
        try:
            red_path = skill_dir() / "genres" / genre / "red_lines.md"
            if red_path.exists():
                red_summary = red_path.read_text(encoding="utf-8")[:800]
        except Exception:
            pass

        # 4. 平台规则
        platform_block = ""
        try:
            from platform_profiles import render_platform_rules
            platform_block = render_platform_rules(platform) if platform else ""
        except Exception:
            pass

        # 5. 算卷数:每卷 30-50 章合适
        arc_count = max(3, round(total_chapters / 35))
        if total_chapters < 80:
            arc_count = 3
        elif total_chapters < 200:
            arc_count = max(3, total_chapters // 40)
        else:
            arc_count = max(4, total_chapters // 50)

        # 字数 / 章
        avg_words_per_chap = max(800, total_words // total_chapters)

        system = f"""你是「墨栈」中文长篇小说策划助手。任务:根据作者的原始想法、所选平台、所选总字数与总章节数,产出一本**完整可落地**的网文构思 —— 包括书名/简介/主角/**全卷全章大纲**。

# 【最优先原则:题材 > 想法】
作者所选的题材「{genre}」是顶层约束。如果作者的「想法」文本里包含与该题材的世界观冲突的元素,你必须以题材的世界规则为权威,把"想法"重新诠释为该题材下的合理设定,而不是顺着想法生成其他题材的内容。
具体方法:把与题材冲突的关键名词替换为该题材内可识别的等价物(例如:"激光剑"在武侠里可改写为"剑气");在简介里自然交代这次"替换",让设定显得自洽。

# 【次优先原则:平台 > 题材的次要表达】
即便题材是「{genre}」,所选平台的调性也必须直接体现到书名套路、简介节奏、章节字数、大纲骨架上。

# 【总规模约束(必须严格遵守)】
- 全书总字数:{total_words} 字(约)
- 全书总章节:{total_chapters} 章
- 平均每章:{avg_words_per_chap} 字
- 计划卷数:**{arc_count} 卷**(每卷 {max(20, total_chapters // arc_count)}-{total_chapters // (arc_count-1) if arc_count>1 else total_chapters} 章)

# 【保真硬约束 — 最高优先级】
1. 作者在「原始想法」中提及的所有专有名词(人名、地名、组织名、物品名)必须**原样使用**,不得替换为常见的网文套名(李轩/林北/楚风/叶辰 等)。例如:想法里写"主角叫陆沉",主角就必须叫陆沉。
2. 主角身份、核心动机、故事背景必须紧扣作者的「原始想法」,不要改写成套路化的"废柴逆袭/天才归来"模板。
3. 简介里的人物、势力、地点、事件要与想法保持一致,不得自创"想法里没提"的新主角或新背景。

{fp}

## 该题材世界规则摘要
{world_summary or "(未找到 worldbuilding.md,按文风印记与一般常识处理)"}

## 该题材硬红线(P0)
{red_summary or "(未找到 red_lines.md)"}

{platform_block or "(未选择发布平台,按综合调性处理;书名以可读性优先,简介 200-300 字)"}

# 输出格式(严格遵守)
必须输出一段 JSON,不要任何解释、不要 markdown 围栏。键固定为:
{{
  "title": "书名(4-8 字,有题材辨识度)",
  "subtitle": "副标题/slogan(可选,≤20 字)",
  "synopsis": "简介(200-400 字),带钩子",
  "total_words": {total_words},
  "total_chapters": {total_chapters},
  "protagonist": {{
    "name": "主角名",
    "age": 数字,
    "identity": "身份背景",
    "motivation": "核心动机",
    "trait": "核心人设标签"
  }},
  "themes": ["主题词1", "主题词2", "主题词3"],
  "arcs": [
    {{
      "num": 1,
      "name": "第一卷·开篇(建议章数)",
      "chapters_range": "1-30",
      "theme": "本卷核心命题",
      "key_events": ["本卷关键事件 1", "本卷关键事件 2", "本卷关键事件 3"]
    }}
    /* 严格共 {arc_count} 卷 */
  ],
  "outline": [
    /* 共 {total_chapters} 项,每项一章,严格按章号 1..{total_chapters} */
    {{"num": 1, "title": "第 1 章 标题", "hook": "本章核心钩子(≤30字)"}},
    {{"num": 2, "title": "第 2 章 标题", "hook": "本章核心钩子(≤30字)"}},
    /* ... 一直列到第 {total_chapters} 章 ... */
  ]
}}

# 严格要求
1. **arcs 数组必须恰好 {arc_count} 个**,每卷覆盖的章数总和 = {total_chapters}
2. **outline 数组必须恰好 {total_chapters} 个**,章号 1..{total_chapters} 严格连续,不能跳号
3. 每章 hook 必须**与上一章形成衔接**(上一章末尾埋的钩子,要在本章内兑现或继续加深)
4. 每章 title 须符合平台调性;按平台字数 {avg_words_per_chap} 字
5. 大事件节点(主角第一次大胜/第一次重大挫败/转折/高潮)必须按题材红线和读者预期出现
6. 严格按 JSON schema 输出,不要任何附加说明
"""
        user = f"""# 题材
{genre}

# 作者的原始想法
{idea}

# 全书规模
总字数 {total_words} 字 · 总章节 {total_chapters} 章 · 平均 {avg_words_per_chap} 字/章 · 共 {arc_count} 卷

# 要求
- 紧扣题材文风印记与平台调性
- 主角动机要鲜明、不烂俗
- 简介必须留两个以上钩子
- 大事件节点必须按题材预期节奏出现
- arcs 严格 {arc_count} 卷,outline 严格 {total_chapters} 章,逐章不可跳号
- 严格按 JSON schema 输出,不要任何附加说明"""

        # 8K-300K 字通常 outline 1-300 章;按总章节数算 max_tokens(每章 ~80 token)
        out_tokens = min(16000, 1500 + total_chapters * 80)

        backend = LLMBackend(llm_cfg)
        result = backend.chat(system, user, max_tokens=out_tokens)
        if not result["ok"]:
            # 客户端配置错(无 key / 无效 endpoint)不算服务端故障,返 200 + ok:false
            return jsonify(result), 200

        text = (result.get("text") or "").strip()
        # 去除可能的 ```json 围栏
        if text.startswith("```"):
            text = re.sub(r"^```(?:json)?\s*", "", text)
            text = re.sub(r"\s*```\s*$", "", text)
        try:
            conceived = json.loads(text)
        except Exception as e:
            return jsonify({"ok": False, "error": f"模型未按 JSON 返回: {e}", "raw": text}), 500

        return jsonify({
            "ok": True,
            "genre": genre,
            "conceived": conceived,
            "model": result.get("model"),
            "usage": result.get("usage", {}),
        })

    @app.route("/api/projects/<name>/conceived", methods=["GET", "PUT"])
    def api_conceived(name):
        """读写已落库的构思方案(写入 config.json 同目录的 conceived.json)。"""
        p = projects_root() / name
        if not p.exists():
            return jsonify({"ok": False, "error": "项目不存在"}), 404
        cp = p / "conceived.json"
        if request.method == "PUT":
            body = request.get_json(force=True, silent=True) or {}
            cp.write_text(json.dumps(body, ensure_ascii=False, indent=2), encoding="utf-8")
            # 同步更新 config.json 的 title
            cfg_path = p / "config.json"
            if cfg_path.exists() and body.get("title"):
                cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
                cfg["title"] = body["title"]
                cfg["status"] = "writing"
                cfg_path.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
            return jsonify({"ok": True})
        if not cp.exists():
            return jsonify({"ok": True, "data": None})
        return jsonify({"ok": True, "data": json.loads(cp.read_text(encoding="utf-8"))})

    @app.route("/api/projects/<name>/outline_full", methods=["GET", "PUT"])
    def api_outline_full(name):
        """读写「全卷全章大纲」(写到 data/outline_full.json)。"""
        p = projects_root() / name
        if not p.exists():
            return jsonify({"ok": False, "error": "项目不存在"}), 404
        op = p / "data" / "outline_full.json"
        if request.method == "PUT":
            body = request.get_json(force=True, silent=True) or {}
            op.parent.mkdir(parents=True, exist_ok=True)
            op.write_text(json.dumps(body, ensure_ascii=False, indent=2), encoding="utf-8")
            return jsonify({"ok": True, "saved_chapters": len(body.get("outline") or [])})
        if not op.exists():
            return jsonify({"ok": True, "data": None})
        return jsonify({"ok": True, "data": json.loads(op.read_text(encoding="utf-8"))})

    @app.route("/api/projects/<name>/chapter/<int:num>/blueprint", methods=["GET"])
    def api_chapter_blueprint(name, num):
        """返回第 N 章的章纲(title + hook),供写作时回填「本章大纲」框"""
        p = projects_root() / name
        if not p.exists():
            return jsonify({"ok": False, "error": "项目不存在"}), 404
        op = p / "data" / "outline_full.json"
        if not op.exists():
            return jsonify({"ok": False, "error": "尚无全书大纲,请先在构思向导完成全章大纲"}), 404
        try:
            data = json.loads(op.read_text(encoding="utf-8"))
        except Exception as e:
            return jsonify({"ok": False, "error": f"大纲解析失败: {e}"}), 500
        outline = data.get("outline") or []
        for ch in outline:
            if int(ch.get("num", -1)) == num:
                return jsonify({"ok": True, "blueprint": ch,
                                "chapter_text": f"【章名】{ch.get('title','')}\n【本章核心钩子】{ch.get('hook','')}"})
        return jsonify({"ok": False, "error": f"第 {num} 章不在大纲中"}), 404

    @app.route("/api/projects/<name>/chapter/<int:num>/consistency", methods=["GET"])
    def api_chapter_consistency(name, num):
        """检查章节与 conceived / outline 的一致性:
        - 主角名是否在章节里出现
        - 大纲里该章的 hook 关键词是否在章节里出现
        - 简短的「主题漂移」提示
        """
        p = projects_root() / name
        if not p.exists():
            return jsonify({"ok": False, "error": "项目不存在"}), 404
        ch_path = p / "chapters" / f"chapter_{num:03d}.txt"
        if not ch_path.exists():
            return jsonify({"ok": False, "error": "章节不存在"}), 404
        text = ch_path.read_text(encoding="utf-8")

        try:
            cv = json.loads((p / "conceived.json").read_text(encoding="utf-8"))
        except Exception:
            cv = {}
        try:
            full = json.loads((p / "data" / "outline_full.json").read_text(encoding="utf-8"))
        except Exception:
            full = {}

        p_name = (cv.get("protagonist") or {}).get("name", "")
        p_id   = (cv.get("protagonist") or {}).get("identity", "")
        synopsis = cv.get("synopsis", "")
        hook = ""
        for ch in (full.get("outline") or []):
            if int(ch.get("num", -1)) == num:
                hook = ch.get("hook", "")
                break

        issues = []
        if p_name and p_name not in text:
            issues.append({
                "level": "P1",
                "type": "protagonist_missing",
                "message": f"章节中未出现主角名「{p_name}」,可能被改写或漏写",
            })
        if p_id and p_id and p_id not in text:
            issues.append({
                "level": "P2",
                "type": "identity_missing",
                "message": f"章节中未提及主角身份「{p_id}」,需检查是否偏离简介",
            })
        if hook:
            # 抽取 hook 中最显著的 2-3 个名词
            import re
            kws = [w for w in re.split(r"[的,是,在,与,和,和,或,了,着,过,了,把,被]", hook) if 1 < len(w) <= 6][:3]
            missing = [k for k in kws if k and k not in text]
            if missing:
                issues.append({
                    "level": "P2",
                    "type": "hook_keywords_missing",
                    "message": f"大纲钩子的关键词 {missing} 在章节中未出现,可能跑题",
                })
        return jsonify({
            "ok": True,
            "protagonist_name": p_name,
            "synopsis_anchor": synopsis[:120],
            "hook": hook,
            "issues": issues,
            "pass": not any(i["level"] == "P1" for i in issues),
        })

    @app.route("/api/brand", methods=["GET"])
    def api_brand():
        """返回品牌元信息(给前端读出来,改名只在一处)。"""
        return jsonify({
            "ok": True,
            "name_cn": "墨栈",
            "name_en": "MoZhan",
            "tagline": "一栈写尽万千江湖",
            "version": "v1.16",
        })

    return app


def main():
    ap = argparse.ArgumentParser(description="墨栈 MoZhan Web UI")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--projects-root", default=None,
                    help="项目根目录(默认 ./projects)")
    ap.add_argument("--debug", action="store_true")
    args = ap.parse_args()
    if args.projects_root:
        os.environ["MOZHAN_PROJECTS_ROOT"] = args.projects_root
    app = create_app()
    print(f"\n  墨栈 · 全题材中文小说创作系统  Web UI")
    print(f"  访问:  http://{args.host}:{args.port}")
    print(f"  项目根: {projects_root()}\n")
    app.run(host=args.host, port=args.port, debug=args.debug)


if __name__ == "__main__":
    main()
