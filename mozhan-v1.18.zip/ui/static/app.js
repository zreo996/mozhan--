﻿/* 墨栈 · Web UI v1.16 */
const $  = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => r.querySelectorAll(s);

const GENRE_META = {
  fantasy:    { emoji: "⚔",  cn: "玄幻",   en: "Fantasy" },
  urban:      { emoji: "🏙",  cn: "都市",   en: "Urban" },
  scifi:      { emoji: "🚀",  cn: "科幻",   en: "Sci-Fi" },
  wuxia:      { emoji: "🗡",  cn: "武侠",   en: "Wuxia" },
  historical: { emoji: "🏯",  cn: "历史",   en: "Historical" },
  game:       { emoji: "🎮",  cn: "游戏",   en: "Game" },
  apocalypse: { emoji: "☢",  cn: "末世",   en: "Apocalypse" },
  superpower: { emoji: "✨",  cn: "异能",   en: "Superpower" },
  mystery:    { emoji: "🕯",  cn: "悬疑",   en: "Mystery" },
  romance:    { emoji: "🌸",  cn: "甜宠",   en: "Romance" },
  fanfiction: { emoji: "📖",  cn: "同人",   en: "Fanfiction" },
  isekai:     { emoji: "🌀",  cn: "快穿",   en: "Isekai" },
};

const state = {
  page: "home",
  currentProject: null,
  conceive: { genre: null, platform: "", idea: "", total_words: 1000000, total_chapters: 300, result: null },
  llm: JSON.parse(localStorage.getItem("mozhan_llm") || "null") || {
    provider: "anthropic",
    api_key: "",
    base_url: "",
    model: "claude-opus-4-7",
    temperature: 0.7,
    max_tokens: 8000,
  },
};

/* ───────── 通用工具 ───────── */
async function api(path, opts = {}) {
  const init = { method: opts.method || "GET", headers: { "Content-Type": "application/json" } };
  if (opts.body) init.body = JSON.stringify(opts.body);
  const r = await fetch(path, init);
  const j = await r.json().catch(() => ({ ok: false, error: "响应非 JSON" }));
  return j;
}

function toast(msg, kind = "") {
  const el = $("#toast");
  el.textContent = msg;
  el.className = "toast " + kind;
  el.hidden = false;
  clearTimeout(toast._t);
  toast._t = setTimeout(() => { el.hidden = true; }, 2400);
}

function setPage(name) {
  state.page = name;
  $$(".page").forEach(p => p.hidden = (p.dataset.page !== name));
  $$(".nav-link").forEach(a => a.classList.toggle("active", a.dataset.page === name));
  if (name === "home")     renderHome();
  if (name === "conceive") enterConceive();
  if (name === "studio")   renderStudioList();
  if (name === "settings") fillSettings();
}

/* ───────── 首页 ───────── */
async function renderHome() {
  const wrap = $("#home-project-list");
  wrap.textContent = "加载中…";
  const j = await api("/api/projects");
  if (!j.ok) { wrap.textContent = "加载失败:" + j.error; return; }
  if (!j.projects.length) {
    wrap.innerHTML = `<p class="muted">尚无作品。点击「开始构思新书」创建你的第一本。</p>`;
    return;
  }
  wrap.innerHTML = "";
  for (const p of j.projects) {
    const m = GENRE_META[p.genre] || { emoji: "📚", cn: p.genre, en: "" };
    const card = document.createElement("div");
    card.className = "project-card";
    card.innerHTML = `
      <div class="pc-title">${m.emoji} ${p.title || p.name}</div>
      <div class="pc-meta">
        <span class="pc-genre">${m.cn}</span>
        <span>${p.status}</span>
      </div>`;
    card.onclick = () => { state.currentProject = p.name; setPage("studio"); setTimeout(() => loadProject(p.name), 80); };
    wrap.appendChild(card);
  }
}

/* ───────── 三步向导 ───────── */
function enterConceive() {
  showStep(1);
  loadGenres();
  loadPlatforms();
}

function showStep(n) {
  $$(".step").forEach(s => s.classList.toggle("active", +s.dataset.step === n));
  for (let i = 1; i <= 3; i++) {
    $(`.step[data-step="${i}"]`)?.classList.toggle("done", i < n);
  }
  $$(".step-panel").forEach(p => p.hidden = (+p.dataset.step !== n));
}

async function loadGenres() {
  const grid = $("#genre-grid");
  grid.textContent = "加载中…";
  const j = await api("/api/genres");
  if (!j.ok) { grid.textContent = "加载失败"; return; }
  grid.innerHTML = "";
  for (const g of j.genres) {
    const m = GENRE_META[g] || { emoji: "📚", cn: g, en: "" };
    const card = document.createElement("div");
    card.className = "genre-card";
    card.dataset.genre = g;
    card.innerHTML = `
      <div class="gc-emoji">${m.emoji}</div>
      <div class="gc-name">${m.cn}</div>
      <div class="gc-en" title="英文名作国际化后备">${m.en}</div>`; // 极弱化显示;主展示为中文名
    card.onclick = () => {
      $$(".genre-card").forEach(c => c.classList.remove("selected"));
      card.classList.add("selected");
      state.conceive.genre = g;
      $("#genre-pick-hint").textContent = `已选:${m.cn}`;
      $("#to-step-2").disabled = false;
    };
    grid.appendChild(card);
  }
}

async function loadPlatforms() {
  const grid = $("#platform-grid");
  if (!grid) return;
  grid.textContent = "加载中…";
  const j = await api("/api/platforms");
  if (!j.ok) { grid.textContent = "加载失败:" + j.error; return; }
  grid.innerHTML = "";
  // 「综合(不指定)」选项,默认选中
  const none = document.createElement("div");
  none.className = "platform-card selected";
  none.innerHTML = `
    <div class="pl-head"><span class="pl-logo">📚</span><span>综合(不指定)</span></div>
    <div class="pl-tip">不绑定具体平台,墨栈按通用调性平衡书名与简介。</div>
    <div class="pl-meta">~3000 字/章</div>`;
  none.onclick = () => {
    $$(".platform-card").forEach(c => c.classList.remove("selected"));
    none.classList.add("selected");
    state.conceive.platform = "";
  };
  grid.appendChild(none);

  for (const p of j.platforms) {
    const c = document.createElement("div");
    c.className = "platform-card";
    c.innerHTML = `
      <div class="pl-head"><span class="pl-logo">${p.logo}</span><span>${p.name_cn}</span></div>
      <div class="pl-tip">${p.tip}</div>
      <div class="pl-meta">~${p.chapter_word} 字/章 · 亲和:${(p.genre_fit||[]).slice(0,3).join('/')}</div>`;
    c.onclick = () => {
      $$(".platform-card").forEach(x => x.classList.remove("selected"));
      c.classList.add("selected");
      state.conceive.platform = p.id;
    };
    grid.appendChild(c);
  }
}

$("#to-step-2")?.addEventListener("click", () => {
  if (!state.conceive.genre) return toast("请先选题材", "error");
  loadSeedsForGenre(state.conceive.genre);
  showStep(2);
});

$("#to-step-3")?.addEventListener("click", () => {
  const idea = $("#idea-input").value.trim();
  if (!idea) return toast("请先写下你的想法", "error");
  state.conceive.idea = idea;
  showStep(3);
  updatePlanSummary();
});

async function loadSeedsForGenre(genre) {
  const wrap = $("#idea-seeds");
  wrap.textContent = "载入中…";
  const j = await api(`/api/genre/${genre}/seeds`);
  if (!j.ok) { wrap.textContent = "载入失败:" + j.error; return; }
  if (!j.seeds || !j.seeds.length) {
    wrap.innerHTML = `<p class="muted" style="margin:0">该题材暂未配置种子点子,直接手写即可。</p>`;
    return;
  }
  wrap.innerHTML = "";
  for (const s of j.seeds) {
    const b = document.createElement("button");
    b.className = "chip";
    b.dataset.idea = s.idea;
    b.textContent = s.tag;
    b.title = s.idea;
    wrap.appendChild(b);
  }
}

function updatePlanSummary() {
  const w = +$("#r-total-words").value || 0;
  const c = +$("#r-total-chapters").value || 0;
  state.conceive.total_words = w;
  state.conceive.total_chapters = c;
  $("#plan-chap").textContent  = c;
  $("#plan-words").textContent = c ? Math.round(w / c).toLocaleString() : "—";
  let arcs = 3;
  if (c < 80) arcs = 3;
  else if (c < 200) arcs = Math.max(3, Math.round(c / 40));
  else arcs = Math.max(4, Math.round(c / 50));
  $("#plan-arcs").textContent = arcs;
}

["r-total-words","r-total-chapters"].forEach(id => {
  document.addEventListener("input", e => {
    if (e.target.id === id) updatePlanSummary();
  });
});

document.addEventListener("click", e => {
  const p = e.target.closest(".chip.preset");
  if (!p) return;
  $("#r-total-words").value    = p.dataset.w;
  $("#r-total-chapters").value = p.dataset.c;
  updatePlanSummary();
});

$("#back-to-step-1")?.addEventListener("click", () => showStep(1));
$("#back-to-step-2")?.addEventListener("click", () => showStep(2));
$("#back-to-step-3")?.addEventListener("click", () => showStep(3));

document.addEventListener("click", e => {
  const c = e.target.closest(".chip");
  if (!c || !c.dataset.idea) return;
  $("#idea-input").value = c.dataset.idea;
});

$("#run-conceive")?.addEventListener("click", async () => {
  if (!state.llm.api_key) { setPage("settings"); return toast("请先在「设置」填 API Key", "error"); }
  // 强制把当前输入框值落到 state(用户可能没触发 input 事件)
  updatePlanSummary();
  if (!state.conceive.genre) { setPage("conceive"); showStep(1); return toast("请先选题材", "error"); }
  if (!state.conceive.idea)  { showStep(2); return toast("请先写下你的想法", "error"); }
  if (!state.conceive.total_words || state.conceive.total_words < 10000)
    return toast("总字数至少 1 万", "error");
  if (!state.conceive.total_chapters || state.conceive.total_chapters < 5)
    return toast("总章节至少 5 章", "error");
  showStep(4);
  $("#conceive-chap-count").textContent = state.conceive.total_chapters;
  $("#conceive-loading").hidden = false;
  $("#conceive-result").hidden = true;
  const btn = $("#run-conceive"); btn.disabled = true;
  try {
    const j = await api("/api/conceive", {
      method: "POST",
      body: {
        genre: state.conceive.genre,
        platform: state.conceive.platform,
        idea: state.conceive.idea,
        total_words: state.conceive.total_words,
        total_chapters: state.conceive.total_chapters,
        llm: state.llm,
      },
    });
    if (!j.ok) {
      toast("构思失败:" + (j.error || "未知错误"), "error");
      showStep(3);
      return;
    }
    state.conceive.result = j.conceived;
    renderConceiveResult(j.conceived);
  } finally {
    btn.disabled = false;
    $("#conceive-loading").hidden = true;
  }
});

$("#reconceive")?.addEventListener("click", () => $("#run-conceive").click());

function renderConceiveResult(c) {
  $("#conceive-result").hidden = false;
  $("#r-title").value    = c.title || "";
  $("#r-subtitle").value = c.subtitle || "";
  $("#r-synopsis").value = c.synopsis || "";
  const p = c.protagonist || {};
  $("#r-pname").value  = p.name || "";
  $("#r-page").value   = p.age  || "";
  $("#r-pid").value    = p.identity || "";
  $("#r-ptrait").value = p.trait || "";
  $("#r-pmotive").value= p.motivation || "";
  $("#r-themes").value = (c.themes || []).join("、");

  // 1. 分卷大纲
  const arcs = $("#r-arcs"); arcs.innerHTML = "";
  const arcsList = c.arcs || [];
  $("#r-arcs-count").textContent = arcsList.length;
  for (const a of arcsList) {
    const d = document.createElement("div");
    d.className = "arc-item";
    const events = (a.key_events || []).map(e => `<li>${e}</li>`).join("");
    d.innerHTML = `<span class="an">第 ${a.num} 卷 · ${a.name}</span>
                   <span class="ar">${a.chapters_range || ""}</span>
                   <div class="at">${a.theme || ""}</div>
                   <ul class="ae">${events}</ul>`;
    arcs.appendChild(d);
  }

  // 2. 完整章纲(默认渲染全部,支持搜索过滤)
  const out = $("#r-outline"); out.innerHTML = "";
  const all = c.outline || [];
  $("#r-outline-count").textContent = all.length;
  state.conceive.outline = all;
  function paintOutlines(rows) {
    out.innerHTML = "";
    for (const ch of rows) {
      const r = document.createElement("div");
      r.className = "outline-row";
      r.innerHTML = `<div class="onum">${ch.num}</div>
                     <div>
                       <div class="otit">${ch.title || ""}</div>
                       <div class="ohk">钩子:${ch.hook || ""}</div>
                     </div>`;
      out.appendChild(r);
    }
    $("#outline-filter-count").textContent = `共 ${rows.length} 章`;
  }
  paintOutlines(all);
  $("#outline-filter").oninput = e => {
    const q = e.target.value.trim().toLowerCase();
    if (!q) return paintOutlines(all);
    paintOutlines(all.filter(ch =>
      String(ch.num).includes(q) ||
      (ch.title || "").toLowerCase().includes(q) ||
      (ch.hook  || "").toLowerCase().includes(q)
    ));
  };
}

$("#create-project")?.addEventListener("click", async () => {
  const title = $("#r-title").value.trim();
  if (!title) return toast("请填写书名", "error");
  const safeName = title.replace(/[\\/:*?"<>|]/g, "_");
  const createRes = await api("/api/projects", {
    method: "POST",
    body: { name: safeName, genre: state.conceive.genre, platform: state.conceive.platform },
  });
  if (!createRes.ok) return toast("建立项目失败:" + createRes.error, "error");

  const conceived = {
    title, subtitle: $("#r-subtitle").value, synopsis: $("#r-synopsis").value,
    total_words: state.conceive.total_words,
    total_chapters: state.conceive.total_chapters,
    protagonist: {
      name: $("#r-pname").value, age: +$("#r-page").value || 0,
      identity: $("#r-pid").value, trait: $("#r-ptrait").value,
      motivation: $("#r-pmotive").value,
    },
    themes: $("#r-themes").value.split(/[、,，]/).map(s => s.trim()).filter(Boolean),
    arcs: state.conceive.result?.arcs || [],
    outline: state.conceive.result?.outline || [],
    idea: state.conceive.idea,
    genre: state.conceive.genre,
    platform: state.conceive.platform,
  };
  await api(`/api/projects/${encodeURIComponent(createRes.name)}/conceived`, {
    method: "PUT", body: conceived,
  });
  // 同步落库全章大纲
  await api(`/api/projects/${encodeURIComponent(createRes.name)}/outline_full`, {
    method: "PUT",
    body: {
      arcs: conceived.arcs,
      outline: conceived.outline,
      total_words: conceived.total_words,
      total_chapters: conceived.total_chapters,
    },
  });

  toast("项目已建立,进入写作台 ✓", "ok");
  state.currentProject = createRes.name;
  setTimeout(() => { setPage("studio"); loadProject(createRes.name); }, 600);
});

/* ───────── 写作台 ───────── */
async function renderStudioList() {
  const wrap = $("#studio-project-list");
  wrap.textContent = "加载中…";
  const j = await api("/api/projects");
  if (!j.ok) { wrap.textContent = "加载失败"; return; }
  if (!j.projects.length) {
    wrap.innerHTML = `<p class="muted">尚无作品</p>`;
    return;
  }
  wrap.innerHTML = "";
  for (const p of j.projects) {
    const m = GENRE_META[p.genre] || { cn: p.genre };
    const el = document.createElement("div");
    el.className = "side-item" + (p.name === state.currentProject ? " active" : "");
    el.innerHTML = `${p.title || p.name}<span class="sg">${m.cn}</span>`;
    el.onclick = () => { state.currentProject = p.name; renderStudioList(); loadProject(p.name); };
    wrap.appendChild(el);
  }
}

$("#refresh-projects")?.addEventListener("click", renderStudioList);
$("#link-conceive")?.addEventListener("click", e => { e.preventDefault(); setPage("conceive"); });
$("#cta-conceive")?.addEventListener("click", () => setPage("conceive"));
$("#cta-studio")?.addEventListener("click", () => setPage("studio"));

async function loadProject(name) {
  $("#studio-empty").hidden = true;
  $("#studio-pane").hidden = false;
  const j = await api(`/api/projects/${encodeURIComponent(name)}`);
  if (!j.ok) return toast("项目加载失败", "error");
  const cfg = j.config || {};
  const m = GENRE_META[cfg.genre] || { cn: cfg.genre || "" };
  $("#cur-title").textContent = cfg.title || cfg.name || name;
  $("#cur-meta").textContent  = `${m.cn} · ${cfg.status || ""} · 已写 ${j.chapters.length} 章`;
  await loadStyle(cfg.genre || "wuxia");
  await loadInfo(name);
  await loadStudioOutline(name);
}

async function loadStudioOutline(name) {
  const wrap = $("#studio-outline");
  wrap.textContent = "载入中…";
  const j = await api(`/api/projects/${encodeURIComponent(name)}/outline_full`);
  if (!j.ok || !j.data) { wrap.textContent = "尚无全书大纲"; return; }
  const all = j.data.outline || [];
  state.studio_outline = all;
  function paint(rows) {
    wrap.innerHTML = "";
    for (const ch of rows) {
      const r = document.createElement("div");
      r.className = "outline-row";
      r.style.gridTemplateColumns = "60px 1fr 90px";
      r.innerHTML = `<div class="onum">${ch.num}</div>
                     <div>
                       <div class="otit">${ch.title || ""}</div>
                       <div class="ohk">${ch.hook || ""}</div>
                     </div>
                     <div style="text-align:right">
                       <button class="btn btn-sm btn-ghost fill-blueprint" data-num="${ch.num}">回填 →</button>
                     </div>`;
      wrap.appendChild(r);
    }
    $("#studio-outline-count").textContent = `共 ${rows.length} 章`;
  }
  paint(all);
  $("#studio-outline-filter").oninput = e => {
    const q = e.target.value.trim().toLowerCase();
    if (!q) return paint(all);
    paint(all.filter(ch =>
      String(ch.num).includes(q) ||
      (ch.title || "").toLowerCase().includes(q) ||
      (ch.hook  || "").toLowerCase().includes(q)
    ));
  };
  // 「回填 →」用事件委托(paint 重建 DOM 后按钮仍可点)
  if (!wrap.dataset.delegated) {
    wrap.addEventListener("click", e => {
      const b = e.target.closest(".fill-blueprint");
      if (!b) return;
      fillBlueprint(+b.dataset.num);
    });
    wrap.dataset.delegated = "1";
  }
}

async function fillBlueprint(num) {
  const j = await api(`/api/projects/${encodeURIComponent(state.currentProject)}/chapter/${num}/blueprint`);
  if (!j.ok) { toast(j.error || "回填失败", "error"); return; }
  $("#ch-num").value = num;
  $("#ch-outline").value = j.chapter_text;
  // 切回写作 tab
  $$(".tab").forEach(x => x.classList.remove("active"));
  $(".tab[data-tab='write']").classList.add("active");
  $$(".tab-panel").forEach(p => p.hidden = (p.dataset.tab !== "write"));
  toast(`已回填第 ${num} 章大纲 ✓`, "ok");
}

$$(".tab").forEach(t => t.addEventListener("click", () => {
  $$(".tab").forEach(x => x.classList.remove("active"));
  t.classList.add("active");
  $$(".tab-panel").forEach(p => p.hidden = (p.dataset.tab !== t.dataset.tab));
  if (t.dataset.tab === "tables") $("#table-load").click();
}));

/* ── 章节写作 ── */
$("#ch-blueprint")?.addEventListener("click", () => fillBlueprint(+$("#ch-num").value || 1));
$("#ch-load")?.addEventListener("click", async () => {
  const num = +$("#ch-num").value || 1;
  const j = await api(`/api/projects/${encodeURIComponent(state.currentProject)}/chapter/${num}`);
  if (j.ok) { $("#ch-text").value = j.content; toast("已读取 ✓", "ok"); }
  else      { $("#ch-text").value = ""; toast(j.error || "未找到该章", "error"); }
});
$("#ch-save")?.addEventListener("click", async () => {
  const num = +$("#ch-num").value || 1;
  const j = await api(`/api/projects/${encodeURIComponent(state.currentProject)}/chapter/${num}`, {
    method: "PUT", body: { content: $("#ch-text").value },
  });
  toast(j.ok ? "已保存 ✓" : "保存失败", j.ok ? "ok" : "error");
});
$("#ch-write")?.addEventListener("click", async () => {
  if (!state.llm.api_key) { setPage("settings"); return toast("请先在「设置」填 API Key", "error"); }
  const num = +$("#ch-num").value || 1;
  const lvl = $("#ch-level").value;
  const out = $("#ch-outline").value;
  $("#ch-log").textContent = `墨栈正在执笔第 ${num} 章(${lvl})…`;
  const btn = $("#ch-write"); btn.disabled = true;
  try {
    const j = await api(`/api/projects/${encodeURIComponent(state.currentProject)}/write`, {
      method: "POST",
      body: { chapter: num, level: lvl, outline: out, llm: state.llm },
    });
    if (!j.ok) { $("#ch-log").textContent = "写作失败:" + j.error; return; }
    $("#ch-text").value = j.text;
    $("#ch-log").textContent = `已完成。字数 ${j.text.length},用量 ${JSON.stringify(j.usage)}`;
    toast("章节已生成 ✓", "ok");
  } finally { btn.disabled = false; }
});
$("#ch-check")?.addEventListener("click", async () => {
  const num = +$("#ch-num").value || 1;
  // 同时跑「P0 主角/简介一致性」+ 传统连续性自检,合并显示
  const [cons, chk] = await Promise.all([
    api(`/api/projects/${encodeURIComponent(state.currentProject)}/chapter/${num}/consistency`),
    api(`/api/projects/${encodeURIComponent(state.currentProject)}/check`, {
      method: "POST", body: { chapter: num },
    }),
  ]);
  const lines = [];
  if (cons.ok) {
    lines.push(`◤ 主角/简介一致性: ${cons.pass ? "✓ 通过" : "✗ 未通过"}`);
    if (cons.protagonist_name) lines.push(`  主角名: ${cons.protagonist_name}`);
    if (cons.synopsis_anchor)  lines.push(`  简介锚: ${cons.synopsis_anchor}…`);
    for (const it of (cons.issues || []))
      lines.push(`  [${it.level}] ${it.message}`);
    lines.push("");
  }
  lines.push("◤ 连续性自检");
  lines.push(JSON.stringify(chk.ok ? chk.report : chk, null, 2));
  $("#ch-log").textContent = lines.join("\n");
});
$("#ch-score")?.addEventListener("click", async () => {
  const num = +$("#ch-num").value || 1;
  const j = await api(`/api/projects/${encodeURIComponent(state.currentProject)}/score`, {
    method: "POST", body: { chapter: num },
  });
  $("#ch-log").textContent = JSON.stringify(j.ok ? j.result : j, null, 2);
});
$("#ch-climax")?.addEventListener("click", async () => {
  const j = await api(`/api/projects/${encodeURIComponent(state.currentProject)}/climax`);
  $("#ch-log").textContent = JSON.stringify(j.ok ? j.report : j, null, 2);
});
/* ── 四表(中文结构化视图 + JSON 切换)── */

// 字段中文化映射
const FIELD_LABELS = {
  global_day: "当前天数", current_period: "当前时段", storylines: "剧情线",
  main: "主线", sub: "副线", villain: "反派线", sync_points: "同步点",
  chapter: "章", day: "天", period: "时段", period_hour: "时刻",
  event: "事件", location: "地点", characters: "涉及角色",
  name: "姓名", role: "定位", status: "状态", cultivation_level: "修为",
  chapter_last_seen: "末次出场", appearances: "出场章节", last_moved: "最近移动",
  from: "起", to: "至",
  active: "活跃", dormant: "休眠", recovered: "已回收", id: "编号",
  introduced_day: "埋设天", introduced_chapter: "埋设章", content: "内容",
  related_characters: "相关角色", tension: "张力", priority: "优先级",
  items: "物品", type: "类型", rarity: "品级", owner: "持有者",
  acquired_chapter: "获取章", history: "履历", action: "动作",
};

const VALUE_LABELS = {
  weapon: "武器", clue: "线索", potion: "丹药", armor: "防具",
  accessory: "饰品", skill: "功法",
  owned: "持有", used: "已用", lost: "已失", damaged: "已损",
  active: "活跃", recovered: "已回收", dormant: "休眠",
  "主角": "主角", "导师": "导师", "反派": "反派", "配角": "配角",
  "女主": "女主", "男配": "男配",
};

function roleBadge(role) {
  if (!role) return "";
  const map = { "主角":"📕","女主":"🌸","导师":"🎓","反派":"⚔","配角":"👤","男配":"🗡" };
  return (map[role] || "👤") + " " + role;
}

function t(value) { return VALUE_LABELS[value] ?? FIELD_LABELS[value] ?? value; }

function pretty(v) {
  if (v === null || v === undefined) return '<span class="muted">(无)</span>';
  if (typeof v === "boolean") return v ? "✓" : "✗";
  if (Array.isArray(v)) {
    if (v.length === 0) return '<span class="muted">(空)</span>';
    return v.map(pretty).join("、");
  }
  if (typeof v === "object") {
    return Object.entries(v).map(([k, vv]) =>
      `<span class="kv"><span class="k">${t(k)}</span><span class="v">${pretty(vv)}</span></span>`
    ).join(" ");
  }
  return String(v);
}

function renderTable(rows, columns) {
  if (!rows || rows.length === 0) {
    return '<p class="muted table-empty">(暂无记录)</p>';
  }
  const thead = columns.map(c => `<th>${t(c.label || c.key)}</th>`).join("");
  const tbody = rows.map(r =>
    "<tr>" + columns.map(c => {
      const v = c.render ? c.render(r) : pretty(r[c.key]);
      return `<td>${v}</td>`;
    }).join("") + "</tr>"
  ).join("");
  return `<div class="tbl-wrap"><table class="tbl"><thead><tr>${thead}</tr></thead><tbody>${tbody}</tbody></table></div>`;
}

function renderTableCN(name, data) {
  if (!data) return '<p class="muted">(空表)</p>';

  if (name === "timeline.json") {
    const main = data.storylines?.main || [];
    const sub  = data.storylines?.sub  || [];
    const vil  = data.storylines?.villain || [];
    const head = `
      <div class="table-summary">
        <span>📖 已写到 <b>第 ${data.global_day ?? "?"} 天</b></span>
        <span>⏰ 当前 <b>${t(data.current_period) || "—"}</b></span>
        <span>📌 主线 ${main.length} 事件 · 副线 ${sub.length} · 反派 ${vil.length}</span>
      </div>`;
    const cols = [
      { key: "chapter",  label: "章" },
      { key: "day",      label: "天" },
      { key: "period",   label: "时段", render: r => `${r.period || ""} ${r.period_hour != null ? `(${r.period_hour}时)` : ""}` },
      { key: "event",    label: "事件" },
      { key: "location", label: "地点" },
      { key: "characters", label: "角色", render: r => (r.characters || []).map(roleBadge).join(" ") },
    ];
    let body = "";
    if (main.length) body += `<h4 class="storyline-title">📕 主线</h4>` + renderTable(main, cols);
    if (sub.length)  body += `<h4 class="storyline-title">🌿 副线</h4>` + renderTable(sub, cols);
    if (vil.length)  body += `<h4 class="storyline-title">⚔ 反派线</h4>` + renderTable(vil, cols);
    if (!body) body = '<p class="muted table-empty">(暂无事件,写完第一章后自动生成)</p>';
    return head + body;
  }

  if (name === "characters_snapshot.json") {
    const list = data.characters || [];
    const cols = [
      { label: "姓名", render: r => `<b>${r.name || "(无名)"}</b>` },
      { label: "定位", render: r => roleBadge(r.role) },
      { label: "状态", render: r => `<span class="status-pill">${t(r.status) || "—"}</span>` },
      { label: "修为", render: r => r.cultivation_level || '<span class="muted">—</span>' },
      { label: "位置", render: r => r.location || '<span class="muted">—</span>' },
      { label: "末次出场", render: r => r.chapter_last_seen != null ? `第 ${r.chapter_last_seen} 章` : "—" },
      { label: "最近移动", render: r => r.last_moved
        ? `第 ${r.last_moved.day} 天:${r.last_moved.from} → ${r.last_moved.to}`
        : '<span class="muted">—</span>' },
    ];
    const head = `<div class="table-summary">👥 共 <b>${list.length}</b> 个角色</div>`;
    return head + renderTable(list, cols);
  }

  if (name === "hooks.json") {
    const act = data.active || [];
    const rec = data.recovered || [];
    const dor = data.dormant || [];
    const head = `<div class="table-summary">🪝 活跃 <b>${act.length}</b> · 已回收 <b>${rec.length}</b> · 休眠 <b>${dor.length}</b></div>`;
    const cols = [
      { label: "伏笔",  render: r => `<b>${r.name || r.id}</b>` },
      { label: "内容",  render: r => r.content || "" },
      { label: "优先级",render: r => {
          const p = r.priority || "";
          const cls = p === "P0" ? "p0" : p === "P1" ? "p1" : "p2";
          return `<span class="pri ${cls}">${p || "—"}</span>`;
        } },
      { label: "张力",  render: r => r.tension || "—" },
      { label: "埋设",  render: r => r.introduced_chapter != null ? `第 ${r.introduced_chapter} 章` : "—" },
      { label: "末次出现", render: r => r.chapter_last_seen != null ? `第 ${r.chapter_last_seen} 章` : "—" },
    ];
    let body = "";
    if (act.length) body += `<h4 class="storyline-title">🔥 活跃</h4>` + renderTable(act, cols);
    if (rec.length) body += `<h4 class="storyline-title">✓ 已回收</h4>` + renderTable(rec, cols);
    if (dor.length) body += `<h4 class="storyline-title">💤 休眠</h4>` + renderTable(dor, cols);
    if (!body) body = '<p class="muted table-empty">(暂无伏笔)</p>';
    return head + body;
  }

  if (name === "inventory.json") {
    const list = data.items || [];
    const cols = [
      { label: "物品",  render: r => `<b>${r.name || r.id}</b>` },
      { label: "类型",  render: r => t(r.type) || "—" },
      { label: "品级",  render: r => r.rarity || "—" },
      { label: "持有者",render: r => r.owner || "—" },
      { label: "位置",  render: r => r.location || "—" },
      { label: "状态",  render: r => `<span class="status-pill">${t(r.status) || "—"}</span>` },
      { label: "获取",  render: r => r.acquired_chapter != null ? `第 ${r.acquired_chapter} 章` : "—" },
    ];
    const head = `<div class="table-summary">🎒 共 <b>${list.length}</b> 件物品</div>`;
    return head + renderTable(list, cols);
  }

  return '<p class="muted">(未知表)</p>';
}

async function loadTable() {
  const tname = $("#table-name").value;
  const view = $("#table-view");
  view.innerHTML = '<p class="muted">读取中…</p>';
  const j = await api(`/api/projects/${encodeURIComponent(state.currentProject)}/table/${tname}`);
  if (!j.ok) {
    view.innerHTML = `<p class="muted">读取失败:${j.error || "未知错误"}</p>`;
    $("#table-meta").textContent = "";
    return;
  }
  view.innerHTML = renderTableCN(tname, j.data);
  $("#table-text").value = JSON.stringify(j.data, null, 2);
  const file = tname.replace(".json", "");
  $("#table-meta").textContent = `已加载 · ${file} · 点「{ }」可切到 JSON 模式编辑`;
}

$("#table-load")?.addEventListener("click", loadTable);
$("#table-name")?.addEventListener("change", loadTable);

$("#table-toggle-json")?.addEventListener("click", () => {
  const wrap = $("#table-json-wrap");
  wrap.hidden = !wrap.hidden;
  $("#table-toggle-json").textContent = wrap.hidden ? "{ } 查看/编辑 JSON" : "👁 返回中文视图";
});
$("#table-cancel-json")?.addEventListener("click", () => {
  $("#table-json-wrap").hidden = true;
  $("#table-toggle-json").textContent = "{ } 查看/编辑 JSON";
});

$("#table-save")?.addEventListener("click", async () => {
  const tname = $("#table-name").value;
  let body;
  try { body = JSON.parse($("#table-text").value); }
  catch (e) { return toast("JSON 解析失败:" + e.message, "error"); }
  const j = await api(`/api/projects/${encodeURIComponent(state.currentProject)}/table/${tname}`, {
    method: "PUT", body,
  });
  if (j.ok) {
    toast("已保存 ✓", "ok");
    $("#table-view").innerHTML = renderTableCN(tname, body);
  } else {
    toast(j.error || "保存失败", "error");
  }
});
/* ── 文风 ── */
async function loadStyle(genre) {
  const j = await api(`/api/genre/${genre}/style`);
  $("#style-text").textContent = j.ok ? j.text : ("加载失败:" + j.error);
}
/* ── 简介 tab(中文卡片视图 + JSON 折叠)── */
async function loadInfo(name) {
  const view = $("#info-view");
  view.innerHTML = '<p class="muted">读取中…</p>';
  const j = await api(`/api/projects/${encodeURIComponent(name)}/conceived`);
  const c = j.data;
  if (!c) {
    view.innerHTML = '<p class="muted">(该项目还没有构思草稿,请先在「构思新书」走完四步)</p>';
    $("#info-text").value = "";
    return;
  }
  $("#info-text").value = JSON.stringify(c, null, 2);

  // 主角卡片
  const p = c.protagonist || {};
  const heroCard = `
    <div class="info-card info-hero">
      <div class="info-card-head">👤 主角</div>
      <div class="info-hero-name">${p.name || "(未命名)"}<span class="info-hero-age">${p.age || "?"} 岁</span></div>
      <div class="info-row"><span class="info-k">身份</span><span class="info-v">${p.identity || '<span class="muted">(未填)</span>'}</span></div>
      <div class="info-row"><span class="info-k">人设</span><span class="info-v">${p.trait || '<span class="muted">(未填)</span>'}</span></div>
      <div class="info-row"><span class="info-k">动机</span><span class="info-v">${p.motivation || '<span class="muted">(未填)</span>'}</span></div>
    </div>`;

  // 主题徽章
  const themeTags = (c.themes || []).map(t => `<span class="tag">${t}</span>`).join("")
    || '<span class="muted">(无)</span>';

  // 分卷大纲
  const arcItems = (c.outline || []).map(o => `
    <li class="info-arc">
      <div class="info-arc-head">
        <span class="info-arc-name">📚 ${o.arc || "(无名)"}</span>
        <span class="info-arc-range">${o.chapters || ""}</span>
      </div>
      <div class="info-arc-key">${o.key || ""}</div>
    </li>`).join("") || '<li class="muted">(暂无分卷大纲)</li>';

  // 前三章钩子
  const hookItems = (c.first_three_chapters || []).map(ch => `
    <li class="info-hook">
      <span class="info-hook-num">第 ${ch.num} 章</span>
      <span class="info-hook-title">${ch.title || ""}</span>
      <span class="info-hook-text">${ch.hook || ""}</span>
    </li>`).join("") || '<li class="muted">(暂无前三章钩子)</li>';

  view.innerHTML = `
    <div class="info-card info-title-card">
      <div class="info-title">《${c.title || "(未命名)"}》</div>
      <div class="info-subtitle">${c.subtitle || ""}</div>
    </div>

    <div class="info-card">
      <div class="info-card-head">📖 简介</div>
      <div class="info-synopsis">${(c.synopsis || "(无)").replace(/\n/g, "<br>")}</div>
    </div>

    ${heroCard}

    <div class="info-card">
      <div class="info-card-head">🎯 核心主题</div>
      <div class="info-tags">${themeTags}</div>
    </div>

    <div class="info-card">
      <div class="info-card-head">🗂 分卷大纲</div>
      <ul class="info-arcs">${arcItems}</ul>
    </div>

    <div class="info-card">
      <div class="info-card-head">🎣 前三章钩子</div>
      <ul class="info-hooks">${hookItems}</ul>
    </div>
  `;
}

// 简介 JSON 保存
$("#info-save")?.addEventListener("click", async () => {
  let body;
  try { body = JSON.parse($("#info-text").value); }
  catch (e) { return toast("JSON 解析失败:" + e.message, "error"); }
  const j = await api(`/api/projects/${encodeURIComponent(state.currentProject)}/conceived`, {
    method: "PUT", body,
  });
  if (j.ok) {
    toast("已保存 ✓", "ok");
    loadInfo(state.currentProject);
  } else {
    toast(j.error || "保存失败", "error");
  }
});
$("#info-reload")?.addEventListener("click", () => loadInfo(state.currentProject));
/* ───────── 设置 ───────── */
function fillSettings() {
  $("#cfg-provider").value = state.llm.provider;
  $("#cfg-key").value      = state.llm.api_key;
  $("#cfg-base").value     = state.llm.base_url;
  $("#cfg-model").value    = state.llm.model;
  $("#cfg-temp").value     = state.llm.temperature;
  $("#cfg-max").value      = state.llm.max_tokens;
}
$("#cfg-save")?.addEventListener("click", () => {
  state.llm = {
    provider: $("#cfg-provider").value,
    api_key:  $("#cfg-key").value.trim(),
    base_url: $("#cfg-base").value.trim(),
    model:    $("#cfg-model").value.trim() || "claude-opus-4-7",
    temperature: +$("#cfg-temp").value || 0.7,
    max_tokens:  +$("#cfg-max").value  || 8000,
  };
  localStorage.setItem("mozhan_llm", JSON.stringify(state.llm));
  toast("设置已保存 ✓", "ok");
});
$("#cfg-test")?.addEventListener("click", async () => {
  const cfg = {
    provider: $("#cfg-provider").value,
    api_key:  $("#cfg-key").value.trim(),
    base_url: $("#cfg-base").value.trim(),
    model:    $("#cfg-model").value.trim() || "claude-opus-4-7",
    temperature: +$("#cfg-temp").value || 0.7,
    max_tokens: 200,
  };
  $("#cfg-log").textContent = "测试中…";
  // 使用 /api/conceive 跑一个迷你测试,避免新建项目
  const j = await api("/api/conceive", {
    method: "POST",
    body: { genre: "wuxia", idea: "测试连接,请返回任意 JSON", llm: cfg },
  });
  if (j.ok) {
    $("#cfg-log").textContent = "✓ 连接成功\n模型: " + j.model + "\n用量: " + JSON.stringify(j.usage);
    toast("连接成功 ✓", "ok");
  } else {
    $("#cfg-log").textContent = "✗ 连接失败\n" + (j.error || JSON.stringify(j));
    toast("连接失败", "error");
  }
});

/* ───────── 键盘快捷键 ───────── */
document.addEventListener("keydown", e => {
  // Ctrl+Enter: 提交当前步骤 / 触发主操作
  if ((e.ctrlKey || e.metaKey) && e.key === "Enter") {
    const activeBtn = document.querySelector(".btn-primary:not([disabled]):not([hidden])");
    if (activeBtn && activeBtn.offsetParent !== null) activeBtn.click();
  }
  // Esc: 返回上一步(构思向导) / 关闭 toast
  if (e.key === "Escape") {
    const toast = document.getElementById("toast");
    if (toast && !toast.hidden) { toast.hidden = true; return; }
    const back = document.querySelector(".step-panel:not([hidden]) .btn-ghost[id^=back-to]");
    if (back) back.click();
  }
});

/* ───────── 启动 ───────── */
$$(".nav-link").forEach(a => a.addEventListener("click", () => setPage(a.dataset.page)));

(async () => {
  const b = await api("/api/brand").catch(() => null);
  if (b?.ok) $("#brand-version").textContent = b.version;
  setPage("home");
})();


