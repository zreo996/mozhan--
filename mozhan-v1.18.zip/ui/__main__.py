"""ui 启动入口 — 允许 python -m ui"""
from ui.app import main

if __name__ == "__main__":
    main()
