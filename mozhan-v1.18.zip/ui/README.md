# 墨栈 · MoZhan Web UI

A browser-based writing dashboard for the **mozhan** Skill.
Brings together project management, four-table editing, AI-driven chapter
generation, continuity self-check, quality scoring, climax density, and
style fingerprints — all from a single page.

## Quick Start

```bash
# 1. Install
pip install flask
# (核心零依赖,flask 只为 UI)

# 2. Launch
python -m ui
# 默认 http://127.0.0.1:8765
```

Then open <http://127.0.0.1:8765> in your browser.

## Configuration

| CLI flag | Default | Description |
|:---|:---|:---|
| `--host` | `127.0.0.1` | Bind address (use `0.0.0.0` for LAN access) |
| `--port` | `8765` | Listen port |
| `--projects-root` | `./projects` | Project storage directory |
| `--debug` | off | Flask debug mode |

```bash
python -m ui --host 0.0.0.0 --port 9000 --projects-root ~/novels
```

## Model API

Click ⚙️ **设置** in the sidebar and fill in:

- **Provider**: `anthropic` (Claude) or `openai` (any OpenAI-compatible endpoint)
- **API Key**: stored in browser `localStorage` only, never sent to disk
- **Base URL**: leave blank for default; for OpenAI-compatible services
  (e.g. DeepSeek, Moonshot, OpenRouter), set their endpoint
- **Model**: e.g. `claude-sonnet-4-6`, `gpt-4o`, `deepseek-chat`
- **Temperature**: 0.7 default
- **Max Tokens**: 8000 default

Click 🧪 **测试连接** to verify before writing.

## Pages

| Page | What it does |
|:---|:---|
| 📁 **项目** | Create / select / delete projects; auto-generates style fingerprint |
| ✍️ **写作** | Edit chapter outline, hit 🚀 AI 写作, save, run self-check / score / climax density |
| 📊 **四表** | View and edit `timeline.json` / `characters_snapshot.json` / `hooks.json` / `inventory.json` |
| 🎨 **文风** | Browse style fingerprints across all 12 genres |
| ⚙️ **设置** | API configuration |

## REST API

The UI is also a REST backend. Use the same endpoints from your own tools.

```
GET    /api/projects
POST   /api/projects                     {name, genre}
GET    /api/projects/<name>
DELETE /api/projects/<name>
GET    /api/projects/<name>/table/<table>
PUT    /api/projects/<name>/table/<table>
GET    /api/projects/<name>/chapter/<num>
PUT    /api/projects/<name>/chapter/<num>     {content}
DELETE /api/projects/<name>/chapter/<num>
POST   /api/projects/<name>/write        {llm, chapter, level, outline, worldview}
POST   /api/projects/<name>/check        {chapter}
POST   /api/projects/<name>/score        {chapter}
GET    /api/projects/<name>/climax
GET    /api/genre/<genre>/style
GET    /api/genres
```

## Architecture

```
Browser (HTML/JS)
    ↓ HTTP/JSON
Flask (ui/app.py)
    ↓ import
core/scripts/*.py        # 连续性 / 评分 / 爽点 / 文风印记
    ↓ read
data/{project}/*.json    # 四表 + 文风印记 + 章节
```

All state lives in plain JSON files under `projects/`. No database.

## Project Layout

```
projects/<书名>/
├── config.json
├── data/
│   ├── timeline.json
│   ├── characters_snapshot.json
│   ├── hooks.json
│   ├── inventory.json
│   └── style_fingerprint.json    # 自动从 genres/<题材>/masterpiece_analysis.md 抽取
└── chapters/
    └── chapter_001.txt
```

## Security

- API keys are stored in the browser's `localStorage` only
- Server never persists API keys
- Default bind is `127.0.0.1` (loopback only); expose with `--host 0.0.0.0` only on trusted networks
- Add a reverse proxy with auth (e.g. nginx + basic_auth) before public deployment

## Troubleshooting

- **`ModuleNotFoundError: No module named 'flask'`** → `pip install flask`
- **`No module named 'ui.app'`** → run from repo root: `cd /path/to/mozhan && python -m ui`
- **章节写作超时** → 大章节(L4 5500字)约 1-2 min;检查网络与 API 配额
- **自检/评分失败** → `python -m pytest tests/` 看核心脚本是否正常
