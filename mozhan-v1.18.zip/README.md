﻿<div align="center">

<img src="ui/static/logo.svg" width="120" alt="墨栈 LOGO">

# 墨栈 · MoZhan

**一栈写尽万千江湖**

为长篇中文网文量身定制的创作 Skill。  
十二大题材 · **九大发布平台** · 文风印记自动注入 · **四步构思向导** · Web UI 一键接入 Claude / GPT / DeepSeek。

</div>

<div align="center">

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Tests](https://img.shields.io/badge/tests-49%20passed-brightgreen)](tests/)
[![Python](https://img.shields.io/badge/Python-3.10%2B-blue)](https://www.python.org)
[![Genres](https://img.shields.io/badge/%E9%A2%98%E6%9D%90-12%20%E5%A4%A7-purple)](genres/)
[![Platforms](https://img.shields.io/badge/%E5%B9%B3%E5%8F%B0-9%20%E5%AE%B6-magenta)](core/scripts/platform_profiles.py)
[![Version](https://img.shields.io/badge/version-v1.17-orange)](CHANGELOG.md)

</div>

---

## ✨ 它是什么

**墨栈 (MoZhan)** 是一个 Claude Skill 形态的中文长篇小说创作工具箱。
你的 Claude 装上它之后,可以从一句模糊的「我想写个故事」一直陪到百万字完本 ——

- **🪄 四步构思向导** — 选题材+平台 / 写想法 / 定规模 / 出**完整章纲**(墨栈一次性把 300 章标题与钩子写齐)
- **📡 九大网文平台调性** — 番茄 / 书旗 / 七猫 / 起点 / 晋江 / 飞卢 / 刺猬猫 / 知乎 / 公众号,**书名套路、简介节奏、章节字数自动适配**
- **🎨 文风印记** — 12 题材的精品分析自动抽取,经 Prompt Caching 注入到每次生成
- **📋 四表压缩上下文** — `timeline / characters / hooks / inventory` 持续维护,避免 LLM 失忆
- **🛡 P0 锚定** — `conceived.json` 的主角名/简介/主题在每次写章节时**强制注入 system prompt**,模型不再"按模板套"
- **🚦 三层红线 + 一致性自检** — 时间倒序、位置漂移、修为倒退、伏笔丢失、物品消失、**主角名跑偏、简介脱节**全部自动拦
- **⚡ L1-L4 成本分级** — 常规章 1 次 API、关键章 2 次、核心章 3-4 次、宏篇章 5-6 次
- **🕹 Web UI** — 浏览器即开,本地存 API Key,服务端零知识

---

## 🖼 界面预览

> 跑 `python -m ui` 后访问 `http://127.0.0.1:8765` 即可看到,下面是页面结构示意。

| 首页 | 构思向导 · 选题材 | 构思向导 · 构思结果 |
|:---:|:---:|:---:|
| Hero + 作品列表 | 12 题材卡片网格 | 可编辑的书名/简介/大纲卡片 |
| 写作台 | 文风印记 | 设置 |

> 完整截图参见 [`docs/screenshots/`](docs/screenshots/)。

---

## 🚀 30 秒上手

### 1. 装到你的 Claude Code

```bash
# 克隆本仓
git clone https://github.com/your-org/mozhan.git
cd mozhan

# 建立符号链接到 Claude Code skills 目录
mkdir -p ~/.claude/skills
ln -s "$(pwd)" ~/.claude/skills/mozhan

# 装依赖(可选 — 不装也能用零 LLM 的自检/评分/爽点追踪)
pip install -r requirements.txt
```

然后在 Claude Code 里说:

> 「用 mozhan 帮我写一本武侠,主角是个被除名的剑客。」

### 2. 或:直接跑 Web UI

```bash
python -m ui
# → 浏览器打开 http://127.0.0.1:8765
# → 点「设置」填 API Key(仅存浏览器 localStorage)
# → 点「开始构思新书」,走完四步,墨栈自动建项目
```

Windows 用户也可以直接双击 `scripts/start_ui.bat`。

---

## 🧰 它能做什么(按场景)

### 场景 A:你脑子里有画面,想开书

1. 打开 Web UI,点「开始构思新书」
2. 选**题材**(12 选 1) + **平台**(9 选 1,可不选走综合)
3. 写三五句话的核心想法(可点种子点子直接填)
4. 定**全本规模**:总字数 + 总章节(预设档位:30 万 / 100 万 / 200 万字)
5. 墨栈一次性返回:**书名 / 副标 / 简介 / 主角 / 全卷 + 全章大纲(每章带标题与钩子)**
6. 不满意?「重新构思」;满意?一键建项目,**全章纲直接落库到 `outline_full.json`**

### 场景 B:你已经有大纲,想写章节

```bash
# 初始化项目
python core/scripts/one_click_writer.py init "沧海剑歌" wuxia "裴然"

# 写第 1 章
python core/scripts/one_click_writer.py plan 1 outline.txt   # 规划
python core/scripts/one_click_writer.py write 1 content.txt  # 让 Claude 写

# 写后自检
python core/scripts/self_check.py 1 --data-dir projects/沧海剑歌/data
```

### 场景 C:章节数破了 50,想看连续性

```bash
# 全书时间线/位置/修为/伏笔 一站式检查
python core/scripts/self_check.py 50 --data-dir projects/沧海剑歌/data --verbose

# 爽点密度
python core/scripts/climax_tracker.py projects/沧海剑歌/chapters
```

---

## 📂 目录结构

```
mozhan/
├── SKILL.md                    # 主入口
├── README.md                   # 你在这里
├── CHANGELOG.md                # 版本变更
├── CONTRIBUTING.md             # 贡献指南
├── ITERATION_LOG.md            # 详细迭代日志(辩证历程)
├── LICENSE                     # MIT
├── requirements.txt            # flask / anthropic / pytest
│
├── core/
│   ├── scripts/                # 11 个核心脚本
│   │   ├── self_check.py            # 5 重自检(P0 红线)
│   │   ├── post_process.py          # 写后四表更新
│   │   ├── quality_score.py         # 质量评分
│   │   ├── one_click_writer.py      # 一键写作(CLI)
│   │   ├── llm_client.py            # LLM 客户端 + 冻结上下文
│   │   ├── continuity_enforcer.py   # P0 状态机
│   │   ├── climax_tracker.py        # 爽点密度追踪
│   │   ├── genre_style.py           # 文风印记(注入 Prompt)
│   │   ├── genre_validator.py       # 题材风格校验
│   │   ├── platform_profiles.py     # 9 平台调性档案
│   │   ├── multi_agent.py           # 多 Agent 并行会诊
│   │   └── auto_update.py           # 事件驱动自动迭代
│   ├── references/             # 12 篇参考资料(红线条约/成本分级/...)
│   └── templates/              # 7 个 JSON/MD 模板
│
├── genres/                     # 12 大题材
│   ├── fantasy/   urban/  scifi/  wuxia/  historical/
│   ├── game/      apocalypse/  superpower/  fanfiction/
│   └── mystery/   romance/  isekai/
│   (每个含 worldbuilding.md / masterpiece_analysis.md / plot_templates.md / red_lines.md)
│
├── commands/                   # 7 个 slash 命令文档
├── ui/                         # Flask Web UI
│   ├── app.py
│   ├── __main__.py
│   ├── templates/index.html
│   ├── static/{logo.svg, style.css, app.js}
│   └── README.md
│
├── examples/demo_wuxia/        # 武侠最小可运行示例(3 章 + 4 表)
├── tests/                      # 49 个 pytest 测试
├── scripts/
│   ├── start_ui.sh
│   └── start_ui.bat
└── docs/                       # 截图与文档
```

---

## 🆕 v1.17 新特性详解

### 1. 四步构思向导(代替三步)

```
[1] 选题材 + 平台      —— 12 题材 × 9 平台,题材决定世界观,平台决定书名/字数/调性
       ↓
[2] 写想法            —— 三五句话即可,可点种子点子;题材决定推荐方向
       ↓
[3] 定规模            —— 总字数 + 总章节;预设 30 万/100 万/200 万/3 万四档
       ↓
[4] 看构思            —— 书名/简介/主角/全卷/「每一章的标题+钩子」一次性产出
```

**关键升级**:第 4 步不再是"分卷大纲 + 前三章",而是 **完整 N 章大纲**(N = 你定的总章节)。
墨栈算出 arcs = `max(3, 总章 / 35)`,确保卷数和总章节自洽。
全章纲落到 `data/outline_full.json`,写作台「📚 大纲」tab 全文可搜可回填。

### 2. 九大网文平台调性

| 平台 | 章节字数 | 书名套路 | 简介风格 | 适合题材 |
|:---|:---:|:---|:---|:---|
| 🍅 番茄 | 2000 | 6-15 字 + 强钩子词 | 80-200 字短句 | 玄幻/都市/末世 |
| 📕 书旗 | 3000 | 8-18 字古典雅致 | 200-400 字带世界观 | 武侠/玄幻/历史 |
| 🐱 七猫 | 2000 | 8-16 字情感词 | 100-250 字关系图 | 言情/都市 |
| 📘 起点 | 3500 | 8-20 字有格调 | 200-500 字文学化 | 玄幻/科幻/武侠 |
| 🌸 晋江 | 3500 | 4-12 字清新 | 150-300 字重氛围 | 言情/同人 |
| 🚀 飞卢 | 1500 | 10-22 字超长 | 60-150 字爽点 | 玄幻/异世界/游戏 |
| 🦔 刺猬猫 | 3000 | 6-16 字中二 | 80-200 字轻小说 | 同人/异世界 |
| 💡 知乎 | 1200 | 8-18 字反转钩 | 80-150 字现实感 | 都市/言情/悬疑 |
| 📱 公众号 | 1500 | 10-20 字强情绪 | 60-120 字痛点 | 都市/言情/历史 |

选好平台后,书名、简介、单章字数会**全自动按该平台规则**生成。

### 2.5 Web UI 中文化与快捷键
打开 `http://127.0.0.1:8765` 看到的是**全中文界面**:
- 顶栏 4 入口:首页 / 构思新书 / 写作台 / 设置(全部中文)
- 题材卡显示「中文名 + emoji」,英文名作极弱化副标题(便于国际化后备)
- 首页新增 4 个数据徽章(12 题材 / 9 平台 / 4 级成本 / 3 层红线)
- **键盘快捷键**:`Ctrl+Enter` 提交当前步骤,`Esc` 关闭 toast / 返回上一步
- 文案/错误信息/Toast 全部中文;未配 API Key 时一键跳到设置页




**根因**:`build_frozen_system` 不读 `conceived.json`,模型不知道项目设定。

**修复**(双层保险):
- **system 层**:每次写章节前,自动读 `conceived.json`,把主角名/身份/动机/简介/主题作为「**核心设定(强约束,不得擅自修改)**」插到 system prompt 第一段
- **user 层**:每条写作 prompt 顶部加「**保真硬约束 — 最高优先级**」三条铁规
- **检验层**:新增 `GET /api/projects/<n>/chapter/<num>/consistency` —— 自动比对章节文本是否含主角名、是否提及身份、是否命中大纲钩子关键词;写作台「自检」按钮已合并这个端点

### 4. 写作台「📚 大纲」tab

打开任一项目,即可看到全 N 章大纲,支持:
- 🔍 实时搜索(章号 / 标题 / 钩子)
- 📌「回填 →」按钮:一键把该章的标题+钩子塞进写作框,然后「🚀 让墨栈写」

---



| 等级 | 触发的就是拒绝 | 例子 |
|:---:|:---|:---|
| **P0** | 一票否决 | 时间倒序、位置漂移、修为倒退、伏笔超 3 章未回收、物品消失、角色幽灵 |
| **P1** | 每条 -10 分 | 视角混乱、节奏崩塌、战力崩坏、设定冲突、伏笔断裂、逻辑跳跃 |
| **LINT** | 提示 | 字段缺失、休眠超 30 章的伏笔、消耗品未标 `remaining` |

完整规则:[`core/references/red_lines.md`](core/references/red_lines.md) + 每个题材的 `red_lines.md`。

---

## 🎨 文风印记

每个题材的 `masterpiece_analysis.md` 由墨栈自动解析为 ~500 token 的结构化印记:

```
== 文风印记: wuxia ==
参考 4 本精品: 《雪中悍刀行》《最强boss系统》《死人经》《催妆》

== 核心流派与文字气质 ==
- 雪中悍刀行 流派: 诗意武侠
- 最强boss系统 流派: 武侠游戏化
- 死人经 流派: 黑暗武侠
- 催妆 流派: 武侠甜宠流

== 关键写作技巧 ==
- 《雪中悍刀行》 不只是主角,配角也有弧光
- 《最强boss系统》 武侠世界游戏化
- 《死人经》 复仇是唯一主线
- 《催妆》 感情戏是主线
...
```

这些印记经 `LLMClient.FrozenContext.style_fingerprint` 注入到 **Prompt Caching 冻结区**,每次写作都自动加载。
成本:每个印记 ~500 token,因 cache hit 90% 折扣,基本免费。

---

## 💰 成本优化(七大策略)

| 策略 | 节省 | 适用 |
|:---|:---:|:---|
| 上下文压缩(4 表代替 20 章全文) | 60-80% token | 全部 |
| 批量生成(多章一次返回) | 50% API 次数 | L1 常规章 |
| 规格复用(章节规格 + 少量变量) | 30% token | L2 关键章 |
| Prompt 缓存(冻结世界观+文风) | 90% 冻结区 | 全部 |
| 并行 Agent 评审(多视角) | 40% 时间 | L3/L4 |
| 增量更新(只送最近 N 章) | 50% 历史 | L4 宏篇 |
| 模型路由(轻任务用 Haiku) | 60% 成本 | L1/P1 |

**百万字总成本**:从 ~18M tokens 降至 ~7M tokens(节省 61%)。

---

## 🧪 测试

```bash
pip install -r requirements.txt
pytest tests/ -v
```

```
======================== 49 passed in 4.32s ========================
```

覆盖:`continuity_enforcer` / `climax_tracker` / `genre_style` / `post_process` / `quality_score` / `self_check` / `llm_client` 各模块核心路径。

---

## 🛣 Roadmap

- [x] v1.10 基础整合
- [x] v1.11 中文网文节奏引擎 + 题材兼容矩阵
- [x] v1.12 三方辩证共识(版权 P0 / 语义鲁棒 / 数据透明)
- [x] v1.13 补全:时段时间词典 + 27 个测试 + 12 题材红线
- [x] v1.14 文风印记自动注入
- [x] v1.15 Web UI + GitHub 打包
- [x] v1.16 **墨栈** 品牌 + 三步构思向导
- [x] v1.17 **平台层(9 家)+ 四步向导 + 全章纲生成 + P0 一致性锚定**
- [ ] v1.18 多 Agent 会诊实装(目前接口在,UI 待补)
- [ ] v1.19 RAG 检索跨章文风一致性
- [ ] v1.20 桌面端(Tauri / Electron)打包

完整迭代史:[`ITERATION_LOG.md`](ITERATION_LOG.md)

---

## 🤝 致谢

- **[novel-writer-inkos-fusion](https://github.com/...)** — 早期整合的母版
- **DeepSeek / MiniMax** — 三方辩证对手,贡献了 5 个致命缺陷定位
- **Anthropic Claude 4.7** — 主力写作模型
- **51 部网文精品** — 12 题材的文风印记都来自它们的 `masterpiece_analysis.md`

## 📜 许可证

MIT — 见 [LICENSE](LICENSE)。

---

<div align="center">

**墨栈 · MoZhan**  
*一栈写尽万千江湖*

[⭐ Star](../../stargazers) · [🐛 Issue](../../issues) · [💬 Discussion](../../discussions)

</div>


