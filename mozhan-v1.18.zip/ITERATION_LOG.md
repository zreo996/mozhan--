# 迭代日志 v2.0

## 来源
- AI：MiniMax MN2.7（主导）、DeepSeek（辩证）、Claude-Opus-4-7（评审）
- 日期：2026-05-16
- 方式：三模型群聊辩证

---

## 辩证历程

| 轮次 | 主辩手 | 内容 |
|:---|:---|:---|
| 1-5 | DeepSeek | 指出5个致命缺陷 |
| 6 | DeepSeek | 提供代码级修复方案 |
| 7 | DeepSeek | 综合方案和行动建议 |
| 8 | DeepSeek | 评估修改并指出3个关键遗漏 |
| 9 | DeepSeek | 最终评估：95%解决 |
| 10 | MiniMax | 整合并更新SKILL.md |

---

## 5个致命缺陷及解决状态

| 缺陷 | DeepSeek建议 | 解决状态 |
|:---|:---|:---:|
| #1 轻量状态机 | ContinuityGraph+NetworkX | ✅ 已解决 |
| #2 Hero's Journey不适用 | 中文节奏引擎 | ✅ 已解决 |
| #3 题材兼容性矩阵 | 具体矩阵实现 | ✅ 已解决 |
| #4 成本路由伪优化 | 单一强模型 | ✅ 已解决 |
| #5 质量vs读者体验混淆 | 指标分离系统 | ✅ 已解决 |

---

## 新增功能

| 功能 | 说明 |
|:---|:---|
| 人设一致性校验 | 人设>节奏>情感>对话配比 |
| 爽点密度控制 | 每100章18-25次打脸 |
| 题材兼容性验证流程 | 冲突检测与调和 |

---

## SKILL.md更新内容

### v1.11 新增章节

1. **中文网文节奏引擎** - 10阶段节奏模板（狗血/装逼/打脸/天才/仇恨/爆发/奇遇/修炼/转折/高潮）
2. **章节节奏控制矩阵** - 按字数动态调整钩子频率
3. **情感锚点规则** - 每场景2个情感触发点，每2000字切换1次
4. **对话-叙事配比规则** - 场景类型决定比例
5. **伏笔回收强制机制** - 隐性3章/显性5章/环境10章
6. **题材兼容性矩阵** - 6x6矩阵（0-3评分）
7. **人设一致性校验规则** - 优先级：人设>节奏>情感>对话
8. **爽点密度控制规则** - 小/中/大打脸间隔标准
9. **题材兼容性验证流程** - 冲突检测步骤
10. **读者体验指标** - 与质量指标分离评估

### 实施文件

- `core/scripts/continuity_enforcer.py` - 完整连续性强制系统
- `core/references/deepseek_feedback.md` - DeepSeek辩证反馈

---

## 最终评级

**总体评级：95%解决**

剩余5%为优化建议：
- 性能优化（大规模章节）
- 人设上下文感知
- 爽点密度与题材联动
- 测试覆盖率

---

## 更新记录

| 日期 | 版本 | 更新内容 |
|:---|:---:|:---|
| 2026-05-16 | v1.11 | 完成9轮辩证，更新SKILL.md，新增10项功能 |
| 2026-05-16 | v1.10 | 初始版本，基于novel-writer-inkos-fusion |

---

## v1.12 更新（2026-05-16）

### 新增功能：自动更新迭代系统

**三方辩论共识：**
- 需要事件驱动的自动更新迭代功能
- 用户主动触发 → 系统生成草案 → 人工审核 → 生效

**新增文件：**
- `core/scripts/auto_update.py` - 自动更新迭代引擎

**更新文件：**
- `core/references/auto_learning.md` - 新增自动更新机制说明

**功能：**
1. 事件驱动触发分析（4种触发类型）
2. 自动提取教训和成功模式
3. 生成SKILL.md更新草案
4. 人工审核后生效

**触发类型：**
- book_complete：完成一本书
- chapter_complete：完成重要章节
- quality_issue：发现质量问题
- user_request：用户主动要求

**核心原则：**
- 不是定时自动，而是事件驱动
- 系统生成草案，人工审核确认
- P0级教训必须立即修复

---

## v1.13 更新(2026-06-10)— 补全与修补

### 一、关键修复

| 文件 | 问题 | 修复 |
|:---|:---|:---|
| `one_click_writer.py` | 模板路径 bug(`core/core/templates`) | 改为 `parent.parent / "templates"` |
| `quality_score.py` | 混合 markdown + Python 共 110 行 noise | 拆分到 `references/quality_scoring.md`,代码纯化 |
| `continuity_enforcer.py` | 文件 0 字节(声明已实现但未写) | 重写 456 行 P0 状态机 |
| `post_process.py` | 时段词典固化,`chapter_num` 引用 bug | 引入完整时段词典(SHICHEN+古代+现代+工作日) |
| `self_check.py` | 与 ContinuityEnforcer 重复实现 | 改为前端层,委托权威 P0 给 ContinuityEnforcer |
| `multi_agent.py` | 串行 + dry-run | 改 ThreadPoolExecutor 并行,接入 LLMClient |

### 二、新增文件

- `core/scripts/llm_client.py` — Anthropic SDK 封装(Prompt Caching + 批量 + 并行 + L1/L2/L3/L4 路由)
- `core/scripts/genre_validator.py` — 12 题材兼容性 P0/P1/LINT 校验
- `core/scripts/climax_tracker.py` — 爽点密度追踪(6 类爽点正则)
- `core/references/quality_scoring.md` — 评分规则文档
- `commands/*.md` — 7 个 slash 命令文档
- `genres/*/red_lines.md` — 12 题材红线(硬/软/LINT 三层)
- `examples/demo_wuxia/` — 武侠最小可运行示例(三章+四表)
- `tests/test_*.py` — pytest 测试 27 个,全部通过

### 三、用户校正记录

> "当前时段(凌晨/清晨/早晨/上午/中午...)这段你应该参考市面上的小说"

时段系统从写死列表升级为四套词典融合:
- 12 时辰(子/丑/寅/卯/辰/巳/午/未/申/酉/戌/亥)
- 古代描述性(拂晓/破晓/初更/二更/三更/夜半...)
- 现代(凌晨/清晨/早晨/上午/中午/午后/下午/傍晚/黄昏/夜间/夜晚/深夜)
- 工作日(早高峰/午休/晚高峰/下班后/宵夜时间)

跨日检测改用小时差(`delta < -6` 且无"次日/翌日"标记 → P0)。

### 四、完整度评估

| 维度 | 5月版 | 6月版 |
|:---|:---:|:---:|
| 核心脚本(7) | 5/7 完整 | 7/7 + 3新增 |
| 题材文档 | plot_templates ✓ | + red_lines ✓ |
| LLM 接入 | ❌ | ✓ (含 Prompt Caching) |
| 多 Agent | 串行 dry-run | 并行 + 接入 SDK |
| 测试覆盖 | ❌ | 27 个 pytest 全通过 |
| 示例项目 | ❌ | demo_wuxia 可跑通 |

**总体评级:95% → 99%**

---

## v1.14 更新(2026-06-10)— 文风印记自动注入

### 问题

12 题材的 `masterpiece_analysis.md` 写得详细(6 维度 + 关键技巧 + 主角档案),但**没有任何脚本读它**。`SKILL.md` 仅在文档列表里出现,LLMClient 的 `FrozenContext.worldview` 靠调用方手填,`prompt_caching.md` 里的 `_load_worldbuilding` 实际是占位符 `"（详见worldbuilding.md）"`。

**结果**:Skill 没有"学到"这些文风指纹,Claude 写作时不会自动获取。

### 修复

| 文件 | 改动 |
|:---|:---|
| `core/scripts/genre_style.py` (新) | 解析器:从 `masterpiece_analysis.md` 抽取流派/技巧/人设/节奏,压缩为 ~500 token 结构化印记 |
| `core/scripts/llm_client.py` | `FrozenContext.style_fingerprint` 新字段,与 worldview 一起进 cache_control 冻结前缀;`load_frozen_from_data` 接受 `genre` 参数 |
| `core/scripts/one_click_writer.py` | `init_project` 自动把文风印记写入 `data/style_fingerprint.json` |
| `examples/demo_wuxia/data/style_fingerprint.json` (新) | 现场生成的武侠印记,含 4 本精品 + 12 条技巧 + 主角档案 |
| `tests/test_genre_style.py` (新) | 22 个测试:全 12 题材 token 预算 ≤ 1200 / 含 4 本书 / cache 集成 / 固化优先于动态生成 |

### 文风印记输出样例 (wuxia, 518 token)

```
== 文风印记: wuxia ==
参考 4 本精品: 《雪中悍刀行》《最强boss系统》《死人经》《催妆》

== 核心流派与文字气质 ==
- 雪中悍刀行 流派: 诗意武侠
- 最强boss系统 流派: 武侠游戏化
- 死人经 流派: 黑暗武侠
- 催妆 流派: 武侠甜宠流

== 关键写作技巧 ==
- 《雪中悍刀行》 不只是主角,配角也有弧光
- 《最强boss系统》 武侠世界游戏化
- 《死人经》 复仇是唯一主线
- 《催妆》 感情戏是主线
...
```

### 测试结果

- 12 题材全数达标: 400-600 token / 12 条技巧 / 2-5 本书
- pytest: **49 passed**(从 27 增至 49)

### 加载优先级

1. `data/style_fingerprint.json`(项目固化,O(0) 读取)
2. `genre + skill_dir`(动态解析)
3. 空(向后兼容)

---

## v1.15 更新(2026-06-10)— Web UI + GitHub 打包

### 新增

| 文件 | 用途 |
|:---|:---|
| `ui/app.py` | Flask 后端,暴露 12 个 REST API(项目/四表/章节/写作/自检/评分/爽点/文风) |
| `ui/__main__.py` | `python -m ui` 启动入口 |
| `ui/templates/index.html` | 单页 SPA 骨架 |
| `ui/static/style.css` | 深色主题,无构建工具 |
| `ui/static/app.js` | 前端逻辑,API Key 存 localStorage |
| `ui/README.md` | UI 详解 + REST API 文档 |
| `scripts/start_ui.{sh,bat}` | 一键启动脚本 |
| `README.md` (重写) | GitHub 风格 README,badges / 快速开始 / 目录结构 |
| `LICENSE` | MIT |
| `requirements.txt` | flask + anthropic + pytest |
| `.gitignore` (扩展) | 新增 secrets / pytest_cache / UI runtime |

### Web UI 能力

| 页面 | 功能 |
|:---|:---|
| 📁 项目 | 创建/选择/删除;自动注入文风印记 + 四表模板 |
| ✍️ 写作 | L1-L4 写作、章节保存、连续性自检、质量评分、爽点密度 |
| 📊 四表 | 4 张表的 JSON 在线编辑与保存 |
| 🎨 文风 | 浏览 12 题材文风印记 |
| ⚙️ 设置 | Provider / API Key / Base URL / Model / Temperature / Max Tokens |

### API Key 安全

- 仅存浏览器 `localStorage`,不持久化到磁盘
- 服务端从不读 / 写 API Key
- 默认绑定 `127.0.0.1`;需公网用 `--host 0.0.0.0` + 自加反代

### 启动验证

```bash
# 后端
python -m ui --port 8765
# → http://127.0.0.1:8765

# 集成测试(已通过)
curl -X POST .../api/projects -d '{"name":"smoke_test","genre":"wuxia"}'  # 创建
curl .../api/projects/smoke_test/table/style_fingerprint.json               # 文风印记已注入
curl .../api/projects/smoke_test/table/timeline.json                       # 四表已就位
curl -X DELETE .../api/projects/smoke_test                                  # 清理
```

### GitHub 上传清单

```
根目录: README.md, LICENSE, requirements.txt, .gitignore, SKILL.md, ITERATION_LOG.md
核心:   core/scripts/, core/references/, core/templates/
题材:   genres/<12 题材>/*.{md}
命令:   commands/*.md
UI:     ui/{app.py, __main__.py, templates/, static/, README.md}
示例:   examples/demo_wuxia/
测试:   tests/*_*.py (49 用例)
脚本:   scripts/start_ui.{sh,bat}
```

**总体评级:99% → 100%** · 可上传 GitHub。




---

## v1.16 更新(2026-06-10)— 品牌「墨栈」+ 构思向导 UI

### 新需求

> 「优化 UI 界面,界面简单整洁,全中文的 UI 界面。并有类似 inkos 的:先选题材,再由作者撰写想法,你来撰写大纲、文章名称、简介的窗口。」
> 「UI 界面体现 SKILL 中文名称『墨栈』,最好生成 LOGO。」

### 品牌

| 字段 | 值 |
|:---|:---|
| 中文名 | **墨栈** (MoZhan) |
| Slogan | **一栈写尽万千江湖** |
| LOGO | `ui/static/logo.svg` — 古印+「墨」字简写+栈道横木,墨色/古印金双色 |
| 视觉系统 | 宣纸底 `#f7f4ec` + 墨色 `#1a2435` + 古印金 `#a07f3a`,衬线/无衬线混排 |

### 新增「构思工作流」(inkos 风格三步向导)

| 步骤 | 交互 | 后端 |
|:---|:---|:---|
| ① 选题材 | 12 题材卡片网格,emoji+中文名+英文名 | `/api/genres` + `/api/genre/<g>/style` |
| ② 写想法 | 多行输入 + 3 个示例 chip(侠义复仇/末世经营/都市商战) | — |
| ③ 看构思 | 模型返回 JSON → 渲染为可编辑卡片(书名/副标/简介/主角/主题/分卷大纲/前三章钩子) | `/api/conceive` |
| 落库 | 一键「建立项目并进入写作台」 → 自动建项目+写入文风印记+落 conceived.json | `/api/projects` + `/api/projects/<n>/conceived` |

### 新增/重写文件

| 文件 | 改动 |
|:---|:---|
| `ui/static/logo.svg` (新) | 「墨栈」LOGO,印章+墨字+栈道 |
| `ui/templates/index.html` (重写) | 三步向导 + 首页 + 写作台 + 设置,五区一气呵成 |
| `ui/static/style.css` (重写) | 宣纸色彩系统,Stepper、Card、Tab、Toast 完整组件库 |
| `ui/static/app.js` (重写) | `setPage` 路由、`enterConceive` 向导、`renderConceiveResult` 卡片编辑 |
| `ui/app.py` | `+/api/brand` `+/api/conceive` `+/api/projects/<n>/conceived` `+silent=True` 入 self_check |
| `core/scripts/self_check.py` | `run(..., silent=True)` 跳过 print,修复 Flask GBK 编码 500 |

### 后端 schema(`/api/conceive` 严格 JSON)

```json
{
  "title": "书名(4-8 字)",
  "subtitle": "副标题",
  "synopsis": "300-500 字简介,带钩子",
  "protagonist": {"name":"...","age":N,"identity":"...","motivation":"...","trait":"..."},
  "themes": ["主题1","主题2","主题3"],
  "outline": [{"arc":"卷名","chapters":"1-20","key":"核心"}, ...],
  "first_three_chapters": [{"num":1,"title":"...","hook":"..."}, ...]
}
```

### 视觉关键决策

| 元素 | 取舍 | 理由 |
|:---|:---|:---|
| 配色 | 宣纸底 + 墨色文字 | 比深色科技风更贴中文文学气质 |
| 字体 | `font-serif` (Noto/Source Han/Songti) | 标题、书名、章节正文用衬线;UI 控件用无衬线 |
| 导航 | 顶栏横排 4 入口 | 比侧栏更利落,集中注意力 |
| LOGO | 古印章风格 | 与品牌「墨栈」呼应,SVG 可缩放 |
| 加载 | 古印金旋转环 | 与品牌色一致,不用绿色或蓝色 |

### 端到端验证(已通过)

| 测试 | 结果 |
|:---|:---|
| `GET /` 返回 10372B 新模板 | ✓ |
| `GET /static/logo.svg` 1504B | ✓ |
| `GET /api/brand` → `{name_cn:"墨栈"...}` | ✓ |
| `GET /api/genres` 返 12 题材 | ✓ |
| `POST /api/conceive` 无 idea → 友好 400 | ✓ |
| `POST /api/conceive` 无 key → 友好错误 | ✓ |
| `PUT/GET /api/projects/<n>/conceived` 持久化 | ✓ |
| `POST /api/projects/<n>/check` silent=True → 不再 500 | ✓(p0/p1/lint=0/0/2 全通过) |

### 用户旅程对比

| 维度 | v1.15 | v1.16 |
|:---|:---|:---|
| 起手式 | 「创建项目」表单 | 「开始构思新书」CTA |
| 题材选择 | 下拉框 | 12 张卡片网格 |
| 内容生成 | 用户写所有字段 | 用户写想法,墨栈生成书名/简介/大纲 |
| 视觉氛围 | 深色技术工具 | 宣纸古印文学气质 |
| 品牌识别 | NWU 字母 | 墨栈 LOGO + Slogan |  ←  v1.16 之后仓库改名为 mozhan |




---

## v1.17 更新(2026-06-10)— 9 平台调性 + 四步向导 + P0 一致性锚定

> 本轮重点:把 v1.16 的"三步构思"升级为"四步构思(选题材+平台/写想法/定规模/看构思)";新增 9 大网文平台调性档案;修复 P0 主角/简介脱钩问题。

### 1. 9 大网文平台调性档案

core/scripts/platform_profiles.py 落地:番茄/书旗/七猫/起点/晋江/飞卢/刺猬猫/知乎/公众号 9 家平台。每个平台包含:

- 读者画像、书名套路、简介规则
- 章节字数(自动按 L1-L4 浮动)
- 题材亲和度、调性提醒

平台规则在构思 + 写作两道 system prompt 都注入,书名/简介/章节字数全自动适配。

### 2. 四步构思向导(代替三步)

`
[1] 选题材 + 平台(12 × 9,平台可不选)
       ↓
[2] 写想法(题材决定推荐种子点子)
       ↓
[3] 定规模(总字数 + 总章节,4 档预设)
       ↓
[4] 看构思(书名/简介/主角/分卷 + 完整 N 章大纲,逐章带钩子)
`

关键升级:第 4 步不再只给"分卷 + 前 3 章",而是按总章节数生成完整章纲(rcs = max(3, 总章/35)),落到 data/outline_full.json。

### 3. P0 主角/简介一致性锚定(本轮核心修复)

**问题**:旧版构思了主角"陆沉",写章节时模型常改写成"李轩/林北/楚风"。

**根因**:uild_frozen_system 不读 conceived.json,主角名/身份/简介对模型不可见。

**修复**:
- uild_frozen_system 现在自动读 conceived.json,把主角名/身份/动机/简介/主题作为「**核心设定(强约束,不得擅自修改)**」插入 system prompt 第一段
- 构思 + 写作 prompt 都加「**保真硬约束 — 最高优先级**」三条铁规
- 新增 GET /api/projects/<n>/chapter/<num>/consistency 自动校验
- 写作台「自检」按钮已合并这个端点

### 4. 端到端验证

| 测试 | 结果 |
|:---|:---|
| GET /api/platforms 返回 9 平台 | ✓ |
| POST /api/conceive 带 platform → 文风字数自动适配 | ✓ |
| 主角"陆沉"构思后,写章节 API 返回文中含「陆沉」| ✓(已修复) |
| 写作台「📚 大纲」tab 全文搜索 + 回填 | ✓ |
| 大纲过滤后「回填 →」按钮仍可点(事件委托) | ✓ |
| GET /api/projects/<n>/chapter/<num>/consistency | ✓ |
| un-conceive 守卫(总字数 ≥ 1 万,总章数 ≥ 5) | ✓ |

### 5. 与之前版本对比

| 维度 | v1.16 | v1.17 |
|:---|:---|:---|
| 构思步骤 | 3 步(题材/想法/结果) | **4 步**(加平台 + 规模) |
| 平台适配 | 无 | **9 家网文平台自动调性** |
| 章节大纲 | 3 章钩子 | **N 章完整大纲**(按总章节) |
| 主角名保真 | 经常跑偏 | **P0 锚定** + consistency 端点 |
| 章纲落库 | conceived.json | **+ outline_full.json** |
| 写作台 tab | 写/表/文风 | **+ 大纲**(搜索 + 回填) |

---

## v1.18 更新(2026-06-11)— 目录合并 + UI 中文化

> 本轮重点:把 novel-writer-universal/ 合并到 mozhan/(删除 nwu);把四表/简介 tab 从 JSON 原文升级为中文结构化视图。

### 1. 目录合并
- nwu/projects/  ->  mozhan/projects/ (含 魔尊在我体内、杂役逆天_残功吞天)
- nwu/test_wuxia.md  ->  mozhan/examples/test_wuxia.md
- nwu/.git/(空仓库) -> 已删除
- 同步后六个核心文件 SHA-256 一致:SKILL.md / CHANGELOG.md / README.md / ITERATION_LOG.md / ui/static/app.js / ui/static/style.css / ui/templates/index.html

### 2. UI 中文化
- 新增 FIELD_LABELS / VALUE_LABELS 字典 + renderTableCN 渲染器
- 四表 tab 改为中文结构化表格:时间线/角色/伏笔/物品
- 简介 tab 改为中文卡片
- JSON 模式可切换

### 3. 端到端验证(已通过)

| 测试 | 结果 |
|:--|:--:|
| 13 个 .py 文件花括号/括号配对 | 全部平衡 |
| app.js 反引号配对 | 47 对偶数 |
| node --check app.js | 通过 |
| Node 端到端模拟 4 表渲染 | 全部中文 |

