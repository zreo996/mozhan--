# 多 Agent 会诊机制 (Multi-Agent Consultation)

## 重要澄清：两个独立机制

本文档描述的是**多角色会诊**机制——单一模型通过不同prompt扮演多个专家角色，用于**写作任务**。

> **注意**：这不是"多模型并行"架构，而是"单模型多角色"架构。实际执行中，通过prompt模板引导同一模型模拟不同专家，而不是真正启动多个模型实例。

另一个独立机制——**三方辩证**——用于**SKILL迭代优化**，是真正的多模型辩论，详见 `ITERATION_LOG.md`。

| 机制 | 架构 | 用途 | 成本 |
|:---|:---|:---|:---|
| **多角色会诊** | 单模型多角色 | 写作任务协同 | 低（1次调用） |
| **三方辩证** | 多模型辩论 | SKILL迭代优化 | 高（3模型） |

> 两者是完全独立的机制，切勿混淆。

---

## 架构设计

```
┌─────────────────────────────────────────────────────────────┐
│ 主 Agent（NovelWriter）                                      │
│ - 负责任务分解、协调、最终整合                               │
│ - 持有全局上下文（四表）                                    │
└────────────────────┬────────────────────────────────────────┘
                     │
       ┌─────────────┼─────────────┬─────────────┐
       ▼             ▼             ▼             ▼
┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐
│ 场景专家  │  │ 对话专家  │  │ 情节专家  │  │ 设定专家  │
│ Scene    │  │ Dialogue │  │ Plot     │  │ Setting  │
│ (prompt │  │ (prompt │  │ (prompt │  │ (prompt │
│  模拟)   │  │  模拟)   │  │  模拟)   │  │  模拟)   │
└──────────┘  └──────────┘  └──────────┘  └──────────┘

注：四个专家不是四个独立模型，而是同一模型通过不同prompt模板
    扮演的不同角色。实际运行时，主Agent按需调用各"专家"的prompt。
```

---

## Agent 职责定义

### 1. 场景专家 (Scene Expert)

**职责**：负责环境、氛围、场景转换的具体写作

**Prompt 模板**：
```
你是一个专业的场景描写专家。专注于：
- 环境细节的具体化（颜色、声音、气味、触感）
- 氛围营造（紧张、轻松、诡异、温馨）
- 场景之间的自然过渡
- 感官描写的层次感

当前场景要求：
{scene_requirements}

请输出该场景的详细描写（约 500 字）。
```

**使用场景**：L2/L3/L4 章节的场景描写部分

---

### 2. 对话专家 (Dialogue Expert)

**职责**：负责角色对话、性格体现、情感表达

**Prompt 模板**：
```
你是一个专业的对话写作专家。专注于：
- 角色专属语言风格（口头禅、说话方式）
- 对话的信息增量（不说废话）
- 潜台词和言外之意
- 角色关系的动态变化

角色设定：
{character_profile}

对话情境：
{dialogue_situation}

请输出该对话场景（约 800 字，含 2-3 个角色的对话）。
```

**使用场景**：L2/L3/L4 章节的感情线、冲突对话

---

### 3. 情节专家 (Plot Expert)

**职责**：负责情节推进、节奏把控、伏笔布局

**Prompt 模板**：
```
你是一个专业的情节设计专家。专注于：
- 情节点的起承转合
- 节奏把控（张弛有度）
- 伏笔的埋设与回收
- 悬念的制造与释放

当前情节上下文：
{plot_context}

伏笔追踪：
{hooks_status}

请输出该情节段的详细设计（约 1000 字）。
```

**使用场景**：L3/L4 章节的核心情节、高潮场景

---

### 4. 设定专家 (Setting Expert)

**职责**：负责世界观设定、修炼/科技体系、势力格局

**Prompt 模板**：
```
你是一个专业的世界观设定专家。专注于：
- 世界观规则的一致性
- 修炼/科技体系的逻辑自洽
- 势力格局的合理分布
- 细节设定的可执行性

当前题材：{genre}
当前场景涉及的系统：{system_requirements}

请输出/验证该设定的合理性。
```

**使用场景**：新地图开启、新的修炼等级、科技突破

---

## 会诊流程

### L1 常规章
```
主 Agent 独立完成，无需会诊
```

### L2 关键章
```
触发条件（满足任一）：
- 本章有新角色首次出场
- 本章涉及角色关系变化 ≥1 处
- 本章有场景转换（跨区域）

流程：
1. 主 Agent 分解任务
2. 满足条件时调用对话专家/场景专家
3. 主 Agent 整合
4. self_check.py 检查
5. 交付
```

### L3 核心章
```
触发条件（满足任一）：
- 本章是小英雄之旅的"合"（完整起承转合）
- 本章涉及主线推进
- 本章有新地图/新势力开启

流程：
1. 主 Agent 分解任务
2. 场景专家 → 场景描写
3. 对话专家 → 核心对话
4. 情节专家 → 情节设计
5. 主 Agent 整合 + 润色
6. P0+P1 检查
7. P2 润色（如需要）
8. 交付
```

### L4 宏篇章
```
触发条件（满足任一）：
- 涉及中英雄之旅的重大转折
- 涉及大英雄之旅的高潮前奏
- 涉及全书高潮或世界观揭秘

流程：
1. 主 Agent 弧线规划
2. 设定专家 → 世界观一致性验证
3. 情节专家 → 多版本情节设计
4. 场景专家 → 关键场景描写
5. 对话专家 → 核心对话
6. 主 Agent 版本融合
7. 全局一致性验证
8. 三层检查
9. 交付
```

---

## 通信机制

```python
class AgentMessage:
    def __init__(self, from_agent, to_agent, content, type):
        self.from_agent = from_agent
        self.to_agent = to_agent
        self.content = content
        self.type = type  # request/response/feedback

class AgentChatRoom:
    def __init__(self, agents):
        self.agents = {a.name: a for a in agents}
        self.messages = []

    def send(self, from_name, to_name, content):
        msg = AgentMessage(from_name, to_name, content, "request")
        self.messages.append(msg)
        # 路由到目标 Agent
        response = self.agents[to_name].handle(msg)
        return response

    def broadcast(self, from_name, content):
        for agent_name in self.agents:
            if agent_name != from_name:
                self.send(from_name, agent_name, content)
```

---

## 实现示例

```python
def write_chapter_with_consultation(chapter_num, chapter_data, agents):
    """带多 Agent 会诊的章节写作"""

    if chapter_data["level"] == "L1":
        # L1 简单处理
        return simple_write(chapter_data)

    elif chapter_data["level"] == "L2":
        # L2 需要时调用专家
        scene_text = None
        if chapter_data.get("need_scene"):
            scene_response = agents["scene"].process({
                "task": "场景描写",
                "context": chapter_data["context"]
            })
            scene_text = scene_response["output"]

        return integrate_chapter(scene=scene_text, other=chapter_data)

    elif chapter_data["level"] in ["L3", "L4"]:
        # L3/L4 全员会诊
        # 并行调用
        scene_future = agents["scene"].process_async(...)
        dialogue_future = agents["dialogue"].process_async(...)
        plot_future = agents["plot"].process_async(...)

        # 收集结果
        scene_text = scene_future.result()
        dialogue_text = dialogue_future.result()
        plot_design = plot_future.result()

        # 主 Agent 整合
        return agents["main"].integrate({
            "scene": scene_text,
            "dialogue": dialogue_text,
            "plot": plot_design,
            "context": chapter_data["context"]
        })
```

---

## 何时使用

| 场景 | 应该调用 |
|:---|:---|
| 战斗场景 | 场景专家 + 情节专家 |
| 感情对话 | 对话专家 + 情节专家 |
| 新地图开启 | 设定专家 + 场景专家 |
| 世界观揭秘 | 设定专家 + 情节专家 |
| 高潮决战 | 全员会诊 |
| 日常过渡 | 仅主 Agent |