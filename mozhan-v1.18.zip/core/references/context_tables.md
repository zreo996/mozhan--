# 四张数据表结构 (Context Tables)

## 核心原则

四张表是整个写作系统的上下文核心，每个 Agent 按需加载：
- **永远不砍**：timeline、active hooks、前 1 章全文
- **按需加载**：角色详情、物品详情、dormant hooks
- **自动更新**：post_process.py 每次写完章后自动更新

---

## 表一：timeline.json（时间线）

### 结构
```json
{
  "global_day": 15,
  "storylines": {
    "main": [
      {"day": 15, "period": "上午", "event": "主角在长安城酒楼遇到神秘人", "location": "长安城·醉仙楼", "characters": ["主角", "配角A"]}
    ],
    "sub": [],
    "villain": []
  },
  "sync_points": [
    {"day": 15, "description": "下午主副线在长安城交汇"}
  ]
}
```

### 硬性上限
- **events ≤ 2000 条**：超出时合并 oldest 事件
- **storylines 每线 ≤ 500 条**：超量时归档
- **sync_points ≤ 100 条**：交汇点标记

### 核心规则
- **day 单调递增**：不倒退
- **period 顺序**：凌晨 → 上午 → 中午 → 下午 → 傍晚 → 夜间 → 子时（不可逆序）
- **每条事件含 5W**：Who、When、Where、What、Why
- **多线并行**：main/sub/villain 三线，sync_points 标记交汇点
- **跨时段跳跃**：需在 event 中说明（如"三天后"）

### 使用场景
- 加载全部 timeline（约 500 tokens）
- 检测时间线矛盾（P0-1）
- 判断角色位置（结合 characters_snapshot）

---

## 表二：characters_snapshot.json（角色快照）

### 结构
```json
{
  "characters": [
    {
      "id": " protagonist",
      "name": "主角",
      " cultivation_level": "金丹初期",
      "location": "长安城·醉仙楼",
      "last_moved": {"day": 15, "period": "上午", "from": "城外荒野", "to": "长安城"},
      "status": "正常",  // 正常/受伤/中毒/昏迷/死亡
      "mood": "警觉",    // 情绪状态
      "inventory": ["玄铁剑", "解毒丹×3"],
      "active_hooks": ["神秘人的警告"],
      "relationship": {"配角A": "信任", "反派B": "敌对"}
    }
  ]
}
```

### 硬性上限
- **active characters ≤ 50 人**：超出时归档退场角色
- **每角色 inventory items ≤ 20 件**：超量时合并/归档
- **relationship 字段 ≤ 30 条**：超量时只保留高张力关系

### 核心规则
- **last_moved 防瞬移**：记录每次移动的 day/period/from/to
- **修为不倒退**：cultivation_level 只升不降（除特殊情况）
- **退场角色标记**：status 为"死亡"/"退隐"后不再使用
- **同区域才能交互**：不同 location 的角色不可直接对话/战斗

### 使用场景
- 加载全部 active characters（约 300 tokens/角色）
- 检测位置漂移（P0-2）
- 检测修为倒退（P0-3）
- 检测角色幽灵（P0-6）

---

## 表三：hooks.json（伏笔追踪）

### 结构
```json
{
  "active": [
    {
      "id": "hook_001",
      "name": "神秘人的警告",
      "introduced_day": 10,
      "introduced_chapter": 8,
      "content": "主角在城外遇到神秘人，被警告'三月内必有血光之灾'",
      "status": "active",
      "chapter_last_seen": 15,
      "related_characters": ["主角", "神秘人"],
      "tension": "高"
    }
  ],
  "dormant": [
    {
      "id": "hook_002",
      "name": "古剑之灵",
      "introduced_day": 5,
      "content": "主角在古墓中获得一把残剑，剑中有微弱的灵识",
      "dormant_since_chapter": 20,
      "dormant_reason": "等待主角修为提升",
      "recovery_condition": "主角突破金丹期"
    }
  ],
  "recovered": [
    {
      "id": "hook_003",
      "name": "解毒丹线索",
      "introduced_chapter": 12,
      "recovered_chapter": 25,
      "summary": "主角在第25章找到解毒丹，解除了神秘人的诅咒"
    }
  ]
}
```

### 硬性上限
- **active hooks ≤ 30 条**：超量时强制转入 dormant 或回收
- **dormant hooks ≤ 50 条**：超量时合并相似项
- **每 hook related_characters ≤ 5 人**：超量时只保留核心关联

### 核心规则
- **active 超 3 章未回收 → FATAL**（P0-4）
- **active 超 10 章未回收 → 建议转入 dormant**
- **回收后移入 recovered**，作为历史记录
- **每条 hook 含**：引入章节、当前章节、相关角色、张力等级

### 使用场景
- 加载全部 active hooks（约 500 tokens）
- 检测伏笔丢失（P0-4）
- 检测伏笔断裂（P1-3）
- 触发伏笔回收提醒

---

## 表四：inventory.json（物品追踪）

### 结构
```json
{
  "items": [
    {
      "id": "item_001",
      "name": "玄铁剑",
      "type": "weapon",      // weapon/armor/consumable/clue/key
      "rarity": "稀有",
      "owner": "主角",
      "acquired_chapter": 5,
      "location": "主角腰间",
      "status": "owned",    // owned/used/consumed/lost
      "description": "重约三十斤，剑身泛黑光，可破金丹期防御"
    },
    {
      "id": "item_002",
      "name": "解毒丹×3",
      "type": "consumable",
      "owner": "主角",
      "acquired_chapter": 10,
      "remaining": 2,
      "used_history": [
        {"chapter": 18, "reason": "解除蛇毒", "remaining_after": 2}
      ]
    },
    {
      "id": "item_003",
      "name": "神秘玉佩",
      "type": "clue",
      "owner": "神秘人",
      "introduced_chapter": 8,
      "clue_status": "active",
      "clue_description": "玉佩上刻有未知符文，似乎与上古遗迹有关",
      "chapter_last_mentioned": 15
    }
  ]
}
```

### 硬性上限
- **items ≤ 100 件**：全局总量
- **consumable remaining ≥ 1**：提醒；=0 时 status 变为 consumed
- **clue 物品 ≤ 20 件**：超量时合并

### 核心规则
- **consumable 标记 used**：每使用一次 remaining 减 1，remaining=0 时 status 变为 consumed
- **clue 超 3 章未回收 → 提醒**（可能变成死线索）
- **key 物品不可丢失**：结局关键物品全程追踪
- **每条物品含**：获得章节、当前位置、使用历史

### 使用场景
- 加载全部 items（约 200 tokens）
- 检测物品消失（P0-5）
- 触发消耗品提醒
- 触发线索物品回收提醒

---

## 四表联动规则

```
章节完成后
    ↓
post_process.py 分析本章事实
    ↓
更新 timeline（新增事件）
    ↓
更新 characters_snapshot（位置/修为/情绪变动）
    ↓
更新 hooks（识别新伏笔/回收旧伏笔）
    ↓
更新 inventory（物品获得/使用/消耗）
    ↓
触发 self_check.py 五重检查
    ↓
有问题 → 回修
    ↓
无问题 → 交付
```

---

## 分级加载策略

| 等级 | 加载内容 |
|:---|:---|
| L1 | 四表全部 + 前3章摘要 + 前1章全文 |
| L2 | 四表全部 + 前5章全文 + 相关hooks |
| L3 | 四表全部 + 前10章全文 + 所有hooks + 人物小传 |
| L4 | 全局快照 + 前后20章全文 + 全部hooks历史 + 全部角色档案 |