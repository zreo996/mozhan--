# Prompt 缓存优化指南

## 核心原则

**将不变的内容放在前缀，可变内容放在末尾。**

```
┌─────────────────────────────────────────────────────────────┐
│ 冻结区（稳定不变，利用缓存节省约 90%）                        │
├─────────────────────────────────────────────────────────────┤
│ 1. 系统角色定义                                             │
│ 2. 题材专项设定                                             │
│ 3. 四表结构（timeline/characters/hooks/inventory）          │
│ 4. 红线质量体系                                            │
│ 5. 当前项目基本信息                                         │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ 动态区（每次变化，通过 messages 注入）                       │
├─────────────────────────────────────────────────────────────┤
│ 1. 当前章节号和章节标题                                     │
│ 2. 具体的写作任务/问题                                      │
│ 3. 上一轮对话的内容                                         │
│ 4. 需要检查的具体问题                                       │
└─────────────────────────────────────────────────────────────┘
```

---

## 分级缓存策略

### L1 常规章

**冻结区**（约 3,500 tokens）：
```
- 系统角色：你是一个专业中文小说作家
- 题材设定：当前题材的 worldbuilding 摘要
- 四表全部内容
- 写作风格指南
```

**动态区**（约 4,000 tokens）：
```
- 当前章：第 N 章
- 本章大纲
- 前 1 章全文
- 具体任务：写第 N 章
```

### L2 关键章

**冻结区**（约 8,000 tokens）：
```
- 系统角色 + 题材设定 + 四表
- 前 5 章摘要
- active hooks 详情
- 写作风格指南
```

**动态区**（约 13,000 tokens）：
```
- 当前章 + 大纲 + 前 5 章全文
- 具体任务 + 检查要点
```

### L3/L4 核心章

**冻结区**（约 20,000 tokens）：
```
- 系统角色 + 题材设定 + 四表
- 全部大纲
- 人物小传
- 全部 hooks（含 dormant）
```

**动态区**（约 25,000+ tokens）：
```
- 当前章 + 详细规格
- 具体任务 + 质量要求
```

---

## Prompt Caching 实现

### Anthropic SDK 示例

```python
from anthropic import Anthropic

client = Anthropic()

# 冻结区（会被缓存）
system_prompt = """
你是一个专业的中文长篇小说作家。
当前项目：《{title}》
题材：{genre}
写作风格：{style}
...
"""

# 动态区通过 messages 注入
messages = [
    {"role": "user", "content": "写第3章，具体要求：..."}
]

# 使用 cache_control 自动缓存最后一块
response = client.messages.create(
    model="claude-opus-4-7",
    max_tokens=64000,
    cache_control={"type": "ephemeral"},
    system=system_prompt,
    messages=messages
)

# 检查缓存效果
print(f"Cache read: {response.usage.cache_read_input_tokens}")
print(f"Total tokens: {response.usage.input_tokens + response.usage.output_tokens}")
```

---

## 自适应思考模式（L3/L4 专用）

```python
# 对于 L3/L4 核心章，启用自适应思考
response = client.messages.create(
    model="claude-opus-4-7",
    max_tokens=64000,
    thinking={
        "type": "adaptive",
        "budget_tokens": 8000  # 思考预算
    },
    output_config={"effort": "high"},
    system=system_prompt,
    messages=messages
)

# 处理响应
for block in response.content:
    if block.type == "thinking":
        print(f"思考过程: {block.thinking}")
    elif block.type == "text":
        print(f"输出: {block.text}")
```

---

## 版本快照机制

每次完成以下节点时，自动保存四表快照：

```python
import json
from datetime import datetime
from pathlib import Path

class SnapshotManager:
    def __init__(self, project_dir):
        self.project_dir = Path(project_dir)
        self.snapshots_dir = self.project_dir / "snapshots"
        self.snapshots_dir.mkdir(exist_ok=True)

    def save_snapshot(self, chapter_num, data_dir):
        """保存章节完成时的四表状态"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

        snapshot = {
            "chapter": chapter_num,
            "timestamp": timestamp,
            "timeline": self._load_json(data_dir / "timeline.json"),
            "characters": self._load_json(data_dir / "characters_snapshot.json"),
            "hooks": self._load_json(data_dir / "hooks.json"),
            "inventory": self._load_json(data_dir / "inventory.json")
        }

        snapshot_path = self.snapshots_dir / f"chapter_{chapter_num:03d}_{timestamp}.json"
        with open(snapshot_path, 'w', encoding='utf-8') as f:
            json.dump(snapshot, f, ensure_ascii=False, indent=2)

        self._update_metadata(chapter_num, snapshot_path)

        return snapshot_path

    def _load_json(self, path):
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return {}

    def _update_metadata(self, chapter_num, snapshot_path):
        metadata_path = self.snapshots_dir / "metadata.json"
        metadata = self._load_json(metadata_path)

        metadata[str(chapter_num)] = {
            "path": str(snapshot_path),
            "chapter": chapter_num,
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }

        with open(metadata_path, 'w', encoding='utf-8') as f:
            json.dump(metadata, f, ensure_ascii=False, indent=2)

    def restore_snapshot(self, chapter_num):
        """恢复到指定章节的快照"""
        metadata_path = self.snapshots_dir / "metadata.json"
        metadata = self._load_json(metadata_path)

        if str(chapter_num) not in metadata:
            raise ValueError(f"快照不存在：chapter_{chapter_num}")

        snapshot_path = metadata[str(chapter_num)]["path"]
        with open(snapshot_path, 'r', encoding='utf-8') as f:
            snapshot = json.load(f)

        return snapshot
```

---

## 缓存最佳实践

1. **保持冻结区稳定**：不要在系统提示词中插入时间戳、用户ID等动态变量
2. **利用前缀匹配**：缓存是前缀匹配，确保不变的内容在前面
3. **批量请求**：相邻章节使用相同的系统提示词，最大化缓存命中
4. **监控缓存效率**：定期检查 `cache_read_input_tokens` 指标

---

## 与 one_click_writer.py 集成说明

`prompt_caching.md` 中的 SDK 示例（Anthropic）需要根据实际使用的模型进行适配。

### Prompt Builder 示例（通用模板）

以下是一个 `prompt_builder.py` 的实现框架，实际使用时替换模型调用部分：

```python
#!/usr/bin/env python3
"""
Prompt构建器 - 用于构建带有冻结区/动态区分离的system prompt
"""

class PromptBuilder:
    def __init__(self, project_dir):
        self.project_dir = project_dir
        self.frozen_prompt = self._build_frozen_prompt()
    
    def _build_frozen_prompt(self) -> str:
        """构建冻结区 - 项目级配置，这部分会被缓存"""
        # 实际项目中从配置文件读取
        config = self._load_project_config()
        
        return f"""
你是一个专业的中文长篇小说作家。

## 项目信息
- 书名：《{config.get('title', '未命名')》
- 题材：{config.get('genre', '玄幻')}
- 世界观：详见下方设定

## 核心设定
{self._load_worldbuilding()}

## 四表上下文（当前状态）
{self._load_context_tables()}

## 写作规范
- 黄金三章法则：第1章钩子+第2章冲突+第3章转折
- 英雄之旅嵌套：大→中→小→微循环
- P0红线：时间线矛盾/位置漂移/修为倒退 禁止
- 每次写章后调用post_process.py更新四表

## 当前章信息
{{chapter_info}}

现在开始写作。
"""
    
    def build_chapter_prompt(self, chapter_num, level, outline, context):
        """构建单章写作的完整prompt"""
        chapter_info = f"""
## 本章信息
- 章节号：第{chapter_num}章
- 等级：{level}
- 大纲：{outline}
- 前文摘要：{context.get('summary', '')}
- 当前角色：{context.get('current_characters', '')}
- 伏笔状态：{context.get('active_hooks', '')}
"""
        
        return self.frozen_prompt.replace("{{chapter_info}}", chapter_info)
    
    def _load_project_config(self):
        """加载项目配置"""
        import json
        config_path = self.project_dir / "config.json"
        if config_path.exists():
            with open(config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {}
    
    def _load_worldbuilding(self):
        """加载世界观设定"""
        # 从各题材的worldbuilding.md读取
        return "（详见worldbuilding.md）"
    
    def _load_context_tables(self):
        """加载四表"""
        # 从data目录读取四表JSON
        return "（详见四表）"
```

> **注意**：缓存机制依赖于具体模型SDK（如 Anthropic 的 `cache_control`）。上述 `PromptBuilder` 构建了分离结构，实际缓存需要根据所使用的模型API实现。

---