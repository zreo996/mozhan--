# 成本优化体系 (Cost Optimization)

## 核心目标

**在保证质量的前提下，最大程度减少 API 调用次数和 Token 用量。**

---

## 成本控制矩阵

| 等级 | 原方案 Token | 优化后 Token | 节省比例 | API 调用 | 优化策略 |
|:---|:---:|:---:|:---:|:---:|:---|
| L1 | 7,600 | 4,500 | ~41% | 2→1 | 批量生成+自检 |
| L2 | 21,800 | 12,000 | ~45% | 4→2 | 规格复用+并行 |
| L3 | 42,500 | 25,000 | ~41% | 5-6→3-4 | 缓存+多版本融合 |
| L4 | 80,000+ | 50,000 | ~37% | 8-10→5-6 | 全局规划+增量更新 |

---

## 优化策略详解

### 策略一：上下文压缩（Context Compression）

**原理**：将信息压缩为更少的 token 但保留关键信息

```python
# 原方案：前 5 章全文（50,000 tokens）
# 优化后：情节简报（500 tokens）

前5章情节简报格式：
"""
第21-25章简报：
- 主线：主角在灵台山修炼，突破筑基
- 关键事件：获得玄铁剑（第22章）、结识师妹（第23章）
- 伏笔状态：神秘人伏笔 active（第21章埋）
- 角色状态：主角金丹初期、配角师妹练气巅峰
- 物品状态：玄铁剑（持有中）、解毒丹×3
"""
```

**节省**：50,000 tokens → 500 tokens（节省 99%）

---

### 策略二：批量生成（Batch Writing）

**适用**：L1 常规章（占比 60%）

**原理**：一次 API 调用生成多章草稿

```python
def batch_write_l1(chapters_range, outline, context):
    """批量生成 L1 章节"""
    prompt = f"""
    请按照以下大纲，连续生成第 {chapters_range[0]} 章到第 {chapters_range[1]} 章。
    每章约 3000 字。

    大纲：
    {outline}

    四表状态：
    {context}

    要求：
    - 每章独立成篇，有开头结尾
    - 章与章之间衔接自然
    - 符合四表状态
    """

    # 一次 API 调用生成多章
    response = client.messages.create(
        model="claude-sonnet-4-6",  # 用便宜模型
        max_tokens=64000,
        messages=[{"role": "user", "content": prompt}]
    )

    # 解析多章内容
    chapters = parse_multi_chapters(response)
    return chapters
```

**节省**：2 次 API × 60 章 → 1 次 API × 20 批 = 节省 50% API 调用

---

### 策略三：规格复用（Spec Reuse）

**适用**：L2 关键章

**原理**：同一类型场景复用规格模板

```python
# 战斗场景模板
BATTLE_SPEC_TEMPLATE = """
战斗场景规格：
- 开头：双方对峙，简述实力对比（200字）
- 发展：试探性攻击（500字）
- 高潮：全力一击+意外转折（1000字）
- 结局：胜负+后续影响（500字）

关键要素：
- 战斗结果要有铺垫
- 至少一个意外变量
- 结束后角色状态变化
"""

# 情感场景模板
EMOTION_SPEC_TEMPLATE = """
情感场景规格：
- 开头：当前情感状态（200字）
- 发展：情感触发事件（800字）
- 高潮：情感爆发（500字）
- 结尾：情感余韵+后续影响（500字）

关键要素：
- 情感要有渐进
- 避免突然倒贴
- 动作/表情代替心理独白
"""
```

**节省**：每次 L2 章节减少 1 次规格生成 API 调用

---

### 策略四：Prompt 缓存（Prompt Caching）

**原理**：利用 Claude 的缓存机制，相同内容只加载一次

```python
# 分层缓存策略

# 第一层：冻结区（始终缓存）
FROZEN_CONTEXT = """
你是一个专业中文小说作家。
题材：玄幻
四表结构：
- timeline: 时间线追踪
- characters: 角色状态
- hooks: 伏笔追踪
- inventory: 物品追踪
写作风格：...
"""

# 第二层：半稳定区（按题材/项目缓存）
STABLE_CONTEXT = """
当前项目：《XXX》
当前章节：第N章
主角设定：...
世界观设定：...
"""

# 第三层：动态区（每次变化）
DYNAMIC_CONTEXT = """
本章任务：写第N章
本章大纲：...
具体要求：...
"""
```

---

### 策略五：增量更新（Incremental Update）

**适用**：L4 宏篇章

**原理**：不每次加载全部历史，只加载变化部分

```python
class IncrementalContext:
    """增量上下文管理"""

    def __init__(self):
        self.base_context = None  # 基础上下文（缓存）
        self.delta_contexts = []  # 增量变化

    def update(self, new_chapters):
        """只追加新章节，不重复加载历史"""
        self.delta_contexts.append({
            "chapters": new_chapters,
            "timestamp": datetime.now()
        })

    def get_context(self, target_chapter):
        """获取到目标章节为止的完整上下文"""
        # 基础上下文 + 增量变化
        return self.base_context + self.delta_contexts

    def cleanup_old_deltas(self, keep_last_n=5):
        """清理旧增量，只保留最近N个"""
        if len(self.delta_contexts) > keep_last_n:
            # 合并旧增量为新的基础上下文
            old_deltas = self.delta_contexts[:-keep_last_n]
            self.base_context = self._merge(old_deltas)
            self.delta_contexts = self.delta_contexts[-keep_last_n:]
```

---

### 策略六：并行处理（Parallel Processing）

**适用**：L3/L4 核心章

**原理**：场景/对话/情节并行生成，减少串行等待

```python
async def write_l3_parallel(chapter_data):
    """L3 并行写作"""

    # 并行启动多个任务
    scene_task = scene_expert.process_async(chapter_data["scene_requirements"])
    dialogue_task = dialogue_expert.process_async(chapter_data["dialogue_requirements"])
    plot_task = plot_expert.process_async(chapter_data["plot_requirements"])

    # 等待所有任务完成
    scene_result = await scene_task
    dialogue_result = await dialogue_task
    plot_result = await plot_task

    # 主 Agent 整合
    final_chapter = main_agent.integrate({
        "scene": scene_result,
        "dialogue": dialogue_result,
        "plot": plot_result
    })

    return final_chapter

# 时间对比：
# 串行：10分钟（3个任务各3分钟 + 1分钟整合）
# 并行：4分钟（取最大者3分钟 + 1分钟整合）
```

---

### 策略七：廉价模型路由（Cheap Model Routing）

**原理**：简单任务用便宜模型，复杂任务才用顶级模型

| 任务类型 | 推荐模型 | 单价比例 |
|:---|:---|:---:|
| L1 规格生成 | Haiku | 1/40 |
| L1 正文生成 | Sonnet | 1/5 |
| P1 审计 | Haiku | 1/40 |
| P2 润色 | Sonnet | 1/5 |
| L3/L4 创意 | Opus | 1 |
| L3/L4 整合 | Sonnet | 1/5 |

---

## 成本监控

### 实时监控

```python
class CostMonitor:
    """成本监控"""

    def __init__(self):
        self.total_tokens = 0
        self.api_calls = 0
        self.cost_by_level = {"L1": 0, "L2": 0, "L3": 0, "L4": 0}

    def record(self, level, tokens, api_calls=1):
        self.total_tokens += tokens
        self.api_calls += api_calls
        self.cost_by_level[level] += tokens

    def report(self):
        print(f"总 Token: {self.total_tokens:,}")
        print(f"总 API 调用: {self.api_calls}")
        print(f"分级成本: {self.cost_by_level}")
        # 预估成本（基于 GLM-5.1）
        estimated_cost = self.total_tokens / 1_000_000 * 0.1  # $0.1/M
        print(f"预估成本: ${estimated_cost:.2f}")
```

### 预警机制

```python
def check_cost_budget(chapter_num, current_cost, budget):
    """检查是否超出预算"""
    progress = chapter_num / 100  # 假设100章
    expected_cost = budget * progress

    if current_cost > expected_cost * 1.2:  # 超过20%
        return {
            "warning": True,
            "message": f"成本超支：当前${current_cost:.2f}，预期${expected_cost:.2f}",
            "suggestion": "考虑降级本章到L1或合并章节"
        }
```

---

## 优化效果预估

| 优化项 | 节省比例 | 适用场景 |
|:---|:---:|:---|
| 上下文压缩 | 60-80% | 所有等级 |
| 批量生成 | 50% API | L1 |
| 规格复用 | 30% Token | L2 |
| Prompt 缓存 | 90% 冻结区 | 所有等级 |
| 并行处理 | 40% 时间 | L3/L4 |
| 廉价模型路由 | 60% 成本 | L1/P1 |
| 增量更新 | 50% 历史加载 | L4 |

**综合优化效果**：
- L1：节省约 70%
- L2：节省约 60%
- L3：节省约 50%
- L4：节省约 40%

百万字项目总成本：从 ~18M tokens 降至 ~7M tokens（节省约 61%）