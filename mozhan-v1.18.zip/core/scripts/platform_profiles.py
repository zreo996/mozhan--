"""platform_profiles.py — 9 大中文网文平台调性档案

为构思/写作/简介生成提供平台级约束。
平台调性决定:书名套路、简介节奏、章节字数、题材亲和度。
"""
from __future__ import annotations

PLATFORM_PROFILES: dict[str, dict] = {
    "fanqie": {
        "name_cn": "番茄小说",
        "logo": "🍅",
        "audience": "下沉+碎片化读者,免费+广告变现",
        "title_rule": "6-15 字;含强钩子词(逆袭/无敌/暴富/系统/狂飙/震惊);多冒号副标",
        "title_example": "《签到百年,我成了人间仙人》《下山后,七个师姐抢着嫁我》",
        "synopsis_rule": "80-200 字;首句必冲突,末句必反转,大量短句与省略号营造节奏感",
        "chapter_word": 2000,
        "genre_fit": ["fantasy", "urban", "apocalypse", "superpower", "isekai"],
        "tip": "首章必出爽点;3 章内必装一次打脸;标题党为荣,书名就是流量入口",
    },
    "shuqi": {
        "name_cn": "书旗小说",
        "logo": "📕",
        "audience": "付费阅读+IP 改编,长篇向",
        "title_rule": "8-18 字;古典/雅致,带意境;允许 4 字成语式短名",
        "title_example": "《雪中悍刀行》《剑来》《庆余年》",
        "synopsis_rule": "200-400 字;有故事感,带世界观;不要直白说教",
        "chapter_word": 3000,
        "genre_fit": ["wuxia", "fantasy", "historical", "mystery"],
        "tip": "适合厚重题材,允许慢热;首章埋设定,中段出情怀",
    },
    "qimao": {
        "name_cn": "七猫小说",
        "logo": "🐱",
        "audience": "下沉+女性+中老年,免费广告+会员",
        "title_rule": "8-16 字;带情感词(深情/离婚/夫人/前夫/团宠)",
        "title_example": "《离婚后,前夫天天跪着求复合》《团宠小奶包,大佬们排队宠》",
        "synopsis_rule": "100-250 字;情感冲突鲜明,人物关系一张图说清",
        "chapter_word": 2000,
        "genre_fit": ["romance", "urban", "mystery"],
        "tip": "情感戏重,女主人设必须鲜明;反派需脸谱化以利共情投射",
    },
    "qidian": {
        "name_cn": "起点中文网",
        "logo": "📘",
        "audience": "付费+精品化,核心网文读者",
        "title_rule": "8-20 字;有格调,允许有意象/成语/典故;不避长名",
        "title_example": "《诡秘之主》《深海余烬》《道诡异仙》",
        "synopsis_rule": "200-500 字;故事内核+核心设定+主角动机,允许文学化",
        "chapter_word": 3500,
        "genre_fit": ["fantasy", "scifi", "wuxia", "isekai", "game", "mystery"],
        "tip": "质量优先;首章 3000+ 起步,允许长设定;读者容忍慢热,忌水文",
    },
    "jinjiang": {
        "name_cn": "晋江文学城",
        "logo": "🌸",
        "audience": "女性向高粘性读者,付费+IP",
        "title_rule": "4-12 字;清新/古风/有反差;可英文/可双关",
        "title_example": "《撒野》《魔道祖师》《天官赐福》",
        "synopsis_rule": "150-300 字;重氛围与情感张力,弱剧情大纲;常以人物名/事件切入",
        "chapter_word": 3500,
        "genre_fit": ["romance", "fanfiction", "isekai", "mystery"],
        "tip": "女主向,角色塑造 > 剧情推进;CP 感是核心;忌玛丽苏强开挂",
    },
    "feilu": {
        "name_cn": "飞卢小说",
        "logo": "🚀",
        "audience": "极爽向,年轻男性,VIP 章节约",
        "title_rule": "10-22 字;极长书名,带系统/无限/签到/开局等词",
        "title_example": "《开局签到混沌体,诸天大佬都是我徒》《人在娘胎,签到一万年》",
        "synopsis_rule": "60-150 字;首段即爽点+金手指,无废话无设定",
        "chapter_word": 1500,
        "genre_fit": ["fantasy", "isekai", "game", "superpower"],
        "tip": "爽点密度极高(每章必有);无脑碾压为荣;深度设定反而不利",
    },
    "ciwei": {
        "name_cn": "刺猬猫",
        "logo": "🦔",
        "audience": "二次元/同人/轻小说读者",
        "title_rule": "6-16 字;中二/日轻/吐槽/标签化;允许萌点词",
        "title_example": "《我的妹妹哪有这么可爱!》《转生史莱姆的我》",
        "synopsis_rule": "80-200 字;轻小说风格,日常向吐槽+转折;大量独白/内心戏",
        "chapter_word": 3000,
        "genre_fit": ["fanfiction", "isekai", "game", "superpower", "fantasy"],
        "tip": "角色萌点 > 剧情;允许无厘头/吐槽/梗;忌严肃文风",
    },
    "zhihu": {
        "name_cn": "知乎盐选",
        "logo": "💡",
        "audience": "付费短篇,1-3 万字完结,都市情感为主",
        "title_rule": "8-18 字;反转型悬念,问句/反差/钩子",
        "title_example": "《老公每月给我 20 万,可他不回家》《我死后,妈妈终于笑了》",
        "synopsis_rule": "80-150 字;核心矛盾一句话说清,必须有情感冲击",
        "chapter_word": 1200,
        "genre_fit": ["urban", "romance", "mystery", "superpower"],
        "tip": "短篇 1-3 万字;3 章内必有大反转;情感共鸣 > 世界观;必须有现实落点",
    },
    "wechat": {
        "name_cn": "公众号",
        "logo": "📱",
        "audience": "微信生态,情感/职场/历史/短爽文",
        "title_rule": "10-20 字;强情绪/强反差/强代入",
        "title_example": "《人到中年,我才看懂那杯敬自己的酒》《她死在婚礼前一天》",
        "synopsis_rule": "60-120 字;痛点+共鸣+反转,常以'我'或'她/他'切入",
        "chapter_word": 1500,
        "genre_fit": ["urban", "romance", "historical", "mystery"],
        "tip": "首段必抓人(前 3 句决定完读率);情感共鸣是命脉;忌长设定",
    },
}


def get_platform_profile(platform: str) -> dict | None:
    return PLATFORM_PROFILES.get(platform)


def list_platforms() -> list[dict]:
    """返回平台列表(给 UI 用)"""
    return [
        {"id": pid, **p}
        for pid, p in PLATFORM_PROFILES.items()
    ]


def render_platform_rules(platform: str) -> str:
    """渲染某平台的写作规则(注入 prompt)"""
    p = PLATFORM_PROFILES.get(platform)
    if not p:
        return ""
    fit = "/".join(p.get("genre_fit", []))
    return f"""# 目标发布平台: {p['name_cn']} {p['logo']}
- 读者画像: {p['audience']}
- 书名规则: {p['title_rule']}(如:{p['title_example']})
- 简介规则: {p['synopsis_rule']}
- 推荐章节字数: {p['chapter_word']} 字
- 题材亲和度排序: {fit}
- 平台调性提醒: {p['tip']}

# 平台适配要求(必须遵守)
1. **书名**必须严格遵循「{p['name_cn']}」的书名套路,允许适当夸张/钩子词;
2. **简介**长度、节奏、句式必须符合「{p['title_rule']}」,不要用其他平台的文风;
3. **章节字数**按 {p['chapter_word']} 字左右;
4. **大纲与前三章**以该平台读者的口味为优先,而不是作者本人的偏好;"""


def platform_chapter_word(platform: str) -> int:
    p = PLATFORM_PROFILES.get(platform)
    return p["chapter_word"] if p else 3000
