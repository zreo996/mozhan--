#!/usr/bin/env python3
"""
climax_tracker.py — 爽点密度追踪器

网文经验:每 100 章应有 18-25 次"打脸/翻盘/抒泄"爽点,过密读者疲劳,过疏读者弃书。
本脚本扫描多章节文本,识别爽点关键词,计算密度,提示节奏问题。

爽点类型分类:
  - 打脸(slap):反派/反对者被当面打击
  - 翻盘(reverse):局面突变,主角胜
  - 觉醒(awaken):觉醒/突破/觉悟
  - 实力(power):公开亮相实力/身份
  - 抒泄(catharsis):憋屈后反击
  - 拯救(rescue):救人/救场/英雄归来

使用方式:
  python climax_tracker.py --data-dir ./data --chapters ./chapters --window 100
"""
from __future__ import annotations

import json
import re
import sys
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path


# ── 爽点词典 ────────────────────────────────────────────
CLIMAX_PATTERNS = {
    "slap": [
        r"打脸", r"打了.{0,4}耳光", r"脸色.{0,4}惨白",
        r"瞠目结舌", r"无地自容", r"哑口无言", r"目瞪口呆",
        r"哑然失色", r"颜面扫地", r"自取其辱",
    ],
    "reverse": [
        r"反败为胜", r"局势逆转", r"风云突变", r"翻盘",
        r"形势.{0,6}逆转", r"惊天逆转", r"绝地反击",
    ],
    "awaken": [
        r"觉醒", r"突破.{0,4}境界", r"晋升", r"参悟",
        r"开窍", r"灵光乍现", r"顿悟",
    ],
    "power": [
        r"露出.{0,4}真容", r"亮明.{0,4}身份", r"暴露.{0,4}实力",
        r"一招.{0,4}击败", r"瞬杀", r"碾压",
    ],
    "catharsis": [
        r"扬眉吐气", r"出了一口恶气", r"一吐为快", r"积压.{0,6}爆发",
        r"压抑.{0,6}释放",
    ],
    "rescue": [
        r"千钧一发", r"救.{0,4}于水火", r"危急关头", r"绝处.{0,4}救",
        r"英雄.{0,4}归来", r"力挽狂澜",
    ],
}


@dataclass
class ChapterClimax:
    chapter: int
    counts: dict[str, int] = field(default_factory=dict)
    total: int = 0
    snippets: dict[str, list[str]] = field(default_factory=dict)


@dataclass
class DensityReport:
    total_chapters: int
    total_climaxes: int
    by_type: dict[str, int]
    per_100ch: float
    target_min: int = 18
    target_max: int = 25
    status: str = ""             # ok / sparse / overload
    deficit: int = 0             # 需补/需减
    hot_chapters: list[int] = field(default_factory=list)   # 爽点 ≥3
    dry_streak: list[tuple[int, int]] = field(default_factory=list)  # 连续 ≥5 章 0 爽点
    by_chapter: list[ChapterClimax] = field(default_factory=list)

    def to_dict(self):
        return {
            "total_chapters": self.total_chapters,
            "total_climaxes": self.total_climaxes,
            "by_type": self.by_type,
            "per_100ch": round(self.per_100ch, 2),
            "target_min": self.target_min,
            "target_max": self.target_max,
            "status": self.status,
            "deficit": self.deficit,
            "hot_chapters": self.hot_chapters,
            "dry_streak": self.dry_streak,
            "by_chapter": [
                {"chapter": c.chapter, "total": c.total, "counts": c.counts}
                for c in self.by_chapter
            ],
        }


class ClimaxTracker:
    """扫描章节目录,生成密度报告"""

    def __init__(self, chapters_dir: str | Path,
                 target_min: int = 18, target_max: int = 25):
        self.chapters_dir = Path(chapters_dir)
        self.target_min = target_min
        self.target_max = target_max
        self._compiled = {
            cat: [re.compile(p) for p in pats]
            for cat, pats in CLIMAX_PATTERNS.items()
        }

    def scan_chapter(self, text: str, chapter: int) -> ChapterClimax:
        counts: Counter[str] = Counter()
        snippets: dict[str, list[str]] = {}
        for cat, regexes in self._compiled.items():
            for regex in regexes:
                for m in regex.finditer(text):
                    counts[cat] += 1
                    if cat not in snippets:
                        snippets[cat] = []
                    if len(snippets[cat]) < 3:
                        start = max(0, m.start() - 8)
                        end = min(len(text), m.end() + 8)
                        snippets[cat].append(text[start:end].replace("\n", " "))
        return ChapterClimax(
            chapter=chapter,
            counts=dict(counts),
            total=sum(counts.values()),
            snippets=snippets,
        )

    def _iter_chapter_files(self):
        """约定文件名: chapter_001.txt / 第001章.txt / ch001.md 等"""
        patterns = [r"chapter_(\d+)", r"第(\d+)章", r"ch(\d+)"]
        for p in sorted(self.chapters_dir.iterdir()):
            if not p.is_file():
                continue
            for pat in patterns:
                m = re.search(pat, p.stem)
                if m:
                    yield int(m.group(1)), p
                    break

    def report(self) -> DensityReport:
        by_chapter: list[ChapterClimax] = []
        for ch_num, path in self._iter_chapter_files():
            try:
                text = path.read_text(encoding="utf-8")
            except Exception:
                continue
            by_chapter.append(self.scan_chapter(text, ch_num))
        by_chapter.sort(key=lambda c: c.chapter)

        total_climaxes = sum(c.total for c in by_chapter)
        total_chapters = len(by_chapter)
        type_counter: Counter[str] = Counter()
        for c in by_chapter:
            type_counter.update(c.counts)

        per_100 = (total_climaxes / total_chapters * 100) if total_chapters else 0.0

        if per_100 < self.target_min:
            status = "sparse"
            deficit = int(self.target_min - per_100)
        elif per_100 > self.target_max:
            status = "overload"
            deficit = int(self.target_max - per_100)  # 负数
        else:
            status = "ok"
            deficit = 0

        hot = [c.chapter for c in by_chapter if c.total >= 3]

        dry: list[tuple[int, int]] = []
        streak_start = None
        for c in by_chapter:
            if c.total == 0:
                if streak_start is None:
                    streak_start = c.chapter
                streak_end = c.chapter
            else:
                if streak_start is not None and (streak_end - streak_start + 1) >= 5:
                    dry.append((streak_start, streak_end))
                streak_start = None
        if streak_start is not None and (streak_end - streak_start + 1) >= 5:
            dry.append((streak_start, streak_end))

        return DensityReport(
            total_chapters=total_chapters,
            total_climaxes=total_climaxes,
            by_type=dict(type_counter),
            per_100ch=per_100,
            target_min=self.target_min,
            target_max=self.target_max,
            status=status,
            deficit=deficit,
            hot_chapters=hot,
            dry_streak=dry,
            by_chapter=by_chapter,
        )


def main():
    if len(sys.argv) < 2 or "--help" in sys.argv:
        print("用法: python climax_tracker.py --chapters DIR [--data-dir DIR] [--target-min N] [--target-max N] [--json]")
        sys.exit(0)
    chapters_dir = None
    data_dir = "./data"
    tmin, tmax = 18, 25
    as_json = "--json" in sys.argv
    for i, arg in enumerate(sys.argv):
        if arg == "--chapters":
            chapters_dir = sys.argv[i + 1]
        elif arg == "--data-dir":
            data_dir = sys.argv[i + 1]
        elif arg == "--target-min":
            tmin = int(sys.argv[i + 1])
        elif arg == "--target-max":
            tmax = int(sys.argv[i + 1])
    if not chapters_dir:
        print("必须指定 --chapters DIR"); sys.exit(2)

    tracker = ClimaxTracker(chapters_dir, target_min=tmin, target_max=tmax)
    report = tracker.report()

    # 持久化到 data/climax_density.json
    Path(data_dir).mkdir(parents=True, exist_ok=True)
    out = Path(data_dir) / "climax_density.json"
    out.write_text(json.dumps(report.to_dict(), ensure_ascii=False, indent=2),
                   encoding="utf-8")

    if as_json:
        print(json.dumps(report.to_dict(), ensure_ascii=False, indent=2))
    else:
        print(f"扫描 {report.total_chapters} 章,共 {report.total_climaxes} 个爽点")
        print(f"每100章密度: {report.per_100ch:.1f} (目标 {tmin}-{tmax})")
        print(f"状态: {report.status}", end="")
        if report.status != "ok":
            print(f" (缺口 {report.deficit})")
        else:
            print()
        if report.by_type:
            print("类型分布:")
            for k, v in sorted(report.by_type.items(), key=lambda x: -x[1]):
                print(f"  {k}: {v}")
        if report.hot_chapters:
            print(f"高爽点章节(≥3): {report.hot_chapters[:10]}{'...' if len(report.hot_chapters) > 10 else ''}")
        if report.dry_streak:
            print(f"连续干涸段: {report.dry_streak[:5]}")
        print(f"\n详细报告: {out}")


if __name__ == "__main__":
    main()
