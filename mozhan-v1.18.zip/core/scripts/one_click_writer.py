#!/usr/bin/env python3
"""
一键写作脚本 (One-Click Writing)
整合所有工具，一键生成章节
"""

import json
import sys
from pathlib import Path
from datetime import datetime

# 导入同目录下的脚本
sys.path.insert(0, str(Path(__file__).parent))
from self_check import SelfChecker
from quality_score import QualityScorer

class OneClickWriter:
    def __init__(self, project_dir, model="claude-sonnet-4-6"):
        self.project_dir = Path(project_dir)
        self.data_dir = self.project_dir / "data"
        self.chapters_dir = self.project_dir / "chapters"
        self.model = model

        # 确保目录存在
        self.chapters_dir.mkdir(exist_ok=True)

    def init_project(self, genre, title, main_character, skill_dir=None):
        """初始化项目"""
        config = {
            "genre": genre,
            "title": title,
            "main_character": main_character,
            "created_date": datetime.now().isoformat(),
            "status": "planning"
        }

        with open(self.project_dir / "config.json", 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)

        # 复制模板四表
        import shutil
        templates_dir = Path(__file__).parent.parent / "templates"
        self.data_dir.mkdir(parents=True, exist_ok=True)
        for template in templates_dir.glob("*.json"):
            shutil.copy(template, self.data_dir / template.name)

        # 写入文风印记(供后续 LLMClient 走 Prompt Caching 命中)
        try:
            from genre_style import render_style_fingerprint
            root = Path(skill_dir) if skill_dir else Path(__file__).parent.parent.parent
            fp_text = render_style_fingerprint(genre, root)
            with open(self.data_dir / "style_fingerprint.json", 'w', encoding='utf-8') as f:
                json.dump({
                    "genre": genre,
                    "text": fp_text,
                    "generated_at": datetime.now().isoformat(),
                }, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"警告:文风印记生成失败 {e}")

        return config

    def plan_chapter(self, chapter_num, level, outline):
        """规划章节"""
        chapter_data = {
            "chapter_num": chapter_num,
            "level": level,
            "outline": outline,
            "status": "planned",
            "planned_date": datetime.now().isoformat()
        }

        plan_file = self.project_dir / "plans" / f"chapter_{chapter_num:03d}.json"
        plan_file.parent.mkdir(exist_ok=True)
        with open(plan_file, 'w', encoding='utf-8') as f:
            json.dump(chapter_data, f, ensure_ascii=False, indent=2)

        return chapter_data

    def write_chapter(self, chapter_num, content):
        """写作章节"""
        # 保存章节
        chapter_file = self.chapters_dir / f"chapter_{chapter_num:03d}.txt"
        with open(chapter_file, 'w', encoding='utf-8') as f:
            f.write(content)

        # 后处理
        self.post_process(chapter_num, chapter_file)

        # 质量评分
        score_result = self.assess_quality(chapter_num, content)

        return {
            "chapter_num": chapter_num,
            "chapter_file": str(chapter_file),
            "quality_score": score_result
        }

    def post_process(self, chapter_num, chapter_file):
        """写后处理"""
        try:
            from post_process import PostProcessor
            processor = PostProcessor(str(self.data_dir), chapter_num)
            processor.process(str(chapter_file))
        except Exception as e:
            print(f"警告：后处理失败 {e}")

    def assess_quality(self, chapter_num, content):
        """质量评估"""
        # self_check
        checker = SelfChecker(str(self.data_dir), chapter_num)
        check_result = checker.run_all_checks(content)

        # quality_score
        scorer = QualityScorer(chapter_num)
        score_result = scorer.assess(content, str(self.data_dir))

        return score_result

    def batch_write(self, start_chapter, end_chapter, outlines):
        """批量写作"""
        results = []
        for i, chapter_num in enumerate(range(start_chapter, end_chapter + 1)):
            chapter_data = outlines[i] if i < len(outlines) else {}
            content = chapter_data.get("content", "")

            result = self.write_chapter(chapter_num, content)
            results.append(result)

            print(f"完成第 {chapter_num} 章，质量评分：{result['quality_score']['final_score']}")

        return results

    def generate_report(self):
        """生成项目报告"""
        chapters = list(self.chapters_dir.glob("chapter_*.txt"))
        plans = list((self.project_dir / "plans").glob("chapter_*.json"))

        report = {
            "project": self.project_dir.name,
            "total_chapters": len(chapters),
            "total_plans": len(plans),
            "chapters_completed": len(chapters),
            "generated_date": datetime.now().isoformat()
        }

        report_file = self.project_dir / "report.json"
        with open(report_file, 'w', encoding='utf-8') as f:
            json.dump(report, f, ensure_ascii=False, indent=2)

        return report

def main():
    if len(sys.argv) < 2:
        print("用法：")
        print("  python one_click_writer.py init <项目名> <题材> <主角名>")
        print("  python one_click_writer.py plan <章节号> <等级> <大纲文件>")
        print("  python one_click_writer.py write <章节号> <内容文件>")
        print("  python one_click_writer.py batch <起始章> <结束章> <大纲文件>")
        print("  python one_click_writer.py report")
        sys.exit(1)

    command = sys.argv[1]

    if command == "init":
        project_name = sys.argv[2]
        genre = sys.argv[3]
        main_character = sys.argv[4]

        writer = OneClickWriter(f"./projects/{project_name}")
        config = writer.init_project(genre, project_name, main_character)
        print(f"项目已初始化：{config}")

    elif command == "plan":
        chapter_num = int(sys.argv[2])
        level = sys.argv[3]
        outline_file = sys.argv[4]

        with open(outline_file, 'r', encoding='utf-8') as f:
            outline = f.read()

        writer = OneClickWriter(".")  # 当前目录
        result = writer.plan_chapter(chapter_num, level, outline)
        print(f"章节已规划：{result}")

    elif command == "write":
        chapter_num = int(sys.argv[2])
        content_file = sys.argv[3]

        with open(content_file, 'r', encoding='utf-8') as f:
            content = f.read()

        writer = OneClickWriter(".")
        result = writer.write_chapter(chapter_num, content)
        print(f"章节已保存，质量评分：{result['quality_score']['final_score']}")

    elif command == "batch":
        start = int(sys.argv[2])
        end = int(sys.argv[3])
        outlines_file = sys.argv[4]

        with open(outlines_file, 'r', encoding='utf-8') as f:
            outlines = json.load(f)

        writer = OneClickWriter(".")
        results = writer.batch_write(start, end, outlines)
        print(f"批量完成 {len(results)} 章")

    elif command == "report":
        writer = OneClickWriter(".")
        report = writer.generate_report()
        print(json.dumps(report, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()