#!/usr/bin/env python3
"""
质量评分脚本 (Quality Score)
自动计算章节质量分数

评分规则详见: core/references/quality_scoring.md
"""

import json
import re
import sys
from pathlib import Path
from datetime import datetime


class QualityScorer:
    def __init__(self, chapter_num):
        self.chapter_num = chapter_num
        self.issues = {"p0": [], "p1": [], "p2": []}
        self.bonuses = []

    def assess(self, chapter_text, data_dir=None):
        """评估章节质量"""
        score = 100

        # P0 检查
        p0_result = self.check_p0(chapter_text, data_dir)
        if p0_result["failures"] > 0:
            return {
                "chapter": self.chapter_num,
                "timestamp": datetime.now().isoformat(),
                "final_score": 0,
                "grade": "不及格",
                "issues": self.issues,
                "recommendation": "P0级致命错误,必须修复后重新评分"
            }

        # P1 检查
        p1_result = self.check_p1(chapter_text)
        score -= p1_result["penalty"]
        self.issues["p1"] = p1_result["issues"]

        # P2 检查
        p2_result = self.check_p2(chapter_text)
        score -= p2_result["penalty"]
        self.issues["p2"] = p2_result["issues"]

        # 加分项
        bonus_result = self.check_bonuses(chapter_text)
        score += bonus_result["total"]
        self.bonuses = bonus_result["items"]

        final_score = max(0, min(100, score))
        grade = self.get_grade(final_score)

        return {
            "chapter": self.chapter_num,
            "timestamp": datetime.now().isoformat(),
            "final_score": final_score,
            "grade": grade,
            "issues": self.issues,
            "bonuses": self.bonuses,
            "breakdown": {
                "base_score": 100,
                "p1_penalty": -p1_result["penalty"],
                "p2_penalty": -p2_result["penalty"],
                "bonus": bonus_result["total"]
            }
        }

    def check_p0(self, text, data_dir):
        """P0 检查 - 与四表交叉校验"""
        failures = []

        if data_dir:
            data_path = Path(data_dir)
            # 时间线检查
            tl_file = data_path / "timeline.json"
            if tl_file.exists():
                tl = json.loads(tl_file.read_text(encoding='utf-8'))
                if self._check_timeline_conflict(text, tl):
                    failures.append("时间线矛盾")

            # 伏笔丢失检查
            hooks_file = data_path / "hooks.json"
            if hooks_file.exists():
                hooks = json.loads(hooks_file.read_text(encoding='utf-8'))
                lost = self._check_hook_loss(hooks)
                if lost:
                    failures.append(f"伏笔丢失: {','.join(lost)}")

            # 物品消失检查
            inv_file = data_path / "inventory.json"
            if inv_file.exists():
                inv = json.loads(inv_file.read_text(encoding='utf-8'))
                missing = self._check_inventory_drift(text, inv)
                if missing:
                    failures.append(f"物品状态异常: {','.join(missing)}")

        self.issues["p0"] = failures
        return {"failures": len(failures), "issues": failures}

    def check_p1(self, text):
        """P1 检查"""
        issues = []
        penalty = 0

        # 视角混乱
        view_pattern = r'视角[:：]\s*([^\n,，。]+)'
        views = re.findall(view_pattern, text)
        if len(set(views)) > 3:
            issues.append({"type": "视角混乱", "detail": f"单章有{len(set(views))}个视角", "penalty": -10})
            penalty += 10

        # 节奏崩塌：超5000字无段落转折
        if len(text) > 5000:
            transitions = sum(text.count(w) for w in ["然而", "突然", "可是", "转眼"])
            if transitions < 2:
                issues.append({"type": "节奏崩塌", "detail": "5000字内转折不足", "penalty": -10})
                penalty += 10

        # 句式单一
        if self._check_sentence_variety(text):
            issues.append({"type": "句式单一", "detail": "连续5句主语相同", "penalty": -10})
            penalty += 10

        return {"penalty": penalty, "issues": issues}

    def check_p2(self, text):
        """P2 检查"""
        issues = []
        penalty = 0

        # 情感过载
        exc = text.count('!') + text.count('！')
        if exc > 3:
            issues.append({"type": "情感过载", "detail": f"单章{exc}个感叹号", "penalty": -5})
            penalty += 5

        # 描写冗余
        long_desc = re.findall(r'[^。!?！？]{500,}', text)
        if long_desc:
            issues.append({"type": "描写冗余", "detail": f"{len(long_desc)}段超500字未断句", "penalty": -5})
            penalty += 5

        # 重复描写
        sentences = re.split(r'[。!?！？]', text)
        sent_counter = {}
        for s in sentences:
            s = s.strip()
            if len(s) > 10:
                sent_counter[s] = sent_counter.get(s, 0) + 1
        dups = [s for s, c in sent_counter.items() if c >= 3]
        if dups:
            issues.append({"type": "重复描写", "detail": f"{len(dups)}句出现3次以上", "penalty": -5})
            penalty += 5

        return {"penalty": penalty, "issues": issues}

    def check_bonuses(self, text):
        """加分项检查"""
        items = []
        total = 0

        if self._has_hero_journey(text):
            items.append({"type": "英雄之旅结构", "score": 5})
            total += 5

        if self._has_clear_hook(text):
            items.append({"type": "清晰钩子", "score": 5})
            total += 5

        if self._has_buried_hook(text):
            items.append({"type": "伏笔埋设", "score": 3})
            total += 3

        if self._has_character_growth(text):
            items.append({"type": "角色成长", "score": 2})
            total += 2

        return {"total": total, "items": items}

    def _check_timeline_conflict(self, text, tl):
        """检测当前章节是否提到逆序时间"""
        cur_day = tl.get("global_day", 1)
        # 简单实现:检查文中"第N天"是否回退
        matches = re.findall(r'第(\d+)天', text)
        for m in matches:
            if int(m) < cur_day - 1:
                return True
        return False

    def _check_hook_loss(self, hooks):
        """检测active hook是否超3章未推进"""
        lost = []
        for h in hooks.get("active", []):
            chapters_passed = self.chapter_num - h.get("introduced_chapter", self.chapter_num)
            if chapters_passed > 3 and not h.get("recovered"):
                lost.append(h.get("name", "unknown"))
        return lost

    def _check_inventory_drift(self, text, inv):
        """物品消失检测"""
        missing = []
        for item in inv.get("items", []):
            if item.get("status") == "consumed" and not item.get("disposed_chapter"):
                missing.append(item.get("name", "unknown"))
        return missing

    def _check_sentence_variety(self, text):
        sentences = [s for s in re.split(r'[。!?！？]', text) if s.strip()]
        if len(sentences) < 5:
            return False
        for i in range(len(sentences) - 4):
            window = sentences[i:i + 5]
            subjects = [s.strip()[:2] for s in window]
            if len(set(subjects)) == 1:
                return True
        return False

    def _has_hero_journey(self, text):
        keywords = ["突然", "然而", "于是", "最终", "终于"]
        return sum(1 for k in keywords if k in text) >= 3

    def _has_clear_hook(self, text):
        tail = text[-200:]
        signals = ["...", "……", "未完", "却不知", "突然", "竟是", "原来", "?", "？"]
        return any(s in tail for s in signals)

    def _has_buried_hook(self, text):
        signals = ["神秘", "隐隐", "似乎", "总觉得", "一闪而过", "似有所感"]
        return sum(1 for s in signals if s in text) >= 2

    def _has_character_growth(self, text):
        signals = ["突破", "领悟", "明白了", "终于懂", "脱胎换骨", "境界", "升级"]
        return any(s in text for s in signals)

    def get_grade(self, score):
        if score == 0:
            return "不及格"
        elif score < 60:
            return "较差"
        elif score < 80:
            return "合格"
        elif score < 90:
            return "良好"
        else:
            return "优秀"


def main():
    if len(sys.argv) < 2:
        print("用法: python quality_score.py <chapter_num> [--text <file>] [--data-dir <dir>]")
        sys.exit(1)

    chapter_num = int(sys.argv[1])

    text = ""
    if "--text" in sys.argv:
        idx = sys.argv.index("--text")
        with open(sys.argv[idx + 1], 'r', encoding='utf-8') as f:
            text = f.read()

    data_dir = None
    if "--data-dir" in sys.argv:
        idx = sys.argv.index("--data-dir")
        data_dir = sys.argv[idx + 1]

    scorer = QualityScorer(chapter_num)
    result = scorer.assess(text, data_dir)

    print(json.dumps(result, ensure_ascii=False, indent=2))
    sys.exit(0 if result["final_score"] >= 60 else 1)


if __name__ == "__main__":
    main()
