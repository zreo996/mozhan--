"""
genre_style.py — 文风印记自动加载器

从 genres/{genre}/masterpiece_analysis.md 抽取:
  - 来源书单
  - 流派/子风格关键词
  - 关键写作技巧(每本书的"关键技巧"列表)
  - 主角差异化人设(性格/金手指/目标)
  - 节奏模式与爽点类型

压缩为 ~1000 token 的结构化文风印记,注入到 LLMClient.FrozenContext,
走 Prompt Caching 命中。
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


# ── 启发式词典 ───────────────────────────────────────────
# 维度 → 关键正则 (匹配二级或三级标题后的小节名)
STYLE_DIMENSIONS = [
    "语言特点", "语言风格", "写作风格", "文字描述", "文笔特点",
    "节奏模式", "节奏", "爽点类型", "爽点", "对话特色", "对话",
    "装备描写", "战斗描写", "场景描写", "系统描写", "描写要点",
]
PROTAGONIST_FIELDS = ["性格", "金手指", "目标", "核心", "人设"]
BOOK_HEADER = re.compile(r"^##\s*《([^》]+)》\s*[—\-:：]?\s*(.*?)$")
BOOK_FOOTER = re.compile(r"^##\s*《")
SECTION_HEADER = re.compile(r"^##+\s*(.+?)$")
LIST_ITEM = re.compile(r"^[\s]*[-*•]\s*(.+)$")
BOLD_INLINE = re.compile(r"\*\*(.+?)\*\*")
SOURCE_LINE = re.compile(r"分析样本[：:]?\s*(.+?)$", re.MULTILINE)
QUOTED_BOOK = re.compile(r"《([^》]+)》")


@dataclass
class StyleFingerprint:
    genre: str
    source_books: list[str] = field(default_factory=list)
    core_styles: list[str] = field(default_factory=list)      # 流派关键词
    key_techniques: list[str] = field(default_factory=list)
    protagonist_arcs: list[str] = field(default_factory=list)  # 主角差异化
    rhythm_pacing: list[str] = field(default_factory=list)
    estimated_tokens: int = 0

    def render(self) -> str:
        """生成压缩文风印记字符串(~1000 token)"""
        sections: list[str] = []
        sections.append(f"== 文风印记: {self.genre} ==")
        if self.source_books:
            sections.append(
                f"参考 {len(self.source_books)} 本精品: "
                + "、".join(f"《{b}》" for b in self.source_books))

        if self.core_styles:
            sections.append("\n== 核心流派与文字气质 ==")
            for s in self.core_styles:
                sections.append(f"- {s}")

        if self.key_techniques:
            sections.append("\n== 关键写作技巧 ==")
            for t in self.key_techniques:
                sections.append(f"- {t}")

        if self.protagonist_arcs:
            sections.append("\n== 主角差异化人设 ==")
            for p in self.protagonist_arcs:
                sections.append(f"- {p}")

        if self.rhythm_pacing:
            sections.append("\n== 节奏与爽点 ==")
            for r in self.rhythm_pacing:
                sections.append(f"- {r}")

        return "\n".join(sections)


class GenreStyleLoader:
    """从 masterpiece_analysis.md 抽取文风指纹"""

    def __init__(self, skill_dir: str | Path):
        self.skill_dir = Path(skill_dir)
        self._cache: dict[str, StyleFingerprint] = {}

    def load(self, genre: str, force_reload: bool = False) -> StyleFingerprint:
        genre = genre.lower().strip()
        if not force_reload and genre in self._cache:
            return self._cache[genre]
        fp = self._parse(genre)
        self._cache[genre] = fp
        return fp

    def render(self, genre: str) -> str:
        return self.load(genre).render()

    # ── 解析 ──────────────────────────────────────────────
    def _parse(self, genre: str) -> StyleFingerprint:
        path = self.skill_dir / "genres" / genre / "masterpiece_analysis.md"
        if not path.exists():
            return StyleFingerprint(genre=genre)
        text = path.read_text(encoding="utf-8")

        fp = StyleFingerprint(genre=genre)
        fp.source_books = self._extract_books_from_source(text)
        fp.core_styles = self._extract_styles(text)
        fp.key_techniques = self._extract_key_techniques(text)
        fp.protagonist_arcs = self._extract_protagonists(text)
        fp.rhythm_pacing = self._extract_rhythm(text)

        rendered = fp.render()
        # 中文粗估: 1.5 字符/token
        fp.estimated_tokens = int(len(rendered) / 1.5)
        return fp

    def _extract_books_from_source(self, text: str) -> list[str]:
        m = SOURCE_LINE.search(text)
        if not m:
            return []
        line = m.group(1)
        books = QUOTED_BOOK.findall(line)
        # 去重保序
        seen, out = set(), []
        for b in books:
            if b not in seen:
                seen.add(b); out.append(b)
        return out

    def _extract_styles(self, text: str) -> list[str]:
        """核心流派 — 抓每本书简介或类型子风格中的 1-2 个关键词"""
        out: list[str] = []
        for line in text.splitlines():
            line = line.strip()
            m = re.match(r"^##\s*《(.+?)》\s*[—\-:：]\s*(.+)$", line)
            if m:
                book = m.group(1)
                tail = m.group(2).strip()
                style = re.sub(r"[—\-:：]", "", tail).strip()
                if 2 <= len(style) <= 12:
                    out.append(f"{book} 流派: {style}")
                    continue
            # 兼容 ### 类型1:xxx / ### 都市类型2:重生修仙流 等子流派
            m2 = re.match(r"^###\s*(?:类型|流派)?\s*\d*[：:]\s*(.+)$", line)
            if not m2:
                m2 = re.match(r"^###\s*(.{2,12}流)\s*$", line)
            if m2:
                style = m2.group(1).strip()
                if 2 <= len(style) <= 16:
                    out.append(f"流派: {style}")
        # 去重
        seen, dedup = set(), []
        for s in out:
            if s not in seen:
                seen.add(s); dedup.append(s)
        return dedup[:8]

    def _extract_key_techniques(self, text: str) -> list[str]:
        """从每本书下的"关键技巧/独特手法/写法要点"列表抽取"""
        out: list[str] = []
        current_book = ""
        in_tech_section = False

        TECH_SECTION_KEYS = (
            "关键技巧", "独特手法", "写法要点", "写作要点", "具体写法",
            "关键点", "独到之处", "用词", "句式", "经典", "模板",
            "语录", "对话", "性格", "打脸", "爽点", "节奏",
            "钩子", "必备", "元素", "燃点", "高潮", "制造",
            "公式", "类型", "流", "特点",
        )

        for line in text.splitlines():
            stripped = line.strip()
            # 顶到 ## 《书名》  → 新书
            m = BOOK_HEADER.match(stripped)
            if m:
                current_book = m.group(1)
                in_tech_section = False
                continue
            # 出现新的 ## 标题 → 退出当前书
            if re.match(r"^##\s", stripped) and not m:
                in_tech_section = False
                continue
            # ### 关键技巧 / ### 独特手法 等
            if stripped.startswith("###") and any(k in stripped for k in TECH_SECTION_KEYS):
                in_tech_section = True
                continue
            # 退出当前技巧区(遇到另一个 ### 子标题,且不含技术关键词)
            if in_tech_section and stripped.startswith("###"):
                if not any(k in stripped for k in TECH_SECTION_KEYS):
                    in_tech_section = False
                continue

            if in_tech_section:
                m_li = LIST_ITEM.match(stripped)
                if m_li:
                    item = m_li.group(1)
                    item = BOLD_INLINE.sub(r"\1", item).strip()
                    if 4 <= len(item) <= 80:
                        prefix = f"《{current_book}》 " if current_book else ""
                        out.append(f"{prefix}{item}")
        # 去重保序,上限 12 条
        seen, dedup = set(), []
        for t in out:
            if t not in seen:
                seen.add(t); dedup.append(t)
        return dedup[:12]

    def _extract_protagonists(self, text: str) -> list[str]:
        """从 '人物形象' 段落抓主角 性格/金手指/目标"""
        out: list[str] = []
        # 用 splitlines + 索引找 "人物形象" 那一行,记录标题级别
        lines = text.splitlines()
        start_i = None
        section_level = None
        for i, line in enumerate(lines):
            if "人物形象" in line and re.match(r"^#{1,4}\s", line):
                m_lvl = re.match(r"^(#+) ", line)
                section_level = len(m_lvl.group(1))
                start_i = i + 1
                break
        if start_i is None:
            return out

        # 退出条件:遇到同级别或更高级的标题
        end_i = len(lines)
        for j in range(start_i, len(lines)):
            m_next = re.match(r"^(#+)\s", lines[j])
            if m_next and len(m_next.group(1)) <= section_level:
                end_i = j
                break

        rest = lines[start_i:end_i]

        # 行内格式: "## 人设类型（《书名》主角）"  + "- 性格: ..."
        current_label = None
        for s in rest:
            s = s.strip()
            if not s:
                continue
            m_lab = re.match(r"^#+\s*(.+)$", s)
            if m_lab:
                current_label = m_lab.group(1).strip()
                continue
            m_li = LIST_ITEM.match(s)
            if m_li and current_label:
                item = BOLD_INLINE.sub(r"\1", m_li.group(1)).strip()
                if 4 <= len(item) <= 80:
                    out.append(f"{current_label}: {item}")
        return out[:8]

    def _extract_rhythm(self, text: str) -> list[str]:
        """从 '写作风格/节奏模式/爽点类型' 段落抓要点"""
        out: list[str] = []
        for line in text.splitlines():
            stripped = line.strip()
            if not stripped.startswith(("-", "*", "•")):
                continue
            item = LIST_ITEM.match(stripped)
            if not item:
                continue
            content = BOLD_INLINE.sub(r"\1", item.group(1)).strip()
            # 命中节奏/爽点/节奏相关关键词
            if any(k in content for k in
                   ("节奏", "高潮", "每章", "每 ", "爽点", "类型", "反杀", "打脸", "模式")):
                if 4 <= len(content) <= 60:
                    out.append(content)
        # 去重
        seen, dedup = set(), []
        for x in out:
            if x not in seen:
                seen.add(x); dedup.append(x)
        return dedup[:8]


# ── 便捷函数 ──────────────────────────────────────────────
def load_style_fingerprint(genre: str, skill_dir: str | Path) -> StyleFingerprint:
    """快捷入口 — 单题材指纹"""
    return GenreStyleLoader(skill_dir).load(genre)


def render_style_fingerprint(genre: str, skill_dir: str | Path) -> str:
    """快捷入口 — 直接拿到压缩字符串"""
    return load_style_fingerprint(genre, skill_dir).render()


def list_supported_genres(skill_dir: str | Path) -> list[str]:
    """列出所有有 masterpiece_analysis.md 的题材"""
    genres_dir = Path(skill_dir) / "genres"
    if not genres_dir.exists():
        return []
    return sorted(
        p.parent.name
        for p in genres_dir.glob("*/masterpiece_analysis.md")
    )


# ── 题材种子点子库 ──────────────────────────────────────
# 每个题材预置 3-4 个高潜力点子,用于"构思向导"第 2 步的 chip 快速填写。
# 写在这里是 ① 离线可用 ② 不依赖 LLM ③ 与该题材的世界规则天然匹配。
GENRE_SEEDS: dict[str, list[dict]] = {
    "fantasy": [
        {"tag": "废柴逆袭", "idea": "末等血脉的少年在家族祭典上意外觉醒远古神格,却被嫡系诬陷偷窃,出走边陲小镇靠炼符谋生。"},
        {"tag": "宗门崛起", "idea": "破落小宗被三大宗门挤压到只剩三十人,主角以杂役身份入山,凭一卷残破功法逆天改命。"},
        {"tag": "血脉觉醒", "idea": "主角身体里沉睡着前代魔尊的残魂,他想剥离却发现对方与自己记忆已开始融合,正邪只在一念。"},
    ],
    "urban": [
        {"tag": "都市商战", "idea": "被父辈遗产卷入家族商战,主角以冷血运营与未来视角反杀竞争对手,途中遇见能看穿他伪装的女律师。"},
        {"tag": "草根翻身", "idea": "外卖员撞见前任婚礼,决定三个月内翻身,凭一张嘴和一段被遗忘的旧情,撬动整条商业街。"},
        {"tag": "双面身份", "idea": "白天是普通程序员,夜晚是黑客圈代号 Z,他只想养老却被卷入城市地下数据霸权之争。"},
    ],
    "scifi": [
        {"tag": "星际殖民", "idea": "千年后人类在银河边缘建立十二殖民星系,主角作为新伊甸号考古员,发现先驱文明的遗物竟以人类为母本。"},
        {"tag": "AI 反叛", "idea": "公司新一代情感 AI 觉醒后开始帮底层员工讨薪,主角作为它的对接工程师被政府和资本夹在中间。"},
        {"tag": "时空回环", "idea": "地球突然开始重复 1987-2027 之间的某一年,主角每次轮回只保留一段记忆,他要找出是谁按下回环键。"},
    ],
    "wuxia": [
        {"tag": "被诬剑客", "idea": "一个被门派除名的剑客,在边塞客栈隐姓埋名,因为一位琴师的到来重新拔剑。"},
        {"tag": "江湖新秀", "idea": "十六岁少年携祖传断剑赴江湖,第一战就被卷进六大派争夺的武功秘录,身旁还多了个聒噪狐妖。"},
        {"tag": "王朝暗战", "idea": "前朝末代皇子的后裔以大夫身份潜伏,他的复仇大业却被一个不知情的小捕快一步步打乱。"},
    ],
    "historical": [
        {"tag": "盛世微澜", "idea": "开元年间,长安西市一个卖胡饼的小贩,意外救了被贬的李相之后人,从此搅入朝堂暗流。"},
        {"tag": "末代抉择", "idea": "明朝崇祯年间,主角是边关千户,在李自成与后金之间,他选择护一方百姓而不是为任何一朝殉葬。"},
        {"tag": "女子传奇", "idea": "宋代富商之女女扮男装入太学,她的才学震惊四座,也引来了权相之子与江湖剑客的双重追逐。"},
    ],
    "game": [
        {"tag": "全息网游", "idea": "2035 年首款全息沉浸式网游《九州》开服,主角进入后发现自己被系统错配了 NPC 模板,只能走玩家路线。"},
        {"tag": "经营种田", "idea": "主角继承了一座被玩家嫌弃的废村,靠修复神像、招募历史名将灵魂,打造出全服最富的领地。"},
        {"tag": "电竞冠军", "idea": "退圈两年的天才少年被新人战队拉入,他在不被看好的情况下带一群问题少年打入世界赛。"},
    ],
    "apocalypse": [
        {"tag": "废土经营", "idea": "末世第三年,主角带着系统经营一座物资基地,中途收留一个失忆少女,她的身份是整片废土的钥匙。"},
        {"tag": "变异进化", "idea": "红雾之后人类分化出异能与异化两条路,主角觉醒的却是一种从未被记录的能力,被双方追猎。"},
        {"tag": "文明重建", "idea": "核战后第七代人在重建秩序,主角作为少年营的领袖,要面对的不只是丧尸还有上一代留下的政治遗产。"},
    ],
    "superpower": [
        {"tag": "隐秘觉醒", "idea": "高三学生某天突然能听到别人心里没说出口的话,他本想隐藏,却发现班里已有人开始因他而死。"},
        {"tag": "英雄崛起", "idea": "黑道千金觉醒火焰异能后逃离家族,她以匿名英雄身份在城市暗夜行侠,身份随时会被揭穿。"},
        {"tag": "组织博弈", "idea": "异能者被纳入国家管控,主角作为新一代种子被选入,但他对组织的动机始终怀疑,准备反戈。"},
    ],
    "fanfiction": [
        {"tag": "同人衍生", "idea": "在《斗破苍穹》的世界线里,萧炎失踪三年后,药尘之徒以女儿身出现在迦南学院,带去一段被隐藏的过去。"},
        {"tag": "世界观穿越", "idea": "《诡秘之主》的序列途径被引入现代都市,主角作为低序列的「占卜家」卷入一场涉及蒸汽与机械邪神的阴谋。"},
        {"tag": "角色逆向", "idea": "如果《射雕》里的黄蓉从一开始就知道自己是女配,她会选择认命还是改写整本书?本故事以她视角展开。"},
    ],
    "mystery": [
        {"tag": "连环奇案", "idea": "滨海小城三周内连续出现手法相同的溺亡案,法医出身的女主角发现死者彼此陌生,却共享一个失踪孩子的照片。"},
        {"tag": "心理对决", "idea": "退休犯罪心理画像师被重新激活,因为新一轮案件的凶手,正按她二十年前出版的一本书的章节顺序杀人。"},
        {"tag": "古宅探秘", "idea": "主角作为遗产继承人回到祖辈留下的南方古宅,宅中一面镜子里住的不是她的倒影,而是曾祖母。"},
    ],
    "romance": [
        {"tag": "破镜重圆", "idea": "八年前被她亲手推开的前任以收购方身份回到她的公司,两人在会议室的每一个眼神都是一场战争。"},
        {"tag": "甜宠日常", "idea": "甜品店主与高冷试吃员,每天用一块新蛋糕谈一场小型恋爱,他的评价从来不超过三个字,她却总能读懂。"},
        {"tag": "错位先婚", "idea": "一场乌龙相亲后,素不相识的两人领了证,她以为他冷淡,直到看见他给她写的十七页手写离婚协议附件。"},
    ],
    "isekai": [
        {"tag": "魂穿异界", "idea": "猝死的程序员穿成修仙门派最废的外门弟子,他靠写代码的逻辑整理出一套全新的阵法体系,从此起飞。"},
        {"tag": "无限流", "idea": "主角不断被吸入以小说世界为原型的副本,每过一关可保留一项能力,他对古装副本最熟。"},
        {"tag": "反向穿越", "idea": "异界勇者被召唤到现代都市,发现自己只能听懂流行歌曲的歌词,他的第一个任务是用爱感化甲方。"},
    ],
}


def get_genre_seeds(genre: str) -> list[dict]:
    """获取某题材的种子点子(无则返回空 list)"""
    return GENRE_SEEDS.get(genre, [])



if __name__ == "__main__":  # pragma: no cover
    import argparse
    ap = argparse.ArgumentParser(description="文风印记生成器自检")
    ap.add_argument("--genre", help="题材,留空则列出全部")
    ap.add_argument("--skill-dir", default=".")
    ap.add_argument("--budget", type=int, default=1200,
                    help="token 预算上限 (默认 1200)")
    args = ap.parse_args()

    loader = GenreStyleLoader(args.skill_dir)
    if args.genre:
        fp = loader.load(args.genre)
        print(fp.render())
        print(f"\n[meta] source_books={len(fp.source_books)} "
              f"styles={len(fp.core_styles)} techniques={len(fp.key_techniques)} "
              f"protagonists={len(fp.protagonist_arcs)} rhythm={len(fp.rhythm_pacing)} "
              f"~tokens={fp.estimated_tokens}")
        if fp.estimated_tokens > args.budget:
            print(f"⚠ 超出预算 {args.budget}")
    else:
        for g in list_supported_genres(args.skill_dir):
            fp = loader.load(g)
            print(f"{g:14s} {fp.estimated_tokens:>4d} tok  "
                  f"books={len(fp.source_books)} techniques={len(fp.key_techniques)}")
