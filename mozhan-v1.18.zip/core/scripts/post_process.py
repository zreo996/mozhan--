#!/usr/bin/env python3
"""
post_process.py — 章节写完后,正则提取事实回填四表

与 continuity_enforcer 共用时段词典(SHICHEN/古代描述性/现代/工作日)。
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

# ── 时段词典(与 continuity_enforcer 完全一致) ────────────
SHICHEN_HOURS = {
    "子时": 0, "丑时": 2, "寅时": 4, "卯时": 6, "辰时": 8, "巳时": 10,
    "午时": 12, "未时": 14, "申时": 16, "酉时": 18, "戌时": 20, "亥时": 22,
}
ANCIENT_PERIODS = {
    "拂晓": 5, "破晓": 5, "黎明": 5, "晨曦": 6, "卯时": 6,
    "晌午": 12, "午间": 12, "正午": 12, "晌后": 14,
    "申牌": 16, "日暮": 18, "薄暮": 18, "暮色": 18,
    "入夜": 20, "初更": 19, "二更": 21, "三更": 23,
    "四更": 1, "五更": 3, "夜半": 0, "子夜": 0, "天明": 5,
}
MODERN_PERIODS = {
    "凌晨": 3, "清晨": 6, "早晨": 7, "上午": 9, "中午": 12,
    "午后": 14, "下午": 15, "傍晚": 18, "黄昏": 18,
    "夜间": 20, "夜晚": 21, "深夜": 23,
}
WORKDAY_PERIODS = {
    "早高峰": 8, "上班时间": 10, "午休": 12, "晚高峰": 18,
    "下班后": 19, "宵夜时间": 22,
}

def _build_period_map() -> dict[str, int]:
    merged: dict[str, int] = {}
    merged.update(MODERN_PERIODS)
    merged.update(ANCIENT_PERIODS)
    merged.update(SHICHEN_HOURS)
    merged.update(WORKDAY_PERIODS)
    return merged

PERIOD_MAP = _build_period_map()
PERIOD_PATTERN = re.compile(
    "(" + "|".join(sorted(PERIOD_MAP.keys(), key=len, reverse=True)) + ")"
)


# ── 基础 IO ──────────────────────────────────────────────
def load_json(filepath, default=None):
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default if default is not None else {}


def save_json(filepath, data):
    Path(filepath).parent.mkdir(parents=True, exist_ok=True)
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


# ── 文本抽取 ──────────────────────────────────────────────
def _cn_num_to_int(s: str) -> int:
    cn_map = {"零":0,"一":1,"二":2,"三":3,"四":4,"五":5,
              "六":6,"七":7,"八":8,"九":9,"十":10,"百":100,"千":1000}
    if s.isdigit():
        return int(s)
    if "十" in s:
        parts = s.split("十")
        left = cn_map.get(parts[0], 1) if parts[0] else 1
        right = cn_map.get(parts[1], 0) if len(parts) > 1 and parts[1] else 0
        return left * 10 + right
    return cn_map.get(s[0], 1)


def extract_day_period(text: str) -> tuple[int, str]:
    """day 来自 "第X天",period 来自全套时段词典(取首个命中)"""
    day_match = re.search(r"第([一二三四五六七八九十百千\d]+)天", text)
    day = _cn_num_to_int(day_match.group(1)) if day_match else 1
    m = PERIOD_PATTERN.search(text)
    period = m.group(1) if m else "上午"
    return day, period


def extract_all_periods(text: str) -> list[str]:
    """按出现顺序返回所有时段词,供 update_timeline 顺序记录"""
    return [m.group(1) for m in PERIOD_PATTERN.finditer(text)]


def extract_locations(text):
    pattern = r"在(.+?)[，,。]|来到(.+?)[，,。]|出现在(.+?)[，,。]|抵达(.+?)[，,。]|到达(.+?)[，,。]"
    matches = re.findall(pattern, text)
    out = []
    for group in matches:
        for loc in group:
            if loc and 1 < len(loc) <= 20:
                out.append(loc.strip())
    seen, result = set(), []
    for x in out:
        if x not in seen:
            seen.add(x); result.append(x)
    return result


def extract_characters(text: str, character_table: dict | None = None) -> list[str]:
    """从角色表中匹配文本里出现的名字"""
    if not character_table:
        return []
    names = []
    for c in character_table.get("characters", []):
        name = c.get("name") if isinstance(c, dict) else None
        if name and name in text:
            names.append(name)
    return names


def extract_events(text):
    events = []
    patterns = [
        r"([^。\n]{1,12})遭遇([^。\n]{1,12})",
        r"([^。\n]{1,12})获得([^。\n]{1,12})",
        r"([^。\n]{1,12})击败([^。\n]{1,12})",
        r"([^。\n]{1,12})发现([^。\n]{1,12})",
        r"([^。\n]{1,12})死(?:亡)?",
    ]
    for pattern in patterns:
        for match in re.findall(pattern, text):
            if isinstance(match, tuple):
                events.append("·".join(m.strip() for m in match if m))
            else:
                events.append(match.strip())
    return events


def extract_items(text: str) -> list[dict]:
    items = []
    for m in re.finditer(r"获得(.+?)[，,。]|得到(.+?)[，,。]|捡到(.+?)[，,。]", text):
        name = next((g for g in m.groups() if g), "").strip()
        if name and len(name) <= 16:
            items.append({"action": "acquire", "item": name})
    for m in re.finditer(r"使用(.+?)[，,。]|服用(.+?)[，,。]|消耗(.+?)[，,。]", text):
        name = next((g for g in m.groups() if g), "").strip()
        if name and len(name) <= 16:
            items.append({"action": "use", "item": name})
    return items


def extract_hooks(text: str) -> list[str]:
    hooks = []
    hint_patterns = [
        r"似乎(.{2,20}?)隐藏",
        r"(.{2,12}?)的秘密",
        r"不知(.{2,15}?)从何说起",
        r"(.{2,15}?)来历不明",
        r"(.{2,15}?)究竟(.{0,8}?)?",
    ]
    for pattern in hint_patterns:
        for match in re.findall(pattern, text):
            if isinstance(match, tuple):
                hook_text = "·".join(m.strip() for m in match if m)
            else:
                hook_text = match.strip()
            if 5 <= len(hook_text) <= 40:
                hooks.append(hook_text)
    return hooks


# ── 处理器 ──────────────────────────────────────────────
class PostProcessor:
    def __init__(self, data_dir: str | Path, chapter_num: int):
        self.data_dir = Path(data_dir)
        self.chapter_num = int(chapter_num)
        self.timeline_path = self.data_dir / "timeline.json"
        self.characters_path = self.data_dir / "characters_snapshot.json"
        self.hooks_path = self.data_dir / "hooks.json"
        self.inventory_path = self.data_dir / "inventory.json"

    def load_all_tables(self):
        self.timeline = load_json(self.timeline_path, {
            "global_day": 1,
            "storylines": {"main": [], "sub": [], "villain": []},
            "sync_points": [],
        })
        self.characters = load_json(self.characters_path, {"characters": []})
        self.hooks = load_json(self.hooks_path, {"active": [], "dormant": [], "recovered": []})
        self.inventory = load_json(self.inventory_path, {"items": []})

    def save_all_tables(self):
        save_json(self.timeline_path, self.timeline)
        save_json(self.characters_path, self.characters)
        save_json(self.hooks_path, self.hooks)
        save_json(self.inventory_path, self.inventory)

    def update_timeline(self, chapter_text: str):
        day, period = extract_day_period(chapter_text)
        locations = extract_locations(chapter_text)
        names = extract_characters(chapter_text, self.characters)

        if day > self.timeline.get("global_day", 1):
            self.timeline["global_day"] = day

        event = {
            "chapter": self.chapter_num,
            "day": day,
            "period": period,
            "period_hour": PERIOD_MAP.get(period, -1),
            "all_periods": extract_all_periods(chapter_text)[:5],
            "event": f"第{self.chapter_num}章",
            "location": locations[0] if locations else "未知",
            "characters": names,
        }
        self.timeline.setdefault("storylines", {}).setdefault("main", []).append(event)

    def update_characters(self, chapter_text: str):
        names = extract_characters(chapter_text, self.characters)
        for c in self.characters.get("characters", []):
            if isinstance(c, dict) and c.get("name") in names:
                c["chapter_last_seen"] = self.chapter_num
                appearances = c.setdefault("appearances", [])
                if self.chapter_num not in appearances:
                    appearances.append(self.chapter_num)

    def update_hooks(self, chapter_text: str):
        for hook_text in extract_hooks(chapter_text):
            existing_ids = [h.get("id") for h in self.hooks.get("active", [])]
            hook_id = f"hook_{len(existing_ids) + 1:03d}"
            self.hooks.setdefault("active", []).append({
                "id": hook_id,
                "name": hook_text[:30],
                "introduced_day": self.timeline.get("global_day", 1),
                "introduced_chapter": self.chapter_num,
                "content": hook_text,
                "status": "active",
                "chapter_last_seen": self.chapter_num,
                "related_characters": extract_characters(chapter_text, self.characters)[:3],
                "tension": "中",
            })

    def update_inventory(self, chapter_text: str):
        for change in extract_items(chapter_text):
            item_name = change["item"]
            action = change["action"]
            existing = next(
                (it for it in self.inventory.get("items", []) if it.get("name") == item_name),
                None,
            )
            if existing:
                if action == "use" and existing.get("type") == "consumable":
                    remaining = existing.get("remaining", 1)
                    existing["remaining"] = max(0, remaining - 1)
                    if existing["remaining"] == 0:
                        existing["status"] = "consumed"
                existing.setdefault("history", []).append({
                    "chapter": self.chapter_num,
                    "action": action,
                })
            elif action == "acquire":
                self.inventory.setdefault("items", []).append({
                    "id": f"item_{len(self.inventory.get('items', [])) + 1:03d}",
                    "name": item_name,
                    "type": "unknown",
                    "rarity": "普通",
                    "owner": "主角",
                    "acquired_chapter": self.chapter_num,
                    "location": "主角身上",
                    "status": "owned",
                    "history": [{"chapter": self.chapter_num, "action": "acquire"}],
                })

    def process(self, chapter_file: str):
        print(f"处理章节: {chapter_file}")
        try:
            chapter_text = Path(chapter_file).read_text(encoding="utf-8")
        except Exception as e:
            print(f"读取章节文件失败: {e}")
            return

        self.load_all_tables()
        self.update_timeline(chapter_text)
        self.update_characters(chapter_text)
        self.update_hooks(chapter_text)
        self.update_inventory(chapter_text)
        self.save_all_tables()

        d, p = extract_day_period(chapter_text)
        print(f"  day={d} period={p} (hour={PERIOD_MAP.get(p, -1)})")
        print("  四表已保存。")


def main():
    if len(sys.argv) < 3:
        print("用法: python post_process.py <chapter_file> <chapter_num> [--data-dir DATA_DIR]")
        sys.exit(1)
    chapter_file = sys.argv[1]
    chapter_num = int(sys.argv[2])
    data_dir = "./data"
    if "--data-dir" in sys.argv:
        data_dir = sys.argv[sys.argv.index("--data-dir") + 1]
    PostProcessor(data_dir, chapter_num).process(chapter_file)


if __name__ == "__main__":
    main()
