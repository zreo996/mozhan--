#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
self_check.py — 五重自检 v2.0

整合 ContinuityEnforcer 作为权威 P0/P1 来源,自身追加 LINT 级别提示
和用户友好的彩色输出/JSON 报告。
"""
from __future__ import annotations

import json
import sys
from datetime import datetime
from pathlib import Path

# 强制 UTF-8 输出,避免 Windows GBK 终端无法打印 ✓✗ 字符
try:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
except Exception:
    pass

# 复用 continuity_enforcer 的权威核
sys.path.insert(0, str(Path(__file__).parent))
from continuity_enforcer import ContinuityEnforcer  # noqa: E402


class Colors:
    RED = "\033[91m"
    YELLOW = "\033[93m"
    GREEN = "\033[92m"
    CYAN = "\033[96m"
    BOLD = "\033[1m"
    RESET = "\033[0m"


def _print(level: str, msg: str):
    style = {
        "FATAL": f"{Colors.RED}{Colors.BOLD}[FATAL]{Colors.RESET}",
        "P1":    f"{Colors.YELLOW}[P1]{Colors.RESET}",
        "LINT":  f"{Colors.CYAN}[LINT]{Colors.RESET}",
        "PASS":  f"{Colors.GREEN}[PASS]{Colors.RESET}",
    }.get(level, f"[{level}]")
    print(f"{style} {msg}")


def _load_json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


class SelfChecker:
    """前端检查器 — 委托权威 P0 给 ContinuityEnforcer,自身补 LINT"""

    def __init__(self, data_dir: str | Path, chapter_num: int):
        self.data_dir = Path(data_dir)
        self.chapter_num = int(chapter_num)
        self.lint: list[str] = []

    # ── LINT 级:格式/字段完整性 ──────────────────────────
    def lint_characters(self):
        chars = _load_json(self.data_dir / "characters_snapshot.json",
                           {"characters": []})
        for c in chars.get("characters", []):
            name = c.get("name", "未知")
            if c.get("status") in ("死亡", "退隐"):
                continue
            if not c.get("cultivation_level"):
                self.lint.append(f"角色 {name} 缺 cultivation_level 字段")
            if not c.get("location"):
                self.lint.append(f"角色 {name} 缺 location 字段")

    def lint_inventory(self):
        inv = _load_json(self.data_dir / "inventory.json", {"items": []})
        for it in inv.get("items", []):
            if not it.get("type"):
                self.lint.append(f"物品 {it.get('name', '未知')} 缺 type 字段")
            if it.get("type") == "consumable" and "remaining" not in it:
                self.lint.append(
                    f"消耗品 {it.get('name', '未知')} 缺 remaining 字段")

    def lint_hooks(self):
        hooks = _load_json(self.data_dir / "hooks.json",
                           {"active": [], "dormant": [], "recovered": []})
        for h in hooks.get("dormant", []):
            since = h.get("dormant_since_chapter", 0)
            gap = self.chapter_num - since
            if gap > 30:
                self.lint.append(
                    f"伏笔 '{h.get('name', '未知')}' 已休眠 {gap} 章,考虑清理")

    # ── 主入口 ─────────────────────────────────────────────
    def run(self, chapter_text: str = "", verbose: bool = False, silent: bool = False) -> dict:
        # 1. 权威 P0/P1 — ContinuityEnforcer
        enforcer = ContinuityEnforcer(str(self.data_dir), self.chapter_num)
        core_result = enforcer.enforce(chapter_text)

        # 2. 自身 LINT
        self.lint_characters()
        self.lint_inventory()
        self.lint_hooks()

        # 3. 汇总
        issues = core_result["issues"]
        p0 = [i for i in issues if i["level"] == "P0"]
        p1 = [i for i in issues if i["level"] == "P1"]

        report = {
            "chapter": self.chapter_num,
            "timestamp": datetime.now().isoformat(),
            "passed": core_result["passed"],
            "summary": {
                "p0_count": len(p0),
                "p1_count": len(p1),
                "lint_count": len(self.lint),
                "checks": core_result["summary"]["checks"],
            },
            "p0": p0,
            "p1": p1,
            "lint": self.lint,
        }

        if not silent:
            self._print_report(report, verbose=verbose)
        return report

    # ── 输出 ──────────────────────────────────────────────
    def _print_report(self, report: dict, verbose: bool):
        print(f"\n{Colors.BOLD}{'='*52}")
        print(f"自检报告 · 章节 #{self.chapter_num}")
        print(f"{'='*52}{Colors.RESET}\n")

        checks = report["summary"]["checks"]
        for name, passed in checks.items():
            _print("PASS" if passed else "FATAL", f"{name}检查 {'通过' if passed else '失败'}")

        if report["p0"]:
            print(f"\n{Colors.RED}{Colors.BOLD}P0 错误 ({len(report['p0'])}):{Colors.RESET}")
            for i in report["p0"]:
                _print("FATAL", f"[{i['type']}] {i['message']}")

        if report["p1"]:
            print(f"\n{Colors.YELLOW}P1 警告 ({len(report['p1'])}):{Colors.RESET}")
            for i in report["p1"]:
                _print("P1", f"[{i['type']}] {i['message']}")

        if self.lint and verbose:
            print(f"\n{Colors.CYAN}LINT 提示 ({len(self.lint)}):{Colors.RESET}")
            for m in self.lint:
                _print("LINT", m)

        print()
        if report["passed"]:
            print(f"{Colors.GREEN}{Colors.BOLD}[OK] P0 全部通过,章节可交付{Colors.RESET}")
        else:
            print(f"{Colors.RED}{Colors.BOLD}[FAIL] P0 未通过,必须回修{Colors.RESET}")

    def save_report(self, report: dict, path: str | Path | None = None):
        if path is None:
            path = self.data_dir / f"check_report_chapter_{self.chapter_num}.json"
        Path(path).write_text(
            json.dumps(report, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        print(f"\n{Colors.CYAN}报告已保存: {path}{Colors.RESET}")


def main():
    if len(sys.argv) < 2:
        print("用法: python self_check.py <chapter_num> [--data-dir DIR] [--text FILE] [--verbose] [--json] [--save-report]")
        sys.exit(1)

    chapter_num = int(sys.argv[1])
    data_dir = "./data"
    if "--data-dir" in sys.argv:
        data_dir = sys.argv[sys.argv.index("--data-dir") + 1]
    chapter_text = ""
    if "--text" in sys.argv:
        chapter_text = Path(sys.argv[sys.argv.index("--text") + 1]).read_text(encoding="utf-8")
    verbose = "--verbose" in sys.argv
    as_json = "--json" in sys.argv
    save = "--save-report" in sys.argv

    checker = SelfChecker(data_dir, chapter_num)
    report = checker.run(chapter_text, verbose=verbose)
    if save:
        checker.save_report(report)
    if as_json:
        print(json.dumps({
            "chapter": chapter_num,
            "passed": report["passed"],
            "p0_count": report["summary"]["p0_count"],
            "p1_count": report["summary"]["p1_count"],
            "lint_count": report["summary"]["lint_count"],
        }, ensure_ascii=False))

    sys.exit(0 if report["passed"] else 1)


if __name__ == "__main__":
    main()
