#!/usr/bin/env python3
"""
连续性强制系统 (Continuity Enforcer) v1.0

P0 级强制校验:基于四表的连续性图状态机
- 时间线单调性
- 角色位置一致性
- 修为/能力不倒退
- 伏笔回收强制
- 物品流转闭环
- 角色幽灵检测

依据: SKILL.md v1.13 / ITERATION_LOG v2.0 缺陷#1
"""

import json
import re
import sys
from pathlib import Path
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Set, Tuple
from datetime import datetime


# ============================================================
# 数据结构
# ============================================================

@dataclass
class ContinuityIssue:
    """连续性问题"""
    level: str               # P0 / P1 / P2
    type: str                # 问题类型
    message: str             # 描述
    chapter: int             # 章节号
    detail: dict = field(default_factory=dict)

    def to_dict(self):
        return {
            "level": self.level,
            "type": self.type,
            "message": self.message,
            "chapter": self.chapter,
            "detail": self.detail
        }


@dataclass
class ContinuityState:
    """当前连续性快照"""
    current_chapter: int
    current_day: int
    current_period: str
    character_positions: Dict[str, str]
    character_levels: Dict[str, int]
    active_hooks: List[dict]
    inventory: List[dict]
    exited_characters: Set[str]


# ============================================================
# 主类
# ============================================================

class ContinuityEnforcer:
    """连续性强制系统主类"""

    # 古代12时辰(对应小时) - 武侠/玄幻/历史/仙侠常用
    SHICHEN_HOURS = {
        "子时": 0, "丑时": 2, "寅时": 4, "卯时": 6,
        "辰时": 8, "巳时": 10, "午时": 12, "未时": 14,
        "申时": 16, "酉时": 18, "戌时": 20, "亥时": 22
    }

    # 古代描述性时段(对应小时,大致映射)
    ANCIENT_PERIODS = {
        "拂晓": 5, "破晓": 5, "黎明": 5, "晨曦": 6, "鸡鸣": 5,
        "天明": 6, "日出": 6, "清晨": 6, "早晨": 7,
        "晌午": 11, "日中": 12, "正午": 12, "日昳": 13,
        "日入": 18, "黄昏": 18, "薄暮": 18, "暮色": 19,
        "人定": 21, "夜半": 0, "子夜": 0,
        "三更": 23, "四更": 1, "五更": 3,
        "夜阑": 23
    }

    # 现代时段
    MODERN_PERIODS = {
        "凌晨": 3, "清晨": 6, "早晨": 7, "上午": 9,
        "中午": 12, "午后": 14, "下午": 15, "傍晚": 18,
        "黄昏": 18, "晚上": 20, "夜间": 22, "深夜": 23,
        "夜晚": 22
    }

    # 现代工作日(都市文常用)
    WORKDAY_PERIODS = {
        "早高峰": 8, "上班时间": 10, "午休": 12,
        "下班": 18, "晚饭后": 20, "宵夜时段": 23
    }

    @classmethod
    def _build_period_map(cls):
        """合并所有时段→小时映射"""
        merged = {}
        merged.update(cls.MODERN_PERIODS)
        merged.update(cls.ANCIENT_PERIODS)
        merged.update(cls.SHICHEN_HOURS)
        merged.update(cls.WORKDAY_PERIODS)
        return merged

    # 通用修为/等级关键词
    LEVEL_KEYWORDS = [
        "炼气", "筑基", "金丹", "元婴", "化神", "炼虚", "合体", "大乘", "渡劫",
        "见习", "学徒", "初级", "中级", "高级", "宗师", "大师",
        "Lv", "等级", "境界"
    ]

    def __init__(self, data_dir: str, chapter_num: int):
        self.data_dir = Path(data_dir)
        self.chapter_num = chapter_num
        self.issues: List[ContinuityIssue] = []

        # 加载四表
        self.timeline = self._load_json("timeline.json", default={
            "global_day": 1,
            "storylines": {"main": [], "sub": [], "villain": []},
            "sync_points": []
        })
        self.characters = self._load_json("characters_snapshot.json",
                                         default={"characters": []})
        self.hooks = self._load_json("hooks.json",
                                    default={"active": [], "dormant": [], "recovered": []})
        self.inventory = self._load_json("inventory.json", default={"items": []})

    def _load_json(self, name: str, default=None) -> dict:
        path = self.data_dir / name
        if not path.exists():
            return default or {}
        try:
            return json.loads(path.read_text(encoding='utf-8'))
        except Exception as e:
            self._add_issue("P0", "数据加载失败", f"无法解析 {name}: {e}")
            return default or {}

    def _save_json(self, name: str, data: dict):
        path = self.data_dir / name
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')

    def _add_issue(self, level: str, type_: str, message: str, **detail):
        self.issues.append(ContinuityIssue(
            level=level, type=type_, message=message,
            chapter=self.chapter_num, detail=detail
        ))

    # ========================================================
    # P0 检查 #1: 时间线单调性
    # ========================================================

    def check_timeline_monotonicity(self, chapter_text: str) -> bool:
        """时间线必须单调递增,period不可逆序跳跃"""
        cur_day = self.timeline.get("global_day", 1)

        # 章节内显式日期
        day_matches = re.findall(r'第\s*(\d+)\s*天', chapter_text)
        if day_matches:
            chapter_days = [int(d) for d in day_matches]
            min_day = min(chapter_days)
            max_day = max(chapter_days)

            if min_day < cur_day - 1:
                self._add_issue(
                    "P0", "时间线回退",
                    f"当前推进至第{cur_day}天,本章却出现第{min_day}天",
                    current_day=cur_day, found_day=min_day
                )
                return False

            # 章内倒序
            for i in range(len(chapter_days) - 1):
                if chapter_days[i + 1] < chapter_days[i] - 1:
                    self._add_issue(
                        "P0", "章内时间倒序",
                        f"第{chapter_days[i]}天后出现第{chapter_days[i+1]}天",
                        sequence=chapter_days
                    )
                    return False

        # period 检查 - 兼容古代(12时辰/描述性)和现代时段
        period_map = self._build_period_map()
        all_periods_pattern = '|'.join(sorted(period_map.keys(), key=len, reverse=True))
        period_matches = re.findall(f'({all_periods_pattern})', chapter_text)

        if len(period_matches) >= 2:
            # 转为小时序列
            hours = [period_map[p] for p in period_matches]
            for i in range(len(hours) - 1):
                # 容忍同一天内的合理跳跃,小时回退超过6小时视为可疑
                delta = hours[i + 1] - hours[i]
                # 负向跳跃(超过-6小时)且非跨日表述 → 警告
                if delta < -6:
                    if not re.search(r'次日|第二天|翌日|过了一夜|隔日|明日', chapter_text):
                        self._add_issue(
                            "P0", "时段逆序",
                            f"{period_matches[i]}({hours[i]}时)→{period_matches[i+1]}({hours[i+1]}时) 无跨日说明",
                            sequence=period_matches
                        )
                        return False
        return True

    # ========================================================
    # P0 检查 #2: 角色位置一致性
    # ========================================================

    def check_character_positions(self, chapter_text: str) -> bool:
        """角色不能瞬移:last_moved必须与当前场景一致"""
        ok = True
        for char in self.characters.get("characters", []):
            name = char.get("name")
            if not name or name not in chapter_text:
                continue

            last_loc = char.get("last_location")
            last_moved_ch = char.get("last_moved_chapter", 0)

            if not last_loc:
                continue

            # 章节内出现的地点
            locs_in_chapter = self._extract_locations(chapter_text)

            # 如果角色在本章活动,场景必须包含last_location或有明确移动叙述
            if locs_in_chapter and last_loc not in locs_in_chapter:
                moved = self._detect_movement(chapter_text, name)
                chapters_since_move = self.chapter_num - last_moved_ch
                if not moved and chapters_since_move <= 1:
                    self._add_issue(
                        "P0", "角色瞬移",
                        f"{name} 上章在 {last_loc},本章出现在 {locs_in_chapter} 无移动叙述",
                        character=name, expected=last_loc, found=locs_in_chapter
                    )
                    ok = False
        return ok

    def _extract_locations(self, text: str) -> List[str]:
        patterns = [
            r'在(.+?)[,，。]',
            r'来到(.+?)[,，。]',
            r'抵达(.+?)[,，。]',
            r'位于(.+?)[,，。]'
        ]
        locs = set()
        for p in patterns:
            for m in re.findall(p, text):
                if 1 < len(m) < 20:
                    locs.add(m.strip())
        return list(locs)

    def _detect_movement(self, text: str, name: str) -> bool:
        """检测是否有角色移动叙述"""
        movement_words = ["前往", "赶往", "动身", "出发", "离开", "回到",
                         "来到", "抵达", "途中", "路上", "走向", "飞往"]
        # 角色名附近(±50字)是否出现移动词
        for m in re.finditer(re.escape(name), text):
            window = text[max(0, m.start() - 50):m.end() + 50]
            if any(w in window for w in movement_words):
                return True
        return False

    # ========================================================
    # P0 检查 #3: 修为/能力不倒退
    # ========================================================

    def check_power_progression(self, chapter_text: str) -> bool:
        """修为只能升不能降"""
        ok = True
        for char in self.characters.get("characters", []):
            name = char.get("name")
            recorded_level = char.get("cultivation_level") or char.get("power_level")
            if not name or recorded_level is None:
                continue

            # 在文中检测显式等级
            detected = self._detect_power_level(chapter_text, name)
            if detected is not None and isinstance(recorded_level, int):
                if detected < recorded_level:
                    self._add_issue(
                        "P0", "修为倒退",
                        f"{name} 记录等级 {recorded_level},本章降至 {detected}",
                        character=name, recorded=recorded_level, found=detected
                    )
                    ok = False
        return ok

    def _detect_power_level(self, text: str, name: str) -> Optional[int]:
        """从文中提取角色等级(数字型)"""
        for m in re.finditer(re.escape(name), text):
            window = text[m.end():m.end() + 80]
            # Lv.XX / 等级XX
            lvl = re.search(r'(?:Lv\.?|等级|Level)\s*(\d+)', window)
            if lvl:
                return int(lvl.group(1))
        return None

    # ========================================================
    # P0 检查 #4: 伏笔回收强制
    # ========================================================

    def check_hook_recovery(self) -> bool:
        """active hook 超3章未推进 → P0"""
        ok = True
        for hook in self.hooks.get("active", []):
            introduced = hook.get("introduced_chapter", self.chapter_num)
            last_mentioned = hook.get("last_mentioned_chapter", introduced)
            gap = self.chapter_num - last_mentioned

            if gap > 3:
                self._add_issue(
                    "P0", "伏笔丢失",
                    f"伏笔『{hook.get('name', '未命名')}』已 {gap} 章未推进",
                    hook=hook.get("name"), gap=gap,
                    last_mentioned=last_mentioned
                )
                ok = False
        return ok

    # ========================================================
    # P0 检查 #5: 物品流转闭环
    # ========================================================

    def check_inventory_integrity(self, chapter_text: str) -> bool:
        """已获得物品不能凭空消失"""
        ok = True
        for item in self.inventory.get("items", []):
            name = item.get("name")
            status = item.get("status", "owned")
            owner = item.get("owner")

            if not name:
                continue

            # 已消耗但未记录章节
            if status == "consumed" and not item.get("disposed_chapter"):
                self._add_issue(
                    "P0", "物品状态异常",
                    f"物品『{name}』标记为consumed但无disposed_chapter",
                    item=name
                )
                ok = False

            # owned 但角色已退场
            if status == "owned" and owner in self._get_exited_characters():
                self._add_issue(
                    "P1", "物品归属悬置",
                    f"物品『{name}』归属于已退场角色 {owner}",
                    item=name, owner=owner
                )
        return ok

    def _get_exited_characters(self) -> Set[str]:
        return {c.get("name") for c in self.characters.get("characters", [])
                if c.get("status") == "exited"}

    # ========================================================
    # P0 检查 #6: 角色幽灵检测
    # ========================================================

    def check_character_ghost(self, chapter_text: str) -> bool:
        """已退场角色不能再次出现(除非复活/回忆)"""
        ok = True
        exited = self._get_exited_characters()
        for name in exited:
            if name and name in chapter_text:
                # 容忍回忆/提及
                ghost_context = self._is_ghost_appearance(chapter_text, name)
                if ghost_context:
                    self._add_issue(
                        "P0", "角色幽灵",
                        f"已退场角色 {name} 再次实体出现",
                        character=name
                    )
                    ok = False
        return ok

    def _is_ghost_appearance(self, text: str, name: str) -> bool:
        """判断是否实体出现(非回忆/提及)"""
        for m in re.finditer(re.escape(name), text):
            window = text[max(0, m.start() - 30):m.end() + 30]
            # 回忆类标记
            if any(w in window for w in ["回忆", "想起", "曾经", "已死", "提起", "若是", "如果"]):
                continue
            # 动作类标记 → 实体出现
            if any(w in window for w in ["说", "道", "看", "走", "出现", "现身", "杀"]):
                return True
        return False

    # ========================================================
    # 总执行入口
    # ========================================================

    def enforce(self, chapter_text: str) -> dict:
        """执行所有连续性检查"""
        checks = [
            ("时间线", self.check_timeline_monotonicity, [chapter_text]),
            ("位置", self.check_character_positions, [chapter_text]),
            ("修为", self.check_power_progression, [chapter_text]),
            ("伏笔", self.check_hook_recovery, []),
            ("物品", self.check_inventory_integrity, [chapter_text]),
            ("幽灵", self.check_character_ghost, [chapter_text]),
        ]

        results = {}
        for name, fn, args in checks:
            try:
                results[name] = fn(*args)
            except Exception as e:
                results[name] = False
                self._add_issue("P0", "检查异常", f"{name}检查失败: {e}")

        p0_count = sum(1 for i in self.issues if i.level == "P0")
        p1_count = sum(1 for i in self.issues if i.level == "P1")

        return {
            "chapter": self.chapter_num,
            "timestamp": datetime.now().isoformat(),
            "passed": p0_count == 0,
            "summary": {
                "p0_count": p0_count,
                "p1_count": p1_count,
                "checks": results
            },
            "issues": [i.to_dict() for i in self.issues]
        }


def main():
    if len(sys.argv) < 3:
        print("用法: python continuity_enforcer.py <data_dir> <chapter_num> [--text <file>]")
        sys.exit(1)

    data_dir = sys.argv[1]
    chapter_num = int(sys.argv[2])

    text = ""
    if "--text" in sys.argv:
        idx = sys.argv.index("--text")
        with open(sys.argv[idx + 1], 'r', encoding='utf-8') as f:
            text = f.read()

    enforcer = ContinuityEnforcer(data_dir, chapter_num)
    result = enforcer.enforce(text)

    print(json.dumps(result, ensure_ascii=False, indent=2))
    sys.exit(0 if result["passed"] else 1)


if __name__ == "__main__":
    main()
