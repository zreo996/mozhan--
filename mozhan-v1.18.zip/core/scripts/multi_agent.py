#!/usr/bin/env python3
"""
多Agent会诊机制 (Multi-Agent Consultation) v1.0

实现"单模型多角色"架构 - 通过prompt模板让同一模型扮演多个专家角色
适用场景: L2/L3/L4 章节,需要多专家协同的复杂场景

设计依据: core/references/multi_agent.md
"""

import json
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from dataclasses import dataclass, field
from typing import Any, List, Dict, Optional, Callable
from datetime import datetime


# ============================================================
# 专家角色定义
# ============================================================

@dataclass
class ExpertRole:
    """专家角色定义"""
    name: str                       # 角色名
    code: str                       # 代号
    prompt_template: str            # prompt模板
    output_target: int              # 期望输出字数
    use_cases: List[str]            # 适用场景

    def build_prompt(self, context: dict) -> str:
        """根据上下文构建prompt"""
        try:
            return self.prompt_template.format(**context)
        except KeyError as e:
            return self.prompt_template + f"\n\n[警告:上下文缺失 {e}]"


# ============================================================
# 内置专家角色库
# ============================================================

EXPERTS = {
    "scene": ExpertRole(
        name="场景专家",
        code="scene",
        prompt_template=(
            "你是一个专业的场景描写专家。专注于:\n"
            "- 环境细节具体化(颜色/声音/气味/触感)\n"
            "- 氛围营造(紧张/轻松/诡异/温馨)\n"
            "- 场景之间的自然过渡\n"
            "- 感官描写的层次感\n\n"
            "题材: {genre}\n"
            "时段: {period}\n"
            "地点: {location}\n"
            "氛围: {mood}\n"
            "场景要求: {scene_requirements}\n\n"
            "请输出该场景的详细描写(约500字)。"
        ),
        output_target=500,
        use_cases=["环境描写", "氛围营造", "场景转换"]
    ),
    "dialogue": ExpertRole(
        name="对话专家",
        code="dialogue",
        prompt_template=(
            "你是一个专业的对话写作专家。专注于:\n"
            "- 角色专属语言风格(口头禅/说话方式)\n"
            "- 对话的信息增量(不说废话)\n"
            "- 潜台词和言外之意\n"
            "- 角色关系的动态变化\n\n"
            "题材: {genre}\n"
            "参与角色: {characters}\n"
            "角色关系: {relationships}\n"
            "对话目标: {dialogue_goal}\n"
            "对话场景: {scene_context}\n\n"
            "请输出该对话(约300-500字,每段对话不超过8句)。"
        ),
        output_target=400,
        use_cases=["关键对话", "情感冲突", "信息传递"]
    ),
    "plot": ExpertRole(
        name="情节专家",
        code="plot",
        prompt_template=(
            "你是一个专业的情节设计专家。专注于:\n"
            "- 因果逻辑的严密性\n"
            "- 冲突的递进与转折\n"
            "- 伏笔的埋设与回收\n"
            "- 节奏的张弛控制\n\n"
            "题材: {genre}\n"
            "当前章节: {chapter_num}\n"
            "本章核心冲突: {core_conflict}\n"
            "需要回收的伏笔: {hooks_to_recover}\n"
            "需要埋设的伏笔: {hooks_to_plant}\n"
            "下一章预定走向: {next_chapter_setup}\n\n"
            "请输出情节大纲(约300字),包括:起承转合四段。"
        ),
        output_target=300,
        use_cases=["情节规划", "冲突设计", "伏笔管理"]
    ),
    "setting": ExpertRole(
        name="设定专家",
        code="setting",
        prompt_template=(
            "你是一个专业的世界观设定专家。专注于:\n"
            "- 设定的内部一致性\n"
            "- 修炼/能力/科技体系的逻辑\n"
            "- 社会规则与文化背景\n"
            "- 与既有设定的衔接\n\n"
            "题材: {genre}\n"
            "当前设定要素: {existing_settings}\n"
            "需要补充的设定: {new_settings_needed}\n"
            "约束条件: {constraints}\n\n"
            "请输出设定补充说明(约200-400字),确保与既有设定无冲突。"
        ),
        output_target=300,
        use_cases=["世界观补充", "设定校验", "体系完善"]
    ),
    "character": ExpertRole(
        name="人设专家",
        code="character",
        prompt_template=(
            "你是一个专业的人设一致性专家。专注于:\n"
            "- 角色性格的稳定性\n"
            "- 言行与背景的一致\n"
            "- 决策与价值观对齐\n"
            "- 成长弧线的合理性\n\n"
            "角色: {character_name}\n"
            "角色档案: {character_profile}\n"
            "本章预定行为: {planned_actions}\n"
            "拟用对话/反应: {planned_dialogue}\n\n"
            "请评估上述行为/对话是否符合人设(必须遵循人设>节奏>情感>对话的优先级)。\n"
            "输出格式: \n"
            "- 一致性评分: 1-10\n"
            "- 冲突点: [...]\n"
            "- 修改建议: [...]"
        ),
        output_target=200,
        use_cases=["人设校验", "OOC预防", "行为审查"]
    ),
    "pacing": ExpertRole(
        name="节奏专家",
        code="pacing",
        prompt_template=(
            "你是一个专业的网文节奏控制专家。专注于:\n"
            "- 章节钩子频率\n"
            "- 爽点密度(每100章18-25次打脸)\n"
            "- 情感波动节奏\n"
            "- 对话-叙事配比\n\n"
            "当前章节: {chapter_num}\n"
            "本章字数: {word_count}\n"
            "本章类型: {chapter_type}\n"
            "已使用爽点(近30章): {recent_climaxes}\n"
            "本章草稿: {chapter_draft}\n\n"
            "请评估节奏并提出调整建议,输出:\n"
            "- 钩子密度评分: 1-10\n"
            "- 爽点位置建议\n"
            "- 节奏问题: [...]\n"
            "- 修改建议: [...]"
        ),
        output_target=250,
        use_cases=["节奏审查", "钩子设计", "爽点排布"]
    ),
}


# ============================================================
# 会诊编排器
# ============================================================

@dataclass
class ConsultationResult:
    """会诊结果"""
    expert_code: str
    expert_name: str
    prompt: str
    response: str = ""
    score: Optional[float] = None
    issues: List[str] = field(default_factory=list)
    suggestions: List[str] = field(default_factory=list)
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


class MultiAgentOrchestrator:
    """多Agent会诊编排器(并行执行版)"""

    def __init__(self, chapter_level: str = "L2", max_workers: int = 4):
        """
        Args:
            chapter_level: L1/L2/L3/L4 章节等级
            max_workers: 并发线程数(同时咨询的专家数上限)
        """
        self.chapter_level = chapter_level
        self.max_workers = max_workers
        self.results: List[ConsultationResult] = []
        self.llm_caller: Optional[Callable[[str], str]] = None
        self._llm_client: Any = None
        self._frozen: Any = None

    def register_llm_caller(self, fn: Callable[[str], str]):
        """注册简易 LLM 调用函数 (prompt -> text)"""
        self.llm_caller = fn

    def register_llm_client(self, client: Any, frozen: Any = None):
        """直接挂接 LLMClient(从 llm_client.py 导入),并行走 Prompt Caching"""
        self._llm_client = client
        self._frozen = frozen

    def select_experts(self, scenario: str) -> List[ExpertRole]:
        """根据场景和章节等级选择专家"""
        if self.chapter_level == "L1":
            # L1: 仅人设+节奏自检
            codes = ["character", "pacing"]
        elif self.chapter_level == "L2":
            # L2: 关键章,4专家
            codes = ["scene", "dialogue", "character", "pacing"]
        elif self.chapter_level == "L3":
            # L3: 核心章,全员上阵
            codes = ["scene", "dialogue", "plot", "setting", "character", "pacing"]
        elif self.chapter_level == "L4":
            # L4: 宏篇章,加入情节+设定深度审
            codes = ["plot", "setting", "character", "pacing", "scene", "dialogue"]
        else:
            codes = ["character"]

        # 场景关键词额外触发
        scenario_lower = scenario.lower()
        if "战斗" in scenario or "战争" in scenario:
            if "pacing" not in codes:
                codes.append("pacing")
        if "对话" in scenario or "争辩" in scenario:
            if "dialogue" not in codes:
                codes.append("dialogue")
        if "新设定" in scenario or "新功法" in scenario:
            if "setting" not in codes:
                codes.append("setting")

        return [EXPERTS[c] for c in codes if c in EXPERTS]

    def consult(self, scenario: str, context: dict) -> List[ConsultationResult]:
        """并行执行会诊"""
        experts = self.select_experts(scenario)

        # 预构建结果(占位),保持专家顺序
        prebuilt: list[ConsultationResult] = [
            ConsultationResult(
                expert_code=e.code,
                expert_name=e.name,
                prompt=e.build_prompt(context),
            )
            for e in experts
        ]

        def _run(idx: int, expert: ExpertRole, result: ConsultationResult):
            if self._llm_client is not None:
                try:
                    r = self._llm_client.call(
                        prompt=result.prompt,
                        frozen=self._frozen,
                        level=self.chapter_level,
                        max_tokens=expert.output_target * 4 + 500,
                        tag=f"agent:{expert.code}",
                    )
                    result.response = r.text
                except Exception as e:
                    result.issues.append(f"LLMClient调用失败: {e}")
            elif self.llm_caller is not None:
                try:
                    result.response = self.llm_caller(result.prompt)
                except Exception as e:
                    result.issues.append(f"LLM调用失败: {e}")
            else:
                result.response = "[dry-run] 未注册LLM,仅返回prompt"
            self._parse_score(result)
            return idx, result

        if not experts:
            self.results.extend(prebuilt)
            return self.results

        with ThreadPoolExecutor(max_workers=self.max_workers) as pool:
            futures = [
                pool.submit(_run, i, e, prebuilt[i])
                for i, e in enumerate(experts)
            ]
            for fut in as_completed(futures):
                try:
                    fut.result()
                except Exception as e:
                    pass  # 已记录到 result.issues

        self.results.extend(prebuilt)
        return self.results

    def _parse_score(self, result: ConsultationResult):
        """从响应中提取评分"""
        import re
        m = re.search(r'(?:评分|score)[:：]\s*(\d+(?:\.\d+)?)', result.response, re.IGNORECASE)
        if m:
            try:
                result.score = float(m.group(1))
            except ValueError:
                pass

    def summary(self) -> dict:
        """会诊总结"""
        total_issues = sum(len(r.issues) for r in self.results)
        avg_score = None
        scores = [r.score for r in self.results if r.score is not None]
        if scores:
            avg_score = sum(scores) / len(scores)

        return {
            "chapter_level": self.chapter_level,
            "expert_count": len(self.results),
            "total_issues": total_issues,
            "average_score": avg_score,
            "experts_consulted": [r.expert_code for r in self.results],
            "timestamp": datetime.now().isoformat()
        }

    def export(self, output_path: str):
        """导出会诊结果"""
        data = {
            "summary": self.summary(),
            "results": [
                {
                    "expert": r.expert_name,
                    "code": r.expert_code,
                    "prompt": r.prompt,
                    "response": r.response,
                    "score": r.score,
                    "issues": r.issues,
                    "suggestions": r.suggestions,
                    "timestamp": r.timestamp
                }
                for r in self.results
            ]
        }
        Path(output_path).write_text(
            json.dumps(data, ensure_ascii=False, indent=2),
            encoding='utf-8'
        )


def main():
    """CLI入口 - 仅dry-run演示(不实际调用LLM)"""
    if len(sys.argv) < 3:
        print("用法: python multi_agent.py <chapter_level> <scenario> [--context <json>] [--output <file>]")
        print("  chapter_level: L1/L2/L3/L4")
        print("  scenario: 场景描述,如 战斗/对话/新设定")
        print("\n示例:")
        print("  python multi_agent.py L3 战斗 --context context.json")
        sys.exit(1)

    level = sys.argv[1]
    scenario = sys.argv[2]

    context = {
        "genre": "玄幻", "period": "黄昏", "location": "断魂崖",
        "mood": "紧张", "scene_requirements": "主角与仇人对决",
        "characters": "主角,反派首领", "relationships": "杀父仇人",
        "dialogue_goal": "揭露真相", "scene_context": "悬崖之巅",
        "chapter_num": 33, "core_conflict": "复仇决战",
        "hooks_to_recover": "玉佩之谜", "hooks_to_plant": "幕后黑手",
        "next_chapter_setup": "新势力登场",
        "existing_settings": "炼气期", "new_settings_needed": "突破金丹",
        "constraints": "符合修为体系",
        "character_name": "主角", "character_profile": "沉默寡言,内心炽烈",
        "planned_actions": "拔剑反击", "planned_dialogue": "短促应答",
        "word_count": 3000, "chapter_type": "高潮",
        "recent_climaxes": "近10章2次大打脸", "chapter_draft": "[草稿略]"
    }

    if "--context" in sys.argv:
        idx = sys.argv.index("--context")
        with open(sys.argv[idx + 1], 'r', encoding='utf-8') as f:
            context.update(json.load(f))

    orchestrator = MultiAgentOrchestrator(chapter_level=level)
    results = orchestrator.consult(scenario, context)

    output_path = "./consultation_result.json"
    if "--output" in sys.argv:
        idx = sys.argv.index("--output")
        output_path = sys.argv[idx + 1]
    orchestrator.export(output_path)

    print(f"会诊完成,共调用 {len(results)} 位专家")
    print(f"专家列表: {[r.expert_name for r in results]}")
    print(f"结果已保存至: {output_path}")


if __name__ == "__main__":
    main()
