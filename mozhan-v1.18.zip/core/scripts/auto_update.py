"""
SKILL.md 自动更新迭代系统 v1.0

功能：
1. 事件驱动触发分析
2. 自动提取教训和成功模式
3. 生成SKILL.md更新草案
4. 人工审核后生效

触发条件：
- 完成一本书后
- 完成重要章节（高潮/转折）后
- 发现重大质量问题时
- 用户主动要求时
"""

import json
import os
from datetime import datetime
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple
from enum import Enum


class TriggerType(Enum):
    """触发类型"""
    BOOK_COMPLETE = "book_complete"           # 完成一本书
    CHAPTER_COMPLETE = "chapter_complete"      # 完成重要章节
    QUALITY_ISSUE = "quality_issue"           # 质量问题
    USER_REQUEST = "user_request"             # 用户主动


@dataclass
class Lesson:
    """教训记录"""
    category: str                              # 四表/成本/质量/题材
    content: str                              # 教训内容
    severity: int                             # 严重程度 1-5
    chapter_or_project: str                  # 来源章节/项目
    date: str                                 # 记录日期
    status: str = "pending"                   # pending/approved/rejected


@dataclass
class SuccessPattern:
    """成功模式"""
    category: str                              # 章节结构/角色/伏笔/战斗/感情/成本
    pattern: str                               # 模式内容
    applicable_scene: str                     # 适用场景
    example_chapter: str                       # 示例章节
    date: str                                  # 记录日期
    status: str = "pending"


@dataclass
class UpdateDraft:
    """更新草案"""
    trigger: TriggerType
    lessons: List[Lesson]
    patterns: List[SuccessPattern]
    proposed_changes: List[str]               # 建议的修改
    auto_learning_lines: List[str]            # 建议添加到auto_learning.md的内容
    generated_date: str
    status: str = "draft"                     # draft/approved/rejected


class AutoUpdateEngine:
    """自动更新迭代引擎"""

    def __init__(self, base_path: str = "."):
        self.base_path = base_path
        self.lessons_file = os.path.join(base_path, "core", "references", "lessons.md")
        self.patterns_file = os.path.join(base_path, "core", "references", "success_patterns.md")
        self.drafts_dir = os.path.join(base_path, "core", "scripts", "update_drafts")

        # 确保目录存在
        os.makedirs(os.path.dirname(self.lessons_file), exist_ok=True)
        os.makedirs(self.drafts_dir, exist_ok=True)

        # 当前累积的教训和模式
        self.lessons: List[Lesson] = []
        self.patterns: List[SuccessPattern] = []

    def trigger_analysis(self, trigger_type: TriggerType,
                        project_info: Dict = None,
                        quality_report: Dict = None) -> UpdateDraft:
        """
        触发分析，生成更新草案

        Args:
            trigger_type: 触发类型
            project_info: 项目信息（书名、题材、章节数等）
            quality_report: 质量报告（如果有）

        Returns:
            UpdateDraft: 更新草案
        """
        print(f"触发分析: {trigger_type.value}")

        # 收集教训
        lessons = self._collect_lessons(project_info, quality_report)

        # 收集成功模式
        patterns = self._collect_success_patterns(project_info)

        # 生成建议修改
        proposed_changes = self._generate_proposed_changes(lessons, patterns)

        # 生成auto_learning.md更新行
        auto_learning_lines = self._generate_auto_learning_lines(
            trigger_type, lessons, patterns, project_info
        )

        draft = UpdateDraft(
            trigger=trigger_type,
            lessons=lessons,
            patterns=patterns,
            proposed_changes=proposed_changes,
            auto_learning_lines=auto_learning_lines,
            generated_date=datetime.now().strftime("%Y-%m-%d")
        )

        # 保存草案
        self._save_draft(draft)

        return draft

    def _collect_lessons(self, project_info: Dict = None,
                        quality_report: Dict = None) -> List[Lesson]:
        """收集教训"""
        lessons = []

        # 如果有质量报告，分析问题
        if quality_report:
            if quality_report.get("regression_count", 0) > 3:
                lessons.append(Lesson(
                    category="质量控制",
                    content=f"项目{project_info.get('name', 'unknown')}发现{quality_report['regression_count']}次质量回退",
                    severity=4,
                    chapter_or_project=project_info.get("name", "unknown") if project_info else "unknown",
                    date=datetime.now().strftime("%Y-%m-%d")
                ))

            if quality_report.get("continuity_breaks", 0) > 0:
                lessons.append(Lesson(
                    category="四表管理",
                    content=f"发现{quality_report['continuity_breaks']}处连续性断裂",
                    severity=5,
                    chapter_or_project=project_info.get("name", "unknown") if project_info else "unknown",
                    date=datetime.now().strftime("%Y-%m-%d")
                ))

        return lessons

    def _collect_success_patterns(self, project_info: Dict = None) -> List[SuccessPattern]:
        """收集成功模式"""
        patterns = []

        # 如果项目完成且评分高，记录成功模式
        if project_info and project_info.get("rating", 0) >= 85:
            patterns.append(SuccessPattern(
                category="项目整体",
                pattern=f"项目{project_info['name']}获得评分{project_info['rating']}",
                applicable_scene="高难度长篇项目参考",
                example_chapter=project_info.get("name", "unknown"),
                date=datetime.now().strftime("%Y-%m-%d")
            ))

        return patterns

    def _generate_proposed_changes(self, lessons: List[Lesson],
                                    patterns: List[SuccessPattern]) -> List[str]:
        """生成建议修改"""
        changes = []

        # 分析教训，生成修改建议
        for lesson in lessons:
            if lesson.severity >= 4:
                if lesson.category == "四表管理":
                    changes.append(f"【P0级修改】强化连续性检查：{lesson.content}")
                elif lesson.category == "质量控制":
                    changes.append(f"【P1级修改】增加质量门禁：{lesson.content}")

        # 分析成功模式
        for pattern in patterns:
            if pattern.category == "章节结构":
                changes.append(f"【优化】更新章节结构模板：{pattern.pattern}")

        return changes

    def _generate_auto_learning_lines(self, trigger: TriggerType,
                                      lessons: List[Lesson],
                                      patterns: List[SuccessPattern],
                                      project_info: Dict = None) -> List[str]:
        """生成auto_learning.md更新行"""
        lines = []

        # 标题
        date = datetime.now().strftime("%Y-%m-%d")
        trigger_name = trigger.value

        lines.append(f"\n## 实时反馈 - {date} [{trigger_name}]")

        if project_info:
            lines.append(f"\n### 项目信息")
            lines.append(f"- 书名：{project_info.get('name', 'N/A')}")
            lines.append(f"- 题材：{project_info.get('genre', 'N/A')}")
            lines.append(f"- 章节数：{project_info.get('chapter_count', 'N/A')}")

        if lessons:
            lines.append(f"\n### 问题记录")
            for lesson in lessons:
                lines.append(f"- [{lesson.category}] {lesson.content} (严重度:{lesson.severity})")

        if patterns:
            lines.append(f"\n### 灵感记录")
            for pattern in patterns:
                lines.append(f"- [{pattern.category}] {pattern.pattern}")

        if lessons or patterns:
            lines.append(f"\n### 改进行动")
            lines.append(f"- 状态：待审核")
            lines.append(f"- 建议：查看 update_drafts/ 目录下的草案")

        return lines

    def _save_draft(self, draft: UpdateDraft):
        """保存草案"""
        # 生成文件名
        filename = f"draft_{draft.generated_date}_{draft.trigger.value}.md"
        filepath = os.path.join(self.drafts_dir, filename)

        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(f"# 更新草案\n\n")
            f.write(f"**生成日期**: {draft.generated_date}\n")
            f.write(f"**触发类型**: {draft.trigger.value}\n\n")

            f.write(f"## 教训 ({len(draft.lessons)}条)\n\n")
            for lesson in draft.lessons:
                f.write(f"- **{lesson.category}** [{lesson.severity}/5]: {lesson.content}\n")
                f.write(f"  - 来源: {lesson.chapter_or_project}\n\n")

            f.write(f"## 成功模式 ({len(draft.patterns)}条)\n\n")
            for pattern in draft.patterns:
                f.write(f"- **{pattern.category}**: {pattern.pattern}\n")
                f.write(f"  - 适用: {pattern.applicable_scene}\n")
                f.write(f"  - 示例: {pattern.example_chapter}\n\n")

            f.write(f"## 建议修改\n\n")
            for change in draft.proposed_changes:
                f.write(f"- {change}\n")

        print(f"草案已保存: {filepath}")

    def approve_draft(self, draft_date: str, trigger: str):
        """审核通过草案"""
        # 读取草案
        filename = f"draft_{draft_date}_{trigger}.md"
        filepath = os.path.join(self.drafts_dir, filename)

        if not os.path.exists(filepath):
            print(f"草案不存在: {filepath}")
            return False

        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()

        # 根据trigger类型决定写入目标
        # quality_issue → lessons.md（失败教训）
        # chapter_complete/book_complete → success_patterns.md（成功模式）
        if trigger in ["quality_issue", "quality_regression"]:
            target_file = "lessons.md"
        elif trigger in ["chapter_complete", "book_complete"]:
            target_file = "success_patterns.md"
        else:
            target_file = "lessons.md"  # user_request默认写入lessons

        target_path = os.path.join(self.base_path, "core", "references", target_file)

        # 格式化写入（添加分隔符和元数据）
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")
        entry = f"\n\n---\n## 草案 {draft_date} | 触发: {trigger} | {timestamp}\n\n{content}"

        with open(target_path, 'a', encoding='utf-8') as f:
            f.write(entry)

        # 标记草案为已批准
        approved_file = filepath.replace(".md", "_approved.md")
        os.rename(filepath, approved_file)

        print(f"草案已批准并写入 {target_file}: {approved_file}")
        return True

    def get_pending_drafts(self) -> List[str]:
        """获取待审核草案"""
        drafts = []
        for filename in os.listdir(self.drafts_dir):
            if filename.startswith("draft_") and not filename.endswith("_approved.md"):
                drafts.append(filename)
        return drafts


if __name__ == "__main__":
    # 测试
    engine = AutoUpdateEngine(".")

    # 模拟触发
    project_info = {
        "name": "测试小说",
        "genre": "玄幻",
        "chapter_count": 100
    }

    quality_report = {
        "regression_count": 5,
        "continuity_breaks": 2
    }

    draft = engine.trigger_analysis(
        trigger_type=TriggerType.BOOK_COMPLETE,
        project_info=project_info,
        quality_report=quality_report
    )

    print(f"\n生成的草案包含:")
    print(f"- 教训: {len(draft.lessons)}条")
    print(f"- 成功模式: {len(draft.patterns)}条")
    print(f"- 建议修改: {len(draft.proposed_changes)}条")

    # 显示待审核草案
    pending = engine.get_pending_drafts()
    print(f"\n待审核草案: {pending}")