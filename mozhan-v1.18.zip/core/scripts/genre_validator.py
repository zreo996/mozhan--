#!/usr/bin/env python3
"""
genre_validator.py — 题材兼容性校验器

输入:
  - 题材 (12 种之一)
  - 待校验文本 (大纲/章节/设定描述)
输出:
  - 红线冲突清单
  - 题材标签匹配度
  - 子类组合建议

规则来源:
  - genres/{genre}/red_lines.md (题材红线)
  - genres/{genre}/worldbuilding.md (设定要素)
  - core/references/genre_compatibility.json (组合矩阵,可选)

兼容性策略:
  - 'hard'   红线: 出现即报 P0
  - 'soft'   越界: 出现报 P1(可标记 alt-universe 豁免)
  - 'lint'   提示: 出现报 LINT
"""
from __future__ import annotations

import json
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path


# ── 题材规则(精简版,可被外部 JSON/MD 覆盖) ───────────────
GENRE_FORBIDS = {
    "wuxia": {
        "hard": ["枪", "手枪", "步枪", "导弹", "原子弹", "手机", "互联网",
                 "WiFi", "电脑", "汽车", "魔法阵", "斗气", "技能栏"],
        "soft": ["机甲", "外星", "克隆", "异世界穿越"],
        "lint": ["金手指", "系统提示音"],
    },
    "fantasy": {  # 玄幻/仙侠
        "hard": ["枪", "导弹", "手机", "互联网", "WiFi"],
        "soft": ["现代都市生活", "外星科技"],
        "lint": ["完全无修炼体系", "纯科技战胜功法"],
    },
    "urban": {
        "hard": ["飞剑", "炼气", "渡劫", "御剑飞行", "斗气化形"],
        "soft": ["天庭", "封神", "古剑仙"],
        "lint": ["修真大佬隐居都市过头","完全无现代基础设施"],
    },
    "scifi": {
        "hard": ["飞剑", "炼气", "渡劫", "斗气", "御剑", "灵根",
                 "丹田", "经脉真气"],
        "soft": ["纯神话神祇", "封神演义"],
        "lint": ["纯魔法解决科技问题"],
    },
    "historical": {
        "hard": ["手机", "电脑", "互联网", "汽车", "飞机", "电视",
                 "斗气", "炼气", "魔法"],
        "soft": ["纯虚构朝代", "现代价值观直接套用"],
        "lint": ["架空过度,与正史脱钩"],
    },
    "game": {
        "hard": [],  # 游戏题材几乎兼容所有元素
        "soft": ["完全无系统/数值/属性"],
        "lint": ["纯文学叙事缺少游戏化交互"],
    },
    "apocalypse": {
        "hard": ["盛世和平", "强力中央政府仍正常运转"],
        "soft": ["纯魔法/纯修真"],
        "lint": ["丧尸/灾难/废土完全缺席"],
    },
    "superpower": {
        "hard": ["传统修真体系", "炼气筑基"],
        "soft": ["纯科幻硬科技"],
        "lint": ["能力描述模糊无规则"],
    },
    "mystery": {
        "hard": ["主角第一章揭穿真凶", "无谜题/无推理"],
        "soft": ["纯超自然解释凶案"],
        "lint": ["关键线索全在最后一章空降"],
    },
    "romance": {
        "hard": [],
        "soft": ["完全无情感线"],
        "lint": ["双方主角第一章不见面"],
    },
    "fanfiction": {
        "hard": ["完全脱离原作世界观与人设"],
        "soft": ["原作核心人物 OOC 严重"],
        "lint": ["背景与原作差异未做说明"],
    },
    "isekai": {
        "hard": [],
        "soft": ["纯本世界叙事(没穿越/重生/转生)"],
        "lint": ["穿越契机过于潦草"],
    },
}

# 推荐子类组合(可选)
COMBO_HINTS = {
    "wuxia": ["+谍战", "+悬疑", "+权谋", "+轻仙侠"],
    "fantasy": ["+种田", "+无敌流", "+轻松日常"],
    "urban": ["+娱乐圈", "+商战", "+轻修真", "+战神回归"],
    "scifi": ["+末日", "+赛博朋克", "+太空歌剧"],
    "historical": ["+种田", "+权谋", "+谍战", "+悬疑"],
    "game": ["+无限流", "+VR", "+全息"],
    "apocalypse": ["+末世+异能", "+丧尸+收容所"],
    "superpower": ["+异能学院", "+特工"],
    "mystery": ["+本格", "+社会派", "+变格"],
    "romance": ["+甜宠", "+先婚后爱", "+破镜重圆"],
    "fanfiction": ["+守原", "+脑洞"],
    "isekai": ["+无敌流", "+种田", "+恶役大小姐"],
}


@dataclass
class GenreIssue:
    level: str            # P0 / P1 / LINT
    rule: str             # hard / soft / lint
    keyword: str
    snippet: str
    suggestion: str = ""

    def to_dict(self):
        return {
            "level": self.level,
            "rule": self.rule,
            "keyword": self.keyword,
            "snippet": self.snippet,
            "suggestion": self.suggestion,
        }


@dataclass
class GenreValidationResult:
    genre: str
    passed: bool
    issues: list[GenreIssue] = field(default_factory=list)
    combo_hints: list[str] = field(default_factory=list)

    def to_dict(self):
        return {
            "genre": self.genre,
            "passed": self.passed,
            "issues": [i.to_dict() for i in self.issues],
            "combo_hints": self.combo_hints,
        }


class GenreValidator:
    """题材兼容性校验器"""

    LEVEL_MAP = {"hard": "P0", "soft": "P1", "lint": "LINT"}

    def __init__(self, genre: str, skill_dir: str | Path | None = None):
        self.genre = genre.lower().strip()
        self.skill_dir = Path(skill_dir) if skill_dir else None
        self.rules = self._load_rules()
        self.combos = COMBO_HINTS.get(self.genre, [])

    def _load_rules(self) -> dict[str, list[str]]:
        """合并内置规则 + 外部 red_lines.md(如存在)"""
        rules = {
            "hard": list(GENRE_FORBIDS.get(self.genre, {}).get("hard", [])),
            "soft": list(GENRE_FORBIDS.get(self.genre, {}).get("soft", [])),
            "lint": list(GENRE_FORBIDS.get(self.genre, {}).get("lint", [])),
        }
        if self.skill_dir:
            ext = self.skill_dir / "genres" / self.genre / "red_lines.md"
            if ext.exists():
                self._merge_md_rules(rules, ext.read_text(encoding="utf-8"))
        return rules

    @staticmethod
    def _merge_md_rules(rules: dict, md: str):
        """从 red_lines.md 解析:
          ## 硬红线  下列项加入 hard
          ## 软红线  下列项加入 soft
          ## 提示    下列项加入 lint
        """
        current = None
        for line in md.splitlines():
            line = line.strip()
            if line.startswith("##"):
                low = line.lower()
                if "硬" in line or "hard" in low or "p0" in low:
                    current = "hard"
                elif "软" in line or "soft" in low or "p1" in low:
                    current = "soft"
                elif "提示" in line or "lint" in low:
                    current = "lint"
                else:
                    current = None
            elif line.startswith(("-", "*", "•")) and current:
                token = line.lstrip("-*• ").split("(")[0].split("(")[0].strip()
                if token and token not in rules[current]:
                    rules[current].append(token)

    def validate(self, text: str) -> GenreValidationResult:
        issues: list[GenreIssue] = []
        for rule_type in ("hard", "soft", "lint"):
            for kw in self.rules[rule_type]:
                if not kw:
                    continue
                for m in re.finditer(re.escape(kw), text):
                    start = max(0, m.start() - 12)
                    end = min(len(text), m.end() + 12)
                    snippet = text[start:end].replace("\n", " ")
                    issues.append(GenreIssue(
                        level=self.LEVEL_MAP[rule_type],
                        rule=rule_type,
                        keyword=kw,
                        snippet=f"...{snippet}...",
                        suggestion=self._suggest(rule_type, kw),
                    ))
                    break  # 同关键词只报第一次

        passed = not any(i.level == "P0" for i in issues)
        return GenreValidationResult(
            genre=self.genre, passed=passed,
            issues=issues, combo_hints=self.combos,
        )

    def _suggest(self, rule_type: str, kw: str) -> str:
        if rule_type == "hard":
            return f"违反 {self.genre} 题材硬红线,删除或替换 '{kw}'"
        if rule_type == "soft":
            return f"出现 '{kw}' 可能让读者跳出 {self.genre} 题材预期"
        return f"风格提示: '{kw}' 在 {self.genre} 中需克制使用"


def validate_outline_data(outline_path: str | Path, genre: str,
                          skill_dir: str | Path | None = None) -> dict:
    """大纲 JSON 整体校验:扫描所有 chapter outline 字段"""
    data = json.loads(Path(outline_path).read_text(encoding="utf-8"))
    text = "\n".join(
        c.get("outline", "") for c in data.get("chapters", [])
    )
    validator = GenreValidator(genre, skill_dir=skill_dir)
    return validator.validate(text).to_dict()


def main():
    if len(sys.argv) < 3:
        print("用法: python genre_validator.py <genre> <text_file> [--skill-dir DIR] [--json]")
        print(f"  genre 选项: {', '.join(sorted(GENRE_FORBIDS.keys()))}")
        sys.exit(1)

    genre = sys.argv[1]
    text_file = sys.argv[2]
    skill_dir = None
    if "--skill-dir" in sys.argv:
        skill_dir = sys.argv[sys.argv.index("--skill-dir") + 1]
    as_json = "--json" in sys.argv

    text = Path(text_file).read_text(encoding="utf-8")
    validator = GenreValidator(genre, skill_dir=skill_dir)
    result = validator.validate(text)

    if as_json:
        print(json.dumps(result.to_dict(), ensure_ascii=False, indent=2))
    else:
        print(f"题材: {result.genre}")
        print(f"通过: {result.passed}")
        for i in result.issues:
            print(f"  [{i.level}] {i.keyword}: {i.snippet}")
            print(f"        → {i.suggestion}")
        if result.combo_hints:
            print(f"组合建议: {', '.join(result.combo_hints)}")

    sys.exit(0 if result.passed else 1)


if __name__ == "__main__":
    main()
