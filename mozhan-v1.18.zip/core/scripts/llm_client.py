"""
llm_client.py — Anthropic SDK 封装,内置 Prompt Caching/批量/并行

设计目标:
1. 冻结前缀(world + 四表快照)作为缓存区
2. 单次/批量/并行三种调用模式
3. 默认模型 claude-sonnet-4-6,可按 L1/L2/L3/L4 自动路由
4. 透出 cache 命中指标到 cost_log

依赖: pip install anthropic
环境: ANTHROPIC_API_KEY
"""
from __future__ import annotations

import json
import os
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable

try:
    import anthropic
except ImportError:  # pragma: no cover
    anthropic = None


# ── 模型路由 ──────────────────────────────────────────────
MODEL_ROUTING = {
    "L1": "claude-haiku-4-5",        # 常规章 — 廉价
    "L2": "claude-sonnet-4-6",       # 关键章 — 默认
    "L3": "claude-sonnet-4-6",       # 核心章
    "L4": "claude-opus-4-7",         # 宏篇章 — 最强
}
DEFAULT_MODEL = "claude-sonnet-4-6"

# 价格 (per 1M tokens, 用于 cost_log)
PRICING = {
    "claude-opus-4-7":   {"in": 5.00, "out": 25.00, "cache_read": 0.50, "cache_write": 6.25},
    "claude-opus-4-6":   {"in": 5.00, "out": 25.00, "cache_read": 0.50, "cache_write": 6.25},
    "claude-sonnet-4-6": {"in": 3.00, "out": 15.00, "cache_read": 0.30, "cache_write": 3.75},
    "claude-haiku-4-5":  {"in": 1.00, "out":  5.00, "cache_read": 0.10, "cache_write": 1.25},
}


@dataclass
class FrozenContext:
    """冻结前缀 — 命中缓存的不可变部分"""
    worldview: str = ""           # 世界观/题材规则
    style_fingerprint: str = ""   # 文风印记(从 masterpiece_analysis 抽取)
    timeline: dict = field(default_factory=dict)
    characters: dict = field(default_factory=dict)
    hooks: dict = field(default_factory=dict)
    inventory: dict = field(default_factory=dict)
    extra: str = ""               # 额外固定上下文

    def to_system_blocks(self) -> list[dict]:
        """生成带 cache_control 的 system blocks。

        策略:
          - block1 (worldview + style_fingerprint): 几乎不变,加 cache_control
          - block2 (四表快照): 每章微变,但前 1024 tokens 通常稳定
            → 也加 cache_control,SDK 会按前缀匹配
        """
        blocks: list[dict] = []
        frozen_head = (self.worldview + "\n\n" + self.style_fingerprint).strip()
        if frozen_head:
            blocks.append({
                "type": "text",
                "text": frozen_head,
                "cache_control": {"type": "ephemeral"},
            })
        if self.extra:
            blocks.append({
                "type": "text",
                "text": self.extra,
                "cache_control": {"type": "ephemeral"},
            })
        snapshot = self._serialize_tables()
        if snapshot:
            blocks.append({
                "type": "text",
                "text": snapshot,
                "cache_control": {"type": "ephemeral"},
            })
        return blocks

    def _serialize_tables(self) -> str:
        parts = []
        if self.timeline:
            parts.append("== TIMELINE ==\n" + json.dumps(
                self.timeline, ensure_ascii=False, sort_keys=True, indent=2))
        if self.characters:
            parts.append("== CHARACTERS ==\n" + json.dumps(
                self.characters, ensure_ascii=False, sort_keys=True, indent=2))
        if self.hooks:
            parts.append("== HOOKS ==\n" + json.dumps(
                self.hooks, ensure_ascii=False, sort_keys=True, indent=2))
        if self.inventory:
            parts.append("== INVENTORY ==\n" + json.dumps(
                self.inventory, ensure_ascii=False, sort_keys=True, indent=2))
        return "\n\n".join(parts)


@dataclass
class CallResult:
    """单次调用结果 + 计量信息"""
    text: str
    model: str
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0
    cache_creation_tokens: int = 0
    stop_reason: str = ""
    raw: Any = None

    @property
    def cost_usd(self) -> float:
        p = PRICING.get(self.model)
        if not p:
            return 0.0
        return (
            self.input_tokens         * p["in"]          / 1_000_000
            + self.output_tokens      * p["out"]         / 1_000_000
            + self.cache_read_tokens  * p["cache_read"]  / 1_000_000
            + self.cache_creation_tokens * p["cache_write"] / 1_000_000
        )


class LLMClient:
    """Anthropic Messages 封装"""

    def __init__(
        self,
        api_key: str | None = None,
        default_model: str = DEFAULT_MODEL,
        cost_log_path: str | Path | None = None,
        max_workers: int = 4,
    ):
        if anthropic is None:
            raise RuntimeError("anthropic 未安装,执行: pip install anthropic")
        self.client = anthropic.Anthropic(api_key=api_key or os.getenv("ANTHROPIC_API_KEY"))
        self.default_model = default_model
        self.max_workers = max_workers
        self.cost_log_path = Path(cost_log_path) if cost_log_path else None
        if self.cost_log_path:
            self.cost_log_path.parent.mkdir(parents=True, exist_ok=True)

    # ── 单次调用 ─────────────────────────────────────────
    def call(
        self,
        prompt: str,
        *,
        frozen: FrozenContext | None = None,
        model: str | None = None,
        level: str | None = None,
        max_tokens: int = 8000,
        thinking: bool = True,
        extra_system: str = "",
        history: list[dict] | None = None,
        tag: str = "",
    ) -> CallResult:
        chosen_model = self._pick_model(model, level)
        system_blocks: list[dict] = []
        if frozen:
            system_blocks.extend(frozen.to_system_blocks())
        if extra_system:
            system_blocks.append({"type": "text", "text": extra_system})

        messages = list(history or [])
        messages.append({"role": "user", "content": prompt})

        kwargs: dict[str, Any] = {
            "model": chosen_model,
            "max_tokens": max_tokens,
            "system": system_blocks if system_blocks else extra_system,
            "messages": messages,
        }
        if thinking:
            kwargs["thinking"] = {"type": "adaptive"}

        resp = self.client.messages.create(**kwargs)
        result = self._wrap_response(resp, chosen_model)
        self._log_cost(result, tag=tag)
        return result

    # ── 流式调用 (长输出场景) ─────────────────────────────
    def stream(
        self,
        prompt: str,
        *,
        frozen: FrozenContext | None = None,
        model: str | None = None,
        level: str | None = None,
        max_tokens: int = 8000,
        thinking: bool = True,
        extra_system: str = "",
        history: list[dict] | None = None,
        tag: str = "",
    ) -> CallResult:
        chosen_model = self._pick_model(model, level)
        system_blocks: list[dict] = []
        if frozen:
            system_blocks.extend(frozen.to_system_blocks())
        if extra_system:
            system_blocks.append({"type": "text", "text": extra_system})

        messages = list(history or [])
        messages.append({"role": "user", "content": prompt})

        kwargs: dict[str, Any] = {
            "model": chosen_model,
            "max_tokens": max_tokens,
            "system": system_blocks if system_blocks else extra_system,
            "messages": messages,
        }
        if thinking:
            kwargs["thinking"] = {"type": "adaptive"}

        with self.client.messages.stream(**kwargs) as stream:
            final = stream.get_final_message()
        result = self._wrap_response(final, chosen_model)
        self._log_cost(result, tag=tag)
        return result

    # ── 并行调用 (多agent / 多备选) ───────────────────────
    def parallel(
        self,
        prompts: Iterable[dict],
    ) -> list[CallResult]:
        """
        prompts 元素结构: {
            "prompt": str,
            "frozen": FrozenContext | None,
            "model": str | None,
            "level": str | None,
            "max_tokens": int,
            "thinking": bool,
            "tag": str,
            ...其它 call() 接受的参数
        }
        """
        prompts_list = list(prompts)
        results: list[CallResult | None] = [None] * len(prompts_list)
        with ThreadPoolExecutor(max_workers=self.max_workers) as pool:
            future_idx = {
                pool.submit(self.call, **p): i
                for i, p in enumerate(prompts_list)
            }
            for fut in as_completed(future_idx):
                i = future_idx[fut]
                try:
                    results[i] = fut.result()
                except Exception as e:
                    results[i] = CallResult(
                        text=f"[ERROR] {e}",
                        model=prompts_list[i].get("model") or self.default_model,
                    )
        return [r for r in results if r is not None]

    # ── 批量调用 (官方 Batch API,折扣 50%) ─────────────
    def batch(
        self,
        tasks: list[dict],
        wait: bool = True,
        poll_interval: float = 15.0,
        timeout_sec: float = 60 * 60,
    ) -> Any:
        """tasks 同 parallel() 输入格式,但走 batches.create()。
        返回 batch 对象;如果 wait=True,等待完成后返回结果列表。
        """
        requests = []
        for i, t in enumerate(tasks):
            frozen = t.get("frozen")
            extra = t.get("extra_system", "")
            sys_blocks: list[dict] = []
            if frozen:
                sys_blocks.extend(frozen.to_system_blocks())
            if extra:
                sys_blocks.append({"type": "text", "text": extra})
            params = {
                "model": self._pick_model(t.get("model"), t.get("level")),
                "max_tokens": t.get("max_tokens", 8000),
                "system": sys_blocks if sys_blocks else extra,
                "messages": [{"role": "user", "content": t["prompt"]}],
            }
            if t.get("thinking", True):
                params["thinking"] = {"type": "adaptive"}
            requests.append({
                "custom_id": t.get("custom_id", f"task-{i}"),
                "params": params,
            })

        batch = self.client.messages.batches.create(requests=requests)
        if not wait:
            return batch

        deadline = time.time() + timeout_sec
        while time.time() < deadline:
            batch = self.client.messages.batches.retrieve(batch.id)
            if batch.processing_status == "ended":
                break
            time.sleep(poll_interval)
        else:
            raise TimeoutError(f"batch {batch.id} 超时")

        out: list[CallResult] = []
        for entry in self.client.messages.batches.results(batch.id):
            res = entry.result
            if res.type != "succeeded":
                out.append(CallResult(
                    text=f"[BATCH-ERR] {res.type}",
                    model=self.default_model,
                ))
                continue
            msg = res.message
            out.append(self._wrap_response(msg, msg.model))
        return out

    # ── 多 Agent 协同入口 ─────────────────────────────────
    def multi_agent_consult(
        self,
        agent_prompts: list[dict],
        frozen: FrozenContext | None = None,
        level: str = "L2",
    ) -> dict[str, CallResult]:
        """agent_prompts: [{role: "scene"|"dialogue"|..., prompt: str}, ...]
        共享同一 frozen 前缀(走缓存),并行咨询多个专家。
        """
        tasks = []
        for ap in agent_prompts:
            tasks.append({
                "prompt": ap["prompt"],
                "frozen": frozen,
                "level": level,
                "tag": f"agent:{ap['role']}",
                "max_tokens": ap.get("max_tokens", 4000),
                "thinking": ap.get("thinking", True),
            })
        results = self.parallel(tasks)
        return {ap["role"]: r for ap, r in zip(agent_prompts, results)}

    # ── 内部工具 ──────────────────────────────────────────
    def _pick_model(self, model: str | None, level: str | None) -> str:
        if model:
            return model
        if level and level in MODEL_ROUTING:
            return MODEL_ROUTING[level]
        return self.default_model

    def _wrap_response(self, resp: Any, model: str) -> CallResult:
        text_parts = []
        for blk in getattr(resp, "content", []):
            t = getattr(blk, "type", None)
            if t == "text":
                text_parts.append(getattr(blk, "text", ""))
        usage = getattr(resp, "usage", None)
        return CallResult(
            text="".join(text_parts),
            model=model,
            input_tokens=getattr(usage, "input_tokens", 0) if usage else 0,
            output_tokens=getattr(usage, "output_tokens", 0) if usage else 0,
            cache_read_tokens=getattr(usage, "cache_read_input_tokens", 0) if usage else 0,
            cache_creation_tokens=getattr(usage, "cache_creation_input_tokens", 0) if usage else 0,
            stop_reason=getattr(resp, "stop_reason", "") or "",
            raw=resp,
        )

    def _log_cost(self, result: CallResult, tag: str = "") -> None:
        if not self.cost_log_path:
            return
        entry = {
            "ts": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "tag": tag,
            "model": result.model,
            "input_tokens": result.input_tokens,
            "output_tokens": result.output_tokens,
            "cache_read_tokens": result.cache_read_tokens,
            "cache_creation_tokens": result.cache_creation_tokens,
            "cost_usd": round(result.cost_usd, 6),
        }
        log = []
        if self.cost_log_path.exists():
            try:
                log = json.loads(self.cost_log_path.read_text(encoding="utf-8"))
                if not isinstance(log, list):
                    log = []
            except Exception:
                log = []
        log.append(entry)
        self.cost_log_path.write_text(
            json.dumps(log, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )


# ── 便捷工厂 ──────────────────────────────────────────────
def load_frozen_from_data(
    data_dir: str | Path,
    worldview_text: str = "",
    genre: str | None = None,
    skill_dir: str | Path | None = None,
) -> FrozenContext:
    """从 data/ 目录读取四表 + (可选) 文风印记生成 FrozenContext。

    文风印记加载优先级:
      1. data/style_fingerprint.json (项目已固化,O(0) 读取)
      2. genre + skill_dir (动态解析 masterpiece_analysis.md)
      3. 留空 (向后兼容)
    """
    data_dir = Path(data_dir)
    def _read(name: str) -> dict:
        p = data_dir / name
        if not p.exists():
            return {}
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            return {}

    style_fingerprint = ""
    fp_path = data_dir / "style_fingerprint.json"
    if fp_path.exists():
        try:
            fp_data = json.loads(fp_path.read_text(encoding="utf-8"))
            style_fingerprint = fp_data.get("text") or fp_data.get("content") or ""
        except Exception:
            style_fingerprint = ""
    if not style_fingerprint and genre:
        try:
            from genre_style import render_style_fingerprint
            root = Path(skill_dir) if skill_dir else Path(data_dir).parent.parent
            style_fingerprint = render_style_fingerprint(genre, root)
        except Exception:
            style_fingerprint = ""

    return FrozenContext(
        worldview=worldview_text,
        style_fingerprint=style_fingerprint,
        timeline=_read("timeline.json"),
        characters=_read("characters_snapshot.json"),
        hooks=_read("hooks.json"),
        inventory=_read("inventory.json"),
    )


if __name__ == "__main__":  # pragma: no cover
    import argparse

    ap = argparse.ArgumentParser(description="LLM client 自检")
    ap.add_argument("--ping", action="store_true", help="发一条最小请求验证 API key")
    ap.add_argument("--model", default=DEFAULT_MODEL)
    args = ap.parse_args()

    if args.ping:
        c = LLMClient()
        r = c.call("回复:pong。", model=args.model, max_tokens=64, thinking=False)
        print(f"model={r.model} text={r.text!r} "
              f"in={r.input_tokens} out={r.output_tokens} "
              f"cache_r={r.cache_read_tokens} cost=${r.cost_usd:.6f}")
