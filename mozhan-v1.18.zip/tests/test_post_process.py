"""
test_post_process.py — 写后处理脚本的时段词典与四表回填测试
"""
from __future__ import annotations

import json

import pytest

from post_process import (
    PostProcessor,
    PERIOD_MAP,
    extract_day_period,
    extract_all_periods,
)


def test_period_map_includes_all_systems():
    # 现代/古代描述/12时辰/工作日 都要有代表项
    assert "黄昏" in PERIOD_MAP
    assert "黎明" in PERIOD_MAP
    assert "子时" in PERIOD_MAP
    assert "早高峰" in PERIOD_MAP


def test_extract_day_period_basic():
    day, period = extract_day_period("第三天黄昏,他踏入江湖。")
    assert day == 3
    assert period == "黄昏"


def test_extract_all_periods_order():
    text = "黎明出门,正午吃饭,黄昏归来。"
    periods = extract_all_periods(text)
    # 应保留出现顺序
    assert periods[0] == "黎明"
    assert "正午" in periods
    assert "黄昏" in periods


def test_post_processor_writes_tables(demo_data, demo_chapter):
    """跑一遍 process 后,四表都应被更新"""
    pp = PostProcessor(demo_data, chapter_num=2)
    pp.process(str(demo_chapter))

    tl = json.loads((demo_data / "timeline.json").read_text(encoding="utf-8"))
    # 至少新增了一条 main 事件
    assert any(e.get("chapter") == 2 for e in tl["storylines"]["main"])
