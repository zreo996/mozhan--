"""
test_llm_client.py — LLMClient 单元测试(不调用真实 API)

只测试:
  - FrozenContext 序列化与 cache_control 注入
  - CallResult 价格计算
  - load_frozen_from_data 读取四表
"""
from __future__ import annotations

import json

import pytest

from llm_client import (
    CallResult,
    FrozenContext,
    MODEL_ROUTING,
    PRICING,
    load_frozen_from_data,
)


def test_frozen_context_emits_cache_control():
    fc = FrozenContext(worldview="武侠世界,内力为本。",
                       timeline={"global_day": 1},
                       characters={"characters": []})
    blocks = fc.to_system_blocks()
    assert blocks, "至少一个 block"
    assert all(b.get("cache_control", {}).get("type") == "ephemeral" for b in blocks)
    assert all(b["type"] == "text" for b in blocks)


def test_frozen_context_empty_no_block():
    fc = FrozenContext()
    assert fc.to_system_blocks() == []


def test_call_result_cost_calculation():
    r = CallResult(
        text="ok",
        model="claude-sonnet-4-6",
        input_tokens=1_000_000,
        output_tokens=500_000,
    )
    p = PRICING["claude-sonnet-4-6"]
    expected = 1.0 * p["in"] + 0.5 * p["out"]
    assert abs(r.cost_usd - expected) < 0.001


def test_call_result_cache_discount():
    r = CallResult(
        text="ok",
        model="claude-sonnet-4-6",
        input_tokens=1000,
        output_tokens=500,
        cache_read_tokens=900_000,
    )
    # 缓存读取应比常规输入便宜
    assert r.cost_usd > 0
    p = PRICING["claude-sonnet-4-6"]
    cached_cost = 0.9 * p["cache_read"]
    assert r.cost_usd >= cached_cost / 1_000_000 * 1_000_000  # 数量级正确


def test_model_routing_levels():
    # L4 应路由到最强模型
    assert MODEL_ROUTING["L4"] == "claude-opus-4-7"
    assert MODEL_ROUTING["L1"] == "claude-haiku-4-5"
    assert MODEL_ROUTING["L2"] == "claude-sonnet-4-6"


def test_load_frozen_from_data(demo_data):
    fc = load_frozen_from_data(demo_data, worldview_text="武侠世界")
    assert fc.worldview == "武侠世界"
    assert fc.timeline.get("global_day") == 3
    assert any(c["name"] == "李无心"
               for c in fc.characters.get("characters", []))


def test_pricing_all_supported_models():
    for model in MODEL_ROUTING.values():
        assert model in PRICING, f"{model} 缺定价"
