"""
test_genre_validator.py — 题材兼容性 validator 单元测试
"""
from __future__ import annotations

import pytest

from genre_validator import GenreValidator


def test_wuxia_blocks_phone():
    v = GenreValidator("wuxia")
    r = v.validate("少年提剑入江湖,忽然掏出手机。")
    assert not r.passed
    p0 = [i for i in r.issues if i.level == "P0"]
    assert p0, "武侠题材出现手机应触发 P0"
    assert any("手机" in i.keyword for i in p0)


def test_pure_wuxia_passes():
    v = GenreValidator("wuxia")
    r = v.validate("少年踏雪而行,目光如电,提剑向断魂崖走去。")
    assert r.passed
    assert all(i.level != "P0" for i in r.issues)


def test_urban_blocks_flying_sword():
    v = GenreValidator("urban")
    r = v.validate("总裁御剑飞行赶往机场。")
    assert not r.passed


def test_scifi_blocks_qi_cultivation():
    v = GenreValidator("scifi")
    r = v.validate("舰长打开丹田,炼气化神。")
    assert not r.passed


def test_combo_hints_present():
    v = GenreValidator("wuxia")
    r = v.validate("正常武侠文本。")
    assert r.combo_hints, "应给出组合建议"


def test_external_red_lines_loaded(skill_root):
    """skill_dir 应载入 genres/wuxia/red_lines.md 中的额外规则"""
    v = GenreValidator("wuxia", skill_dir=skill_root)
    # 内置 + 外部合并后规则数应 ≥ 内置
    builtin = GenreValidator("wuxia")
    assert len(v.rules["hard"]) >= len(builtin.rules["hard"])
