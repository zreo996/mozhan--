"""
test_quality_score.py — 章节评分基本功能测试
"""
from __future__ import annotations

import pytest

from quality_score import QualityScorer


def test_baseline_score_reasonable(demo_data, demo_chapter):
    text = demo_chapter.read_text(encoding="utf-8")
    scorer = QualityScorer(chapter_num=1)
    result = scorer.assess(text, data_dir=str(demo_data))
    assert "final_score" in result
    assert 0 <= result["final_score"] <= 100
    assert "grade" in result


def test_grade_thresholds():
    scorer = QualityScorer(chapter_num=1)
    assert scorer.get_grade(0) == "不及格"
    assert scorer.get_grade(50) == "较差"
    assert scorer.get_grade(70) == "合格"
    assert scorer.get_grade(85) == "良好"
    assert scorer.get_grade(95) == "优秀"
