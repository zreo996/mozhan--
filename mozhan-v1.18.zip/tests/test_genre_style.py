"""
test_genre_style.py — 文风印记自动加载器单元测试
"""
from __future__ import annotations

import json

import pytest

from genre_style import (
    GenreStyleLoader,
    StyleFingerprint,
    list_supported_genres,
    load_style_fingerprint,
    render_style_fingerprint,
)


# ── 基础 ──────────────────────────────────────────────
def test_supported_genres_at_least_12(skill_root):
    gs = list_supported_genres(skill_root)
    assert len(gs) >= 12
    for g in ("wuxia", "fantasy", "urban", "scifi", "historical",
              "game", "apocalypse", "superpower", "mystery",
              "romance", "fanfiction", "isekai"):
        assert g in gs


# ── 文风印记生成质量 ──────────────────────────────────
@pytest.mark.parametrize("genre", [
    "wuxia", "fantasy", "urban", "scifi", "historical",
    "game", "apocalypse", "superpower", "mystery",
    "romance", "fanfiction", "isekai",
])
def test_fingerprint_within_budget(skill_root, genre):
    fp = load_style_fingerprint(genre, skill_root)
    assert fp.genre == genre
    assert 2 <= len(fp.source_books) <= 8, \
        f"{genre} 解析到 {len(fp.source_books)} 本书"
    assert len(fp.key_techniques) >= 3
    # 1.5 字符/token 粗估
    assert fp.estimated_tokens <= 1200, \
        f"{genre} 印记 {fp.estimated_tokens} tokens 超预算"
    rendered = fp.render()
    assert f"文风印记: {genre}" in rendered
    assert f"参考" in rendered
    assert "关键写作技巧" in rendered


def test_wuxia_includes_known_books(skill_root):
    fp = load_style_fingerprint("wuxia", skill_root)
    book_titles = " ".join(fp.source_books)
    assert "雪中悍刀行" in book_titles
    assert "死人经" in book_titles


def test_fantasy_includes_known_books(skill_root):
    fp = load_style_fingerprint("fantasy", skill_root)
    book_titles = " ".join(fp.source_books)
    assert "斗破苍穹" in book_titles


# ── 渲染与缓存格式 ────────────────────────────────────
def test_render_returns_string(skill_root):
    s = render_style_fingerprint("wuxia", skill_root)
    assert isinstance(s, str)
    assert len(s) > 200


def test_loader_caches_results(skill_root):
    loader = GenreStyleLoader(skill_root)
    a = loader.load("wuxia")
    b = loader.load("wuxia")
    assert a is b, "应走缓存"

    c = loader.load("wuxia", force_reload=True)
    assert c is not a
    assert c.estimated_tokens == a.estimated_tokens


def test_unknown_genre_returns_empty(skill_root):
    fp = load_style_fingerprint("未知题材XYZ", skill_root)
    assert fp.source_books == []
    assert fp.key_techniques == []


# ── FrozenContext 集成 ─────────────────────────────────
def test_frozen_context_includes_style(skill_root, demo_data):
    from llm_client import load_frozen_from_data
    fc = load_frozen_from_data(
        demo_data, worldview_text="武侠世界",
        genre="wuxia", skill_dir=skill_root,
    )
    assert fc.worldview == "武侠世界"
    assert "文风印记" in fc.style_fingerprint
    assert "雪中悍刀行" in fc.style_fingerprint

    blocks = fc.to_system_blocks()
    assert any("文风印记" in b.get("text", "") for b in blocks)
    # 所有非空 block 都应有 cache_control
    assert all("cache_control" in b for b in blocks)


def test_frozen_context_prefers_persisted_fingerprint(skill_root, tmp_path):
    from llm_client import load_frozen_from_data
    data = tmp_path / "demo"
    data.mkdir()
    (data / "style_fingerprint.json").write_text(
        json.dumps({"text": "CUSTOM_FP_FROM_PROJECT"}, ensure_ascii=False),
        encoding="utf-8",
    )
    fc = load_frozen_from_data(data, genre="wuxia", skill_dir=skill_root)
    assert fc.style_fingerprint == "CUSTOM_FP_FROM_PROJECT"


def test_frozen_context_falls_back_when_no_genre(skill_root, tmp_path):
    from llm_client import load_frozen_from_data
    # 不传 genre,空 data 目录 → 印记应为空
    fc = load_frozen_from_data(tmp_path, worldview_text="X")
    assert fc.style_fingerprint == ""


# ── 兼容性:超长/超载保护 ─────────────────────────────
def test_fingerprint_within_token_budget_all(skill_root):
    loader = GenreStyleLoader(skill_root)
    for g in list_supported_genres(skill_root):
        fp = loader.load(g)
        assert fp.estimated_tokens <= 1200, \
            f"{g} 印记 {fp.estimated_tokens} tokens 超 1200 预算"
