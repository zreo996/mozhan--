"""
tests/conftest.py — pytest 共享 fixture

提供 demo_wuxia 数据目录的临时副本,所有测试在隔离副本内修改,避免污染示例。
"""
from __future__ import annotations

import shutil
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "core" / "scripts"))


@pytest.fixture
def demo_dir(tmp_path) -> Path:
    """返回 demo_wuxia 的临时副本路径"""
    src = ROOT / "examples" / "demo_wuxia"
    dst = tmp_path / "demo_wuxia"
    shutil.copytree(src, dst)
    return dst


@pytest.fixture
def demo_data(demo_dir) -> Path:
    return demo_dir / "data"


@pytest.fixture
def demo_chapter(demo_dir) -> Path:
    return demo_dir / "chapters" / "chapter_001.txt"


@pytest.fixture
def skill_root() -> Path:
    return ROOT
