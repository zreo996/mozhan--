"""
test_climax_tracker.py — 爽点密度追踪器单元测试
"""
from __future__ import annotations

from pathlib import Path

import pytest

from climax_tracker import ClimaxTracker


def test_scan_chapter_counts_climaxes():
    tracker = ClimaxTracker(".")
    text = "反派被一招瞬杀,瞠目结舌。主角觉醒后扬眉吐气。"
    c = tracker.scan_chapter(text, 1)
    assert c.total >= 3
    assert "slap" in c.counts or "power" in c.counts


def test_empty_chapter_zero_climax():
    tracker = ClimaxTracker(".")
    c = tracker.scan_chapter("一段平淡的描写,没有起伏。", 1)
    assert c.total == 0


def test_density_sparse_status(tmp_path):
    # 写 10 章基本无爽点
    chap_dir = tmp_path / "ch"
    chap_dir.mkdir()
    for i in range(1, 11):
        (chap_dir / f"chapter_{i:03d}.txt").write_text(
            "平淡日常,一切如常。", encoding="utf-8")
    tracker = ClimaxTracker(chap_dir)
    report = tracker.report()
    assert report.total_chapters == 10
    assert report.status == "sparse"
    assert report.deficit > 0


def test_density_ok_status(tmp_path):
    chap_dir = tmp_path / "ch"
    chap_dir.mkdir()
    # 10 章,每 5 章 1 个爽点 → ~20/100ch (在 18-25 之间)
    for i in range(1, 11):
        if i % 5 == 0:
            (chap_dir / f"chapter_{i:03d}.txt").write_text(
                "反派瞠目结舌,主角扬眉吐气。", encoding="utf-8")
        else:
            (chap_dir / f"chapter_{i:03d}.txt").write_text(
                "日常推进。", encoding="utf-8")
    tracker = ClimaxTracker(chap_dir, target_min=18, target_max=80)
    report = tracker.report()
    assert report.status == "ok", f"密度={report.per_100ch}/100ch status={report.status}"
    assert report.per_100ch >= 18


def test_dry_streak_detection(tmp_path):
    chap_dir = tmp_path / "ch"
    chap_dir.mkdir()
    # 6 章干涸 + 1 章有爽点
    for i in range(1, 7):
        (chap_dir / f"chapter_{i:03d}.txt").write_text(
            "平淡日常。", encoding="utf-8")
    (chap_dir / "chapter_007.txt").write_text(
        "反派瞠目结舌!", encoding="utf-8")
    tracker = ClimaxTracker(chap_dir)
    report = tracker.report()
    assert report.dry_streak, "应检测到连续干涸段"
    assert report.dry_streak[0] == (1, 6)
