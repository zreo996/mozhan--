# 贡献指南

欢迎来到 **墨栈 (MoZhan)** —— 这里是中文长篇网文创作的 Skill 工具箱。
本项目的所有改进(代码、文档、题材档案、prompt 模板、文风分析)都欢迎以 PR 形式贡献。

## 行为准则

- 友善、专业、就事论事
- 批评必须附上具体代码、文档、复现步骤
- 禁止任何人身攻击

## 提 Issue 之前

1. 先看 [README.md](README.md) 的「常见问题」
2. 在 [issues](../../issues) 里搜一下是否已有同类问题
3. 提供最小复现:
   - 运行环境(OS / Python 版本)
   - 触发命令或 UI 操作
   - 完整错误堆栈或截图
   - 预期行为与实际行为的差异

## 提 PR 之前

1. fork 主仓到你的 GitHub 账号
2. 在你的 fork 创建新分支:`git checkout -b feature/your-feature`
3. 保持单 PR 单一改动,避免无关 cleanup
4. 跑通本地验证:

   ```bash
   # 装依赖
   pip install -r requirements.txt

   # 跑全部测试(应 49 个全过)
   pytest tests/ -v

   # 启动 UI 跑通端到端
   python -m ui --port 8765
   ```

5. 在 PR 描述里写明:
   - **Why** — 为什么改
   - **What** — 改了什么
   - **Test plan** — 你如何验证
   - **Risk** — 可能的兼容性影响

## 提交主题材档案(新题材!)

每个题材需要三件套:

```
genres/<your_genre>/
├── worldbuilding.md       # 世界规则/修炼体系/社会结构
├── masterpiece_analysis.md # 4-5 本精品文风分析(文字描述/人物形象/境界/写作风格)
├── plot_templates.md      # 经典桥段 + 章节节奏
└── red_lines.md           # 硬/软/LINT 三层红线
```

参考现有题材(`wuxia/`, `romance/`)对齐结构和详尽程度。

## 提交 Bug 修复

- 在 commit message 里写明 fix #<issue-number>
- 不要把 format/whitespace 改动混入 fix commit

## 提新功能

- 重大新功能请先在 issue 区发起讨论,达成共识再写代码
- 涉及 prompt / system 块改动的,需说明对成本(Prompt Caching 命中率、token 数)的影响
- 涉及 Web UI 的,提供截图(浅色 + 深色主题都要)

## 提交风格

- Python 遵循 PEP 8 + Black(行宽 100)
- 提交前跑一次 `python -m py_compile` 确认语法无误
- 关键函数加 1-2 行 docstring(中文,简洁)
- 谨慎使用第三方依赖,如需新加,在 PR 中说明理由

## 合并流程

- 至少 1 位维护者 review 通过
- CI 通过(若已配置)
- 维护者合并后,会更新 [CHANGELOG.md](CHANGELOG.md) 的 Unreleased 段
