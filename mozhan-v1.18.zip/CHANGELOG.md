﻿# 墨栈 / MoZhan · 变更日志

> 本文档按 SemVer 原则记录面向用户的显著变更。
> 详细迭代记录见 [ITERATION_LOG.md](ITERATION_LOG.md)。



## [v1.17] - 2026-06-10

### 📡 平台层(全新)
- **9 大网文平台调性档案** 落地于 `core/scripts/platform_profiles.py`:
  番茄 🍅 / 书旗 📕 / 七猫 🐱 / 起点 📘 / 晋江 🌸 / 飞卢 🚀 / 刺猬猫 🦔 / 知乎 💡 / 公众号 📱
- 每个平台档案包含:读者画像、书名套路、简介规则、章节字数、题材亲和度、调性提醒
- 平台规则**注入到构思 + 写作的 system prompt**;章节字数按平台基准 × L1/L2/L3/L4 浮动
- 新端点 `GET /api/platforms` — UI 平台卡片数据源

### 🪄 四步构思向导(升级)
1. 选**题材 + 平台**(12 × 10,平台可不选)
2. 写**想法**(种子点子可点选)
3. 定**全本规模**(总字数 + 总章节,4 个预设档位)
4. 看**完整 N 章纲**(每章带标题与钩子,不是只 3 卷)

### 📖 全章纲落库
- `data/outline_full.json` —— 构思阶段的完整章纲落库,供写作台引用
- 新端点 `GET/PUT /api/projects/<n>/outline_full`
- 新端点 `GET /api/projects/<n>/chapter/<num>/blueprint` —— 取该章标题+钩子用于回填
- 写作台新增「📚 大纲」tab,支持搜索 + 「回填 →」按钮

### 🛡 P0 一致性锚定(本轮重点修复)
- **问题**:旧版构思了"陆沉",但写章节时模型常自作主张写成"李轩/林北/楚风",简介背景也对不上
- **根因**:`build_frozen_system` 没读 `conceived.json`
- **修复**:
  - `build_frozen_system` 现在自动读 `conceived.json`,把主角名/身份/动机/简介/主题/书名作为「核心设定(强约束,不得擅自修改)」注入 system prompt 第一段
  - 构思 prompt + 写作 prompt 都加上「保真硬约束 — 最高优先级」三条铁规(不得替换为常见网文套名)
- 新端点 `GET /api/projects/<n>/chapter/<num>/consistency` —— 自动校验主角名/身份/钩子关键词
- 写作台「自检」按钮已合并:同时跑 P0 一致性 + 传统连续性自检

### 🛠 技术细节
- `/api/conceive` 新增参数 `total_words` / `total_chapters` / `platform`,严格生成 N 章大纲
- 章数计算:`arc_count = max(3, 总章/35)`,`out_tokens = min(16000, 1500 + 总章 × 80)`
- 写作时 `outline` 为空,自动从 `outline_full.json` 拉该章钩子

### 🐛 UI 修复
- 修复:「平台 加载中」长时间无响应(`loadPlatforms` 函数缺失)
- 修复:大纲过滤后「回填 →」按钮失绑(改事件委托)
- 加入:`run-conceive` 守卫(字数 ≥ 1 万、章数 ≥ 5)

## [v1.16] - 2026-06-10

### 🎴 品牌:墨栈
- 中文名:**墨栈** · 英文名 **MoZhan** · Slogan:**一栈写尽万千江湖**
- LOGO:古印+墨字简写,见 [`ui/static/logo.svg`](ui/static/logo.svg)
- 视觉:宣纸底 + 墨色 + 古印金

### 🪄 构思工作流(inkos 式三步向导)
1. **选题材** — 12 张题材卡片,emoji + 中文名 + 英文名
2. **写想法** — 多行输入 + 3 个示例 chip
3. **看构思** — Claude 一键生成 书名/副标/简介/主角/分卷大纲/前三章钩子
4. **建立项目** — 一键落库,自动建项目 + 写文风印记

### 🛠 技术变更
- **新端点** `POST /api/conceive` — 输入 `{genre, idea, llm}` → 输出 `conceived` 草稿
- **新端点** `GET/PUT /api/projects/<n>/conceived` — 草稿落库
- **新端点** `GET /api/brand` — 品牌元信息
- **修复** `SelfChecker.run(silent=True)` — 解决 Flask 下 GBK 编码 500
- **更名** 仓库 `novel-writer-universal` → `mozhan`;localStorage key `nwu_llm` → `mozhan_llm`;env `NWU_PROJECTS_ROOT` → `MOZHAN_PROJECTS_ROOT`

## [v1.15] - 2026-06-10
Web UI 首次发布 + GitHub 打包初版。

## [v1.14] - 2026-06-10
文风印记自动注入 — `genre_style.py` 从各题材 `masterpiece_analysis.md` 抽取 ~500 token 结构化印记,经 `LLMClient.FrozenContext.style_fingerprint` 注入 Prompt Caching。

## [v1.13] - 2026-06-10
补全与修补:时段时间词典(12 时辰/古代/现代/工作日) + 7 个新脚本 + 27 个 pytest 测试全过 + 12 题材 red_lines + demo_wuxia 示例。

## [v1.12] - 2026-05-16
自动更新迭代系统:事件驱动(完成书/章节/质量异常/用户请求) → 草案 → 人工审核 → 生效。

## [v1.11] - 2026-05-16
中文网文节奏引擎 + 题材兼容性矩阵 + 人设一致性校验 + 爽点密度控制 + 读者体验指标分离。

## [v1.10] - 2026-05-16
初始版本,基于 novel-writer-inkos-fusion 整合。

TEST
## [v1.18] - 2026-06-11

### 目录合并(同步归档)
- 历史背景:mozhan/ 是 GitHub 发布版,novel-writer-universal/ 是本地开发副本(含真实小说项目 魔尊在我体内、杂役逆天_残功吞天 与早期 git 仓库)。
- 同步:六个核心文件双向校验 SHA-256,内容已完全一致。
- 归档:
  - novel-writer-universal/projects/  ->  mozhan/projects/
  - novel-writer-universal/test_wuxia.md  ->  mozhan/examples/test_wuxia.md
  - novel-writer-universal/.git/(仅含 v1.13 空 commit) -> 已删除
- 结果:mozhan/ 成为唯一仓库,novel-writer-universal/ 已整体移除。
- .gitignore 早已包含 projects/,用户项目数据不会被打包/上传到 GitHub。

### UI 中文化(四表 / 简介 tab)
问题:四张数据表用英文字段(chapter / cultivation_level / priority 等),旧版 loadTables 直接 JSON.stringify,UI 里满是代码。

修复:
- 新增 FIELD_LABELS / VALUE_LABELS 字典(40+ 英→中映射) + renderTableCN 渲染器
- 四表 tab 重写为中文结构化表格:时间线分主线/副线/反派线,角色按主角/导师/反派显示彩色徽章,伏笔 P0/P1 变红/金徽章,物品按武器/线索分类
- 简介 tab 重写为中文卡片(标题/简介/主角/主题/分卷/前三章钩子)
- JSON 模式可切换:默认中文视图,右上角切换按钮
- 补齐 style.css 表格/卡片/徽章/状态药丸样式

### 增强
- 首页加 4 个数据徽章(12题材/9平台/4级成本/3层红线)
- 全局键盘快捷键:Ctrl+Enter 触发主操作,Esc 关闭 toast/返回上一步
- 未配 API Key 时一键跳到设置页
- style.css 补 --font-mono 变量
- 新增 scripts/verify.ps1 一键验证脚本
- 新增 scripts/remove_nwu.ps1 清理脚本

### 静态校验
- 13 个 .py 文件花括号/括号配对全部平衡
- 1 个 app.js 反引号 47 对偶数
- Node.js 端到端模拟 4 张表渲染输出,全部中文
- node --check app.js 通过,无语法错误


