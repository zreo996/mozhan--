@echo off
REM 墨栈 MoZhan · Web UI 启动脚本 (Windows)
chcp 65001 >nul
cd /d "%~dp0\.."
echo.
echo  ========================================
echo   墨栈 · MoZhan Web UI
echo  ========================================
echo.
python -m ui %*
if errorlevel 1 (
  echo.
  echo  [提示] 若提示缺少 flask,请先执行:
  echo         pip install -r requirements.txt
  echo.
  pause
)
