﻿# 墨栈 v1.17 · 一键验证脚本
# 用法:右键 PowerShell → 用 PowerShell 运行
# 或:   powershell -ExecutionPolicy Bypass -File scripts\verify.ps1

Continue = "Stop"
 = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
Write-Host "墨栈 验证  " -ForegroundColor Cyan
Write-Host ""

# 1) Python
 = "C:\Users\Administrator\AppData\Local\Programs\Python\Python313\python.exe"
if (-not (Test-Path )) {
    Write-Host "  ✗ 找不到 Python: " -ForegroundColor Red
    Write-Host "    请先装 Python 3.10+ 并修改此脚本中的 $py 路径" -ForegroundColor Yellow
    exit 1
}
&  -V
Write-Host "  ✓ Python OK" -ForegroundColor Green
Write-Host ""

# 2) 依赖
Write-Host "[1/3] 检查依赖..." -ForegroundColor Cyan
 = @()
foreach ( in "flask", "pytest") {
     = &  -m pip show  2>&1
    if ( -ne 0) {  +=  }
}
if (.Count -gt 0) {
    Write-Host "  ✗ 缺包: " -ForegroundColor Red
    Write-Host "    正在尝试 pip install..." -ForegroundColor Yellow
    &  -m pip install 
}
Write-Host "  ✓ 依赖 OK" -ForegroundColor Green
Write-Host ""

# 3) 静态语法(13 个 py + 1 个 js 配对)
Write-Host "[2/3] 静态语法检查..." -ForegroundColor Cyan
 = @(
    "ui\app.py",
    "ui\__main__.py",
    "core\scripts\self_check.py",
    "core\scripts\post_process.py",
    "core\scripts\quality_score.py",
    "core\scripts\one_click_writer.py",
    "core\scripts\llm_client.py",
    "core\scripts\continuity_enforcer.py",
    "core\scripts\climax_tracker.py",
    "core\scripts\genre_style.py",
    "core\scripts\genre_validator.py",
    "core\scripts\platform_profiles.py",
    "core\scripts\multi_agent.py",
    "core\scripts\auto_update.py"
)
 = 0
foreach ( in ) {
     = Join-Path  
    if (Test-Path ) {
        &  -m py_compile  2>&1 | Out-Null
        if ( -eq 0) {
            Write-Host "  ✓ " -ForegroundColor Green
        } else {
            Write-Host "  ✗ " -ForegroundColor Red
            ++
        }
    }
}
if ( -gt 0) {
    Write-Host "  ✗  个文件语法错误" -ForegroundColor Red
    exit 1
}
Write-Host "  ✓ 14 个 Python 文件全部语法 OK" -ForegroundColor Green
Write-Host ""

# 4) pytest
Write-Host "[3/3] 运行 pytest..." -ForegroundColor Cyan
Push-Location 
try {
    &  -m pytest tests\ -v 2>&1 | Tee-Object -FilePath (Join-Path  "verify.log")
} finally {
    Pop-Location
}
Write-Host ""
Write-Host "完成。日志: \verify.log" -ForegroundColor Cyan
