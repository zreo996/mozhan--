#!/usr/bin/env bash
# 墨栈 MoZhan · Web UI 启动脚本 (Unix/macOS)
set -e
cd "$(dirname "$0")/.."
echo
echo " ========================================"
echo "  墨栈 · MoZhan Web UI"
echo " ========================================"
echo
exec python -m ui "$@"
