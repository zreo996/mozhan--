﻿---
name: mozhan
description: >
  中文长篇小说创作 Skill「墨栈 MoZhan」。12 大题材(玄幻/都市/科幻/历史/游戏/末世/异能/同人/悬疑/武侠/甜宠/快穿) ×
  9 大网文平台(番茄/书旗/七猫/起点/晋江/飞卢/刺猬猫/知乎/公众号)调性适配;
  四步构思向导 → 完整 N 章纲;P0 主角/简介一致性锚定 + 三层红线 + 四表压缩上下文 + L1-L4 成本分级;
  文风印记自动注入 + Web UI(浏览器即开,自接 Anthropic / OpenAI 兼容 API)。
  当用户想"写网文/写小说/构思故事/生成大纲/续写章节/拉网文平台风格"时触发。
tags: [writing, novel, chinese, fiction]
---

# 墨栈 · 全题材中文小说创作助手 v1.17

> 第十七轮迭代 | 9 平台调性 + 四步构思向导 + 全章纲生成 + P0 一致性锚定 + 文风印记自动注入 + Web UI

---

## 一句话定义

四表压缩上下文 + 四级成本分级 + P0/P1/P2 红线护城 + 英雄之旅嵌套结构 + 七大成本优化的全题材中文长篇小说创作系统。

---

## 核心创新

| 特性 | 说明 |
|:---|:---|
| 12 题材 | 玄幻/都市/科幻/历史/游戏/末世/异能/同人/悬疑/武侠/甜宠/快穿 |
| 9 平台 | 番茄/书旗/七猫/起点/晋江/飞卢/刺猬猫/知乎/公众号,书名套路与章节字数自动适配 |
| 四表管理 | timeline/characters/hooks/inventory 压缩上下文,自动续更 |
| 四级成本 | L1(60%)/L2(25%)/L3(10%)/L4(5%) 分级节省 |
| 三层红线 | P0(致命)/P1(严重)/P2(优化) 质量门禁 |
| P0 锚定 | 主角名/简介/主题在每次写作时强制注入 system prompt,防"按模板套" |
| 嵌套英雄 | 大→中→小→微 四层循环结构 |
| 黄金三章 | 第 1 章钩子 + 第 2 章冲突 + 第 3 章转折 |
| 文风印记 | 12 题材精品分析自动抽取,经 Prompt Caching 注入 |
| 七大优化 | 压缩/批量/复用/缓存/并行/增量/路由 |

---

## 项目结构

`
mozhan/
├── SKILL.md                          # 主入口(你在这里)
├── README.md                         # 用户向文档
├── CHANGELOG.md                      # 变更日志(SemVer)
├── ITERATION_LOG.md                  # 迭代日志(三模型辩证)
├── LICENSE                           # MIT
├── requirements.txt
├── .gitignore
├── core/
│   ├── scripts/
│   │   ├── self_check.py             # 五重自检(P0 级)
│   │   ├── post_process.py           # 写后处理(四表更新)
│   │   ├── quality_score.py          # 质量评分
│   │   ├── one_click_writer.py       # 一键写作(CLI)
│   │   ├── llm_client.py             # LLM 客户端(冻结上下文)
│   │   ├── continuity_enforcer.py    # 连续性强制器
│   │   ├── climax_tracker.py         # 爽点密度追踪
│   │   ├── genre_style.py            # 文风印记(注入 Prompt)
│   │   ├── genre_validator.py        # 题材风格校验
│   │   ├── platform_profiles.py      # 9 平台调性档案
│   │   ├── multi_agent.py            # 多 Agent 会诊
│   │   └── auto_update.py            # 事件驱动自动迭代
│   ├── references/
│   │   ├── red_lines.md              # 红线体系(P0/P1/P2)
│   │   ├── cost_tiers.md             # 成本分级(v1.2 优化版)
│   │   ├── cost_optimization.md      # 七大成本优化策略
│   │   ├── context_tables.md         # 四张数据表结构
│   │   ├── hero_journey.md           # 英雄之旅嵌套结构
│   │   ├── multi_agent.md            # 多 Agent 会诊机制
│   │   ├── prompt_caching.md         # Prompt 缓存优化
│   │   ├── auto_learning.md          # 自动化学科机制
│   │   ├── quality_scoring.md        # 质量评分细则
│   │   ├── deepseek_feedback.md      # DeepSeek 辩证记录
│   │   ├── ethics_module.md          # 伦理与版权模块
│   │   └── genre_masterpieces.md     # 题材精品分析汇总
│   └── templates/
│       ├── timeline.json             # 时间线模板
│       ├── characters_snapshot.json  # 角色快照模板
│       ├── hooks.json                # 伏笔追踪模板
│       ├── inventory.json            # 物品追踪模板
│       ├── character_archetypes.md   # 角色模板库
│       ├── plot_templates.md         # 情节模板库
│       └── project_config.json       # 项目配置模板
├── genres/                           # 12 题材
│   └── {fantasy|urban|scifi|historical|game|apocalypse|superpower|
│         fanfiction|mystery|wuxia|romance|isekai}/
│       ├── worldbuilding.md
│       ├── red_lines.md
│       ├── plot_templates.md
│       └── masterpiece_analysis.md
├── examples/
│   └── demo_wuxia/                   # 武侠示例项目(含 5 份数据快照)
├── tests/                            # 49 个 pytest 测试
├── commands/                         # 7 个 slash commands(/write_novel 等)
├── scripts/
│   ├── start_ui.sh                   # Linux/macOS 启动
│   └── start_ui.bat                  # Windows 启动
└── ui/                               # Flask Web UI
    ├── app.py
    ├── __main__.py                   # python -m ui
    ├── templates/index.html
    ├── static/{app.js, style.css, logo.svg}
    └── README.md
`

---

## 快速开始

### 1. 启动 Web UI(推荐)

`ash
pip install -r requirements.txt
python -m ui                        # 默认 http://127.0.0.1:8765
# Windows:  scripts\start_ui.bat
# Linux:    scripts/start_ui.sh
`

打开浏览器 → 填 API Key → 创建项目 → AI 写作。
详见 [ui/README.md](ui/README.md)。

### 2. CLI 写作流程

`ash
# 初始化项目
python core/scripts/one_click_writer.py init 我的小说 玄幻 主角名

# 规划章节
python core/scripts/one_click_writer.py plan 1 L3 大纲.txt

# 写章节
python core/scripts/one_click_writer.py write 1 内容.txt

# 批量写作
python core/scripts/one_click_writer.py batch 1 10 大纲.json
`

### 3. 高级命令(slash)

| 命令 | 作用 |
|:---|:---|
| /write_novel | 进入写作工作流 |
| /outline | 查看/修改大纲 |
| /status | 查看四表状态 |
| /cost | 查看成本报告 |
| /score 第X章 | 章节评分 |
| /check_chapter | 章节一致性自检 |
| /continue_writing | 续写 |

---

## 四表上下文管理

### 核心原则

| 表 | 大小 | 核心规则 |
|:---|:--:|:---|
| timeline.json | ~500 token | 只保留**已发生**时间锚点,过期条目降级或删除 |
| characters_snapshot.json | ~800 token | 只保留**当前状态**(修为/位置/关系),历史进入人物卡 |
| hooks.json | ~400 token | 显性伏笔 5 章/隐性 3 章/环境 10 章回收,过期强制触发 |
| inventory.json | ~300 token | 当前持有物品 + 状态,已消耗/转让/损坏的归档 |

### 写入策略

- 每章写完自动调 post_process.py,LLM 抽取四表 diff → 合并到 JSON
- P0 红线:主角名、修为、已签约关系不可静默修改
- 长度上限硬触发:超阈值时强制归档最早 20% 内容

详见 [core/references/context_tables.md](core/references/context_tables.md)

---

## 三层红线

| 级别 | 含义 | 触发动作 |
|:---:|:---|:---|
| **P0** | 致命(时间倒序、修为倒退、主角名漂移、简介脱节) | 拒绝输出,强制重写 |
| **P1** | 严重(物品消失、伏笔丢失未交代、位置漂移) | 标红警告,人工确认 |
| **P2** | 优化(对话冗余、节奏偏慢、形容词堆砌) | 通过,纳入下章改进池 |

详见 [core/references/red_lines.md](core/references/red_lines.md)

---

## 四级成本分级

| 等级 | 占比 | API 次数 | 适用场景 |
|:---:|:---:|:---:|:---|
| L1 | 60% | 1 次 | 日常推进、过渡章 |
| L2 | 25% | 1-2 次 | 重要节点(拜师/初遇) |
| L3 | 10% | 2-3 次 | 关键章(大战/突破) |
| L4 | 5% | 3-6 次 | 宏篇章(宗门战/飞升) |

详见 [core/references/cost_tiers.md](core/references/cost_tiers.md)

---

## 人设一致性校验

> DeepSeek 指出:当节奏/情感/人设冲突时,以人设优先

**人设 > 节奏 > 情感 > 对话配比**

- 寡言角色:关键场景也不应话多
- 冷酷角色:情感高潮中保持克制
- 弱势角色:即使有机会也不应碾压对手

校验清单见 ed_lines.md 的人设段。

---

## 爽点密度控制

| 爽点类型 | 最小间隔 | 说明 |
|:---|:---:|:---|
| 小打脸 | 3-5 章 | 日常碾压/嘲讽 |
| 中打脸 | 10-15 章 | 正式对决/翻身 |
| 大打脸 | 30-50 章 | 高潮打脸/终极反转 |

**标准密度**:每 100 章 18-25 次打脸
**最大连续非动作章节**:5 章

---

## 题材兼容性矩阵

12 题材两两配对,0-3 分制:

- **0 分**:禁止组合(必须替换)
- **1 分**:困难但可行 — 加"世界观隔离层"(不同时出现)
- **2 分**:可直接混合
- **3 分**:推荐混合(产生协同效应)

详细矩阵见 [core/references/genre_masterpieces.md](core/references/genre_masterpieces.md)。

---

## 双指标评估(质量 vs 读者体验)

`
章节完成
  ↓
质量指标评估 → 语法/连贯性/逻辑(P0 矛盾)
  ↓ (通过)
读者体验指标评估 → 打脸密度/钩子率/翻页率
  ↓ (通过)
交付
`

| 维度 | 指标 | 标准 |
|:---|:---|:---|
| 质量 | 语法正确性 | ≥95% |
| 质量 | 连贯性 | ≥90% |
| 质量 | 逻辑一致性 | 无 P0 矛盾 |
| 体验 | 打脸密度 | 每 100 章 18-25 次 |
| 体验 | 章节钩子率 | ≥95% |
| 体验 | 翻页率预测 | ≥0.7 |

---

## 文风印记自动注入

core/scripts/genre_style.py 从各题材 masterpiece_analysis.md 抽取 ~500 token 的结构化印记(句长偏好/高频词/对话密度/节奏曲线),写入 data/style_fingerprint.json。

写作时 uild_frozen_system 把印记与四表摘要一起注入 system prompt,经 LLMClient.FrozenContext.style_fingerprint 字段进入 Prompt Caching,确保全文风格统一。

---

## Web UI 中文化

UI 已完全中文化(墨栈品牌):

- 界面文案、按钮、提示、错误信息全部中文
- 题材卡片显示「中文名 + emoji」,英文名作副标题(便于国际用户识别)
- 文风印记示例:[examples/demo_wuxia/data/style_fingerprint.json](examples/demo_wuxia/data/style_fingerprint.json)
- 启动入口:python -m ui 或 scripts/start_ui.bat

---

## 测试

`ash
pip install pytest
pytest tests/ -v
`

49 个测试覆盖:连续性强制器、爽点追踪、文风印记、题材校验、LLM 客户端、评分、写后处理。

---

## 三方辩证共识(v1.12 起)

| 优先级 | 原则 | 说明 |
|:---:|:---|:---|
| P0 | **版权合规优先** | 法律风险是硬约束 |
| P1 | **语义鲁棒性** | 技术底线,pass rate > 90% |
| P2 | **数据透明度** | 公信力根基 |
| P3 | **用户反馈闭环** | 需求侧验证 |

详见 [ITERATION_LOG.md](ITERATION_LOG.md) 与 [core/references/deepseek_feedback.md](core/references/deepseek_feedback.md)。

---

## 版本记录

| 版本 | 日期 | 更新内容 |
|:---:|:---|:---|
| **v1.17** | 2026-06-10 | 9 平台调性档案、四步构思向导、全章纲落库、P0 主角/简介一致性锚定 |
| v1.16 | 2026-06-10 | 品牌墨栈、构思工作流(inkos 式)、/api/conceive 端点 |
| v1.15 | 2026-06-10 | Web UI 首次发布 + GitHub 打包初版 |
| v1.14 | 2026-06-10 | 文风印记自动注入(genre_style + Prompt Caching) |
| v1.13 | 2026-06-10 | 补全与修补:时段时间词典 + 7 新脚本 + 27 测试全过 + 12 题材红线 + demo_wuxia |
| v1.12 | 2026-05-16 | 自动更新迭代系统(事件驱动) |
| v1.11 | 2026-05-16 | 中文网文节奏引擎 + 题材兼容性 + 人设校验 + 爽点密度 + 双指标 |
| v1.10 | 2026-05-16 | 初始整合版(novel-writer-inkos-fusion) |

详见 [CHANGELOG.md](CHANGELOG.md) 与 [ITERATION_LOG.md](ITERATION_LOG.md)。
